using System.Windows;
using RealtyAgency.Wpf.ViewModels.Editors;

namespace RealtyAgency.Wpf.Views;

/// <summary>Общее окно для всех форм добавления/редактирования.</summary>
public partial class EditorWindow : Window
{
    public EditorWindow()
    {
        InitializeComponent();
        DataContextChanged += (_, e) =>
        {
            if (e.OldValue is EditorViewModelBase oldVm)
            {
                oldVm.CloseRequested -= OnCloseRequested;
            }

            if (e.NewValue is EditorViewModelBase newVm)
            {
                newVm.CloseRequested += OnCloseRequested;
            }
        };
    }

    private void OnCloseRequested(bool saved) => DialogResult = saved;
}
