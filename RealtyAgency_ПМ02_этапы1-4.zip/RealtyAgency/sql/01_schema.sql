-- =====================================================================
--  Риэлторское агентство «Ключ» — схема базы данных (MySQL 8.x)
--  Запускать первым. Пересоздаёт базу realty_agency с нуля.
-- =====================================================================
CREATE DATABASE IF NOT EXISTS realty_agency
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE realty_agency;

SET FOREIGN_KEY_CHECKS = 0;
DROP VIEW IF EXISTS v_properties_full, v_deals_report, v_realtor_performance;
DROP TABLE IF EXISTS deals, viewings, properties, clients, realtors,
                     property_types, districts, audit_log;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
--  Справочники
-- ---------------------------------------------------------------------
CREATE TABLE districts (
    id   INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE property_types (
    id   INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  Риэлторы (сотрудники агентства)
-- ---------------------------------------------------------------------
CREATE TABLE realtors (
    id                 INT AUTO_INCREMENT PRIMARY KEY,
    full_name          VARCHAR(200)  NOT NULL,
    phone              VARCHAR(20)   NOT NULL UNIQUE,
    email              VARCHAR(254)  NULL,
    commission_percent DECIMAL(5,2)  NOT NULL DEFAULT 3.00
                       CHECK (commission_percent BETWEEN 0 AND 50),
    hire_date          DATE          NOT NULL,
    is_active          TINYINT(1)    NOT NULL DEFAULT 1
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  Клиенты (собственники, покупатели, арендаторы)
-- ---------------------------------------------------------------------
CREATE TABLE clients (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    full_name     VARCHAR(200) NOT NULL,
    phone         VARCHAR(20)  NOT NULL UNIQUE,
    email         VARCHAR(254) NULL,
    notes         VARCHAR(500) NULL,
    registered_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  Объекты недвижимости
-- ---------------------------------------------------------------------
CREATE TABLE properties (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    address          VARCHAR(300)  NOT NULL,
    district_id      INT           NOT NULL,
    property_type_id INT           NOT NULL,
    owner_id         INT           NOT NULL,          -- собственник (клиент)
    realtor_id       INT           NOT NULL,          -- ответственный риэлтор
    offer_type       ENUM('sale','rent') NOT NULL DEFAULT 'sale',
    price            DECIMAL(14,2) NOT NULL CHECK (price > 0),
    area             DECIMAL(8,2)  NOT NULL CHECK (area > 0),
    rooms            INT           NOT NULL DEFAULT 1 CHECK (rooms >= 0),
    floor            INT           NULL,
    total_floors     INT           NULL,
    description      TEXT          NULL,
    status           ENUM('active','reserved','closed','archived') NOT NULL DEFAULT 'active',
    created_at       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_properties_floor
        CHECK (floor IS NULL OR total_floors IS NULL OR floor <= total_floors),
    CONSTRAINT fk_properties_district FOREIGN KEY (district_id) REFERENCES districts(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_properties_type FOREIGN KEY (property_type_id) REFERENCES property_types(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_properties_owner FOREIGN KEY (owner_id) REFERENCES clients(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_properties_realtor FOREIGN KEY (realtor_id) REFERENCES realtors(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  Показы объектов
-- ---------------------------------------------------------------------
CREATE TABLE viewings (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    property_id  INT          NOT NULL,
    client_id    INT          NOT NULL,
    realtor_id   INT          NOT NULL,
    scheduled_at DATETIME     NOT NULL,
    status       ENUM('planned','done','cancelled') NOT NULL DEFAULT 'planned',
    feedback     VARCHAR(500) NULL,
    CONSTRAINT fk_viewings_property FOREIGN KEY (property_id) REFERENCES properties(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_viewings_client FOREIGN KEY (client_id) REFERENCES clients(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_viewings_realtor FOREIGN KEY (realtor_id) REFERENCES realtors(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  Сделки (продажа / аренда)
-- ---------------------------------------------------------------------
CREATE TABLE deals (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    property_id INT           NOT NULL,
    client_id   INT           NOT NULL,               -- покупатель / арендатор
    realtor_id  INT           NOT NULL,
    deal_date   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    amount      DECIMAL(14,2) NOT NULL CHECK (amount > 0),
    commission  DECIMAL(14,2) NOT NULL DEFAULT 0 CHECK (commission >= 0),
    status      ENUM('open','completed','cancelled') NOT NULL DEFAULT 'open',
    CONSTRAINT fk_deals_property FOREIGN KEY (property_id) REFERENCES properties(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_deals_client FOREIGN KEY (client_id) REFERENCES clients(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_deals_realtor FOREIGN KEY (realtor_id) REFERENCES realtors(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  Журнал аудита (заполняется триггерами из 05_audit.sql)
-- ---------------------------------------------------------------------
CREATE TABLE audit_log (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    who         VARCHAR(128) NOT NULL,
    what_action VARCHAR(16)  NOT NULL,
    table_name  VARCHAR(64)  NOT NULL,
    record_id   BIGINT       NULL,
    details     TEXT         NULL,
    event_time  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  Индексы для поиска и отчётов
-- ---------------------------------------------------------------------
CREATE INDEX ix_properties_status_offer ON properties(status, offer_type);
CREATE INDEX ix_properties_price        ON properties(price);
CREATE INDEX ix_properties_address      ON properties(address);
CREATE INDEX ix_viewings_realtor_time   ON viewings(realtor_id, scheduled_at);
CREATE INDEX ix_deals_date              ON deals(deal_date);
CREATE INDEX ix_clients_full_name       ON clients(full_name);

-- ---------------------------------------------------------------------
--  Триггеры-«предохранители» (последний рубеж, основные правила — в BLL)
-- ---------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_deals_before_insert;
DROP TRIGGER IF EXISTS trg_viewings_before_insert;
DROP TRIGGER IF EXISTS trg_properties_before_delete;

DELIMITER $$

-- Нельзя оформить сделку по закрытому/снятому объекту
-- и нельзя продать объект его же собственнику.
CREATE TRIGGER trg_deals_before_insert
BEFORE INSERT ON deals
FOR EACH ROW
BEGIN
    DECLARE v_status VARCHAR(16);
    DECLARE v_owner  INT;
    SELECT status, owner_id INTO v_status, v_owner
      FROM properties WHERE id = NEW.property_id;
    IF v_status IN ('closed', 'archived') THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Объект недоступен для сделки (закрыт или снят с продажи)';
    END IF;
    IF v_owner = NEW.client_id THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Покупатель/арендатор не может совпадать с собственником';
    END IF;
END$$

-- Нельзя назначить показ закрытого/снятого объекта
CREATE TRIGGER trg_viewings_before_insert
BEFORE INSERT ON viewings
FOR EACH ROW
BEGIN
    IF EXISTS (SELECT 1 FROM properties
                WHERE id = NEW.property_id AND status IN ('closed', 'archived')) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Нельзя назначить показ: объект закрыт или снят';
    END IF;
END$$

-- Нельзя удалить объект, по которому были сделки
CREATE TRIGGER trg_properties_before_delete
BEFORE DELETE ON properties
FOR EACH ROW
BEGIN
    IF EXISTS (SELECT 1 FROM deals WHERE property_id = OLD.id) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Нельзя удалить объект: по нему есть сделки';
    END IF;
END$$

DELIMITER ;

-- ---------------------------------------------------------------------
--  Представления
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW v_properties_full AS
SELECT p.id, p.address, d.name AS district, t.name AS property_type,
       p.offer_type, p.price, p.area, p.rooms, p.floor, p.total_floors,
       ROUND(p.price / p.area, 2) AS price_per_m2,
       p.status, c.full_name AS owner, r.full_name AS realtor, p.created_at
FROM properties p
JOIN districts      d ON d.id = p.district_id
JOIN property_types t ON t.id = p.property_type_id
JOIN clients        c ON c.id = p.owner_id
JOIN realtors       r ON r.id = p.realtor_id;

CREATE OR REPLACE VIEW v_deals_report AS
SELECT dl.id, dl.deal_date, p.address, p.offer_type, cl.full_name AS client,
       r.full_name AS realtor, dl.amount, dl.commission, dl.status
FROM deals dl
JOIN properties p  ON p.id  = dl.property_id
JOIN clients    cl ON cl.id = dl.client_id
JOIN realtors   r  ON r.id  = dl.realtor_id;

CREATE OR REPLACE VIEW v_realtor_performance AS
SELECT r.id, r.full_name,
       (SELECT COUNT(*) FROM properties p WHERE p.realtor_id = r.id AND p.status = 'active') AS active_properties,
       (SELECT COUNT(*) FROM viewings v   WHERE v.realtor_id = r.id AND v.status = 'done')   AS done_viewings,
       (SELECT COUNT(*) FROM deals dl     WHERE dl.realtor_id = r.id AND dl.status = 'completed') AS completed_deals,
       (SELECT COALESCE(SUM(dl.commission), 0) FROM deals dl
         WHERE dl.realtor_id = r.id AND dl.status = 'completed') AS total_commission
FROM realtors r;
