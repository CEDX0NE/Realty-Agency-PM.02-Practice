using System.Collections.ObjectModel;
using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.DataAccess;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.Wpf.Infrastructure;

namespace RealtyAgency.Wpf.ViewModels.Pages;

/// <summary>Каталог объектов недвижимости с фильтрами.</summary>
public sealed class PropertiesViewModel : PageViewModel
{
    private readonly IPropertyService _service;
    private readonly IReferenceService _references;
    private readonly EditorFactory _editors;
    private bool _filtersLoaded;

    public PropertiesViewModel(
        IDialogService dialogs,
        IPropertyService service,
        IReferenceService references,
        EditorFactory editors)
        : base(dialogs)
    {
        _service = service;
        _references = references;
        _editors = editors;

        SearchCommand = new AsyncRelayCommand(LoadAsync);
        ResetCommand = new AsyncRelayCommand(ResetAsync);
        AddCommand = new AsyncRelayCommand(AddAsync);
        EditCommand = new AsyncRelayCommand(EditAsync, () => Selected is not null);
        DeleteCommand = new AsyncRelayCommand(DeleteAsync, () => Selected is not null);
        ArchiveCommand = new AsyncRelayCommand(ArchiveAsync, () => Selected is not null);
        ViewingCommand = new AsyncRelayCommand(NewViewingAsync, () => Selected is not null);
        DealCommand = new AsyncRelayCommand(NewDealAsync, () => Selected?.Status == PropertyStatus.Active);
    }

    public override string Title => "Объекты недвижимости";

    public override string Subtitle => "Квартиры, дома и помещения в продаже и аренде";

    public ObservableCollection<Property> Items { get; } = new();

    private Property? _selected;

    public Property? Selected { get => _selected; set => Set(ref _selected, value); }

    // ---------- Фильтры ----------
    public ObservableCollection<District> Districts { get; } = new();

    public ObservableCollection<PropertyType> Types { get; } = new();

    public List<Choice<OfferType>> OfferChoices { get; } = new()
    {
        new("Продажа и аренда", null),
        new("Продажа", OfferType.Sale),
        new("Аренда", OfferType.Rent),
    };

    public List<Choice<PropertyStatus>> StatusChoices { get; } = new()
    {
        new("Все статусы", null),
        new("Активен", PropertyStatus.Active),
        new("Зарезервирован", PropertyStatus.Reserved),
        new("Закрыт", PropertyStatus.Closed),
        new("Снят", PropertyStatus.Archived),
    };

    private string _search = string.Empty;

    public string Search { get => _search; set => Set(ref _search, value); }

    private District? _district;

    public District? SelectedDistrict { get => _district; set => Set(ref _district, value); }

    private PropertyType? _type;

    public PropertyType? SelectedType { get => _type; set => Set(ref _type, value); }

    private Choice<OfferType>? _offer;

    public Choice<OfferType>? Offer { get => _offer; set => Set(ref _offer, value); }

    private Choice<PropertyStatus>? _status;

    public Choice<PropertyStatus>? Status { get => _status; set => Set(ref _status, value); }

    private string _minPrice = string.Empty;

    public string MinPrice { get => _minPrice; set => Set(ref _minPrice, value); }

    private string _maxPrice = string.Empty;

    public string MaxPrice { get => _maxPrice; set => Set(ref _maxPrice, value); }

    // ---------- Команды ----------
    public AsyncRelayCommand SearchCommand { get; }

    public AsyncRelayCommand ResetCommand { get; }

    public AsyncRelayCommand AddCommand { get; }

    public AsyncRelayCommand EditCommand { get; }

    public AsyncRelayCommand DeleteCommand { get; }

    public AsyncRelayCommand ArchiveCommand { get; }

    public AsyncRelayCommand ViewingCommand { get; }

    public AsyncRelayCommand DealCommand { get; }

    public override Task LoadAsync() => RunAsync(async () =>
    {
        if (!_filtersLoaded)
        {
            await LoadFiltersAsync();
        }

        var filter = new PropertyFilter
        {
            Search = Search,
            DistrictId = SelectedDistrict is { Id: > 0 } d ? d.Id : null,
            PropertyTypeId = SelectedType is { Id: > 0 } t ? t.Id : null,
            OfferType = Offer?.Value,
            Status = Status?.Value,
            MinPrice = ParsePrice(MinPrice, "Цена от"),
            MaxPrice = ParsePrice(MaxPrice, "Цена до"),
        };

        var selectedId = Selected?.Id;
        var list = await _service.SearchAsync(filter);

        Items.Clear();
        foreach (var p in list)
        {
            Items.Add(p);
        }

        Selected = Items.FirstOrDefault(p => p.Id == selectedId);
        Footer = $"Найдено объектов: {Items.Count}";
    });

    private async Task LoadFiltersAsync()
    {
        Districts.Clear();
        Districts.Add(new District { Id = 0, Name = "Все районы" });
        foreach (var d in await _references.GetDistrictsAsync())
        {
            Districts.Add(d);
        }

        Types.Clear();
        Types.Add(new PropertyType { Id = 0, Name = "Все типы" });
        foreach (var t in await _references.GetPropertyTypesAsync())
        {
            Types.Add(t);
        }

        SelectedDistrict = Districts[0];
        SelectedType = Types[0];
        Offer = OfferChoices[0];
        Status = StatusChoices[0];
        _filtersLoaded = true;
    }

    private Task ResetAsync()
    {
        Search = MinPrice = MaxPrice = string.Empty;
        if (Districts.Count > 0)
        {
            SelectedDistrict = Districts[0];
        }

        if (Types.Count > 0)
        {
            SelectedType = Types[0];
        }

        Offer = OfferChoices[0];
        Status = StatusChoices[0];
        return LoadAsync();
    }

    /// <summary>
    /// Пустое поле — фильтр не задан. Неверное число — сообщение пользователю
    /// (раньше такой фильтр молча игнорировался и показывались все объекты).
    /// </summary>
    private static decimal? ParsePrice(string text, string field)
    {
        if (NumberText.Normalize(text).Length == 0)
        {
            return null;
        }

        return NumberText.TryParseDecimal(text, out var value) && value >= 0
            ? value
            : throw new ValidationException($"Поле «{field}»: введите число, например 12 500 000");
    }

    private async Task AddAsync()
    {
        if (await Dialogs.ShowEditorAsync(_editors.PropertyEditor(null)))
        {
            await LoadAsync();
        }
    }

    private async Task EditAsync()
    {
        if (Selected is null)
        {
            return;
        }

        if (await Dialogs.ShowEditorAsync(_editors.PropertyEditor(Selected)))
        {
            await LoadAsync();
        }
    }

    private async Task DeleteAsync()
    {
        if (Selected is not { } p)
        {
            return;
        }

        if (!Dialogs.Confirm($"Удалить объект «{p.Address}»?\nПоказы по нему тоже будут удалены."))
        {
            return;
        }

        if (await RunAsync(() => _service.DeleteAsync(p.Id)))
        {
            await LoadAsync();
        }
    }

    private async Task ArchiveAsync()
    {
        if (Selected is not { } p)
        {
            return;
        }

        if (await RunAsync(() => _service.ToggleArchiveAsync(p.Id)))
        {
            await LoadAsync();
        }
    }

    private async Task NewViewingAsync()
    {
        if (Selected is not { } p)
        {
            return;
        }

        if (await Dialogs.ShowEditorAsync(_editors.ViewingEditor(null, p.Id)))
        {
            Dialogs.Info("Показ назначен. Он появится в разделе «Показы».");
        }
    }

    private async Task NewDealAsync()
    {
        if (Selected is not { } p)
        {
            return;
        }

        if (await Dialogs.ShowEditorAsync(_editors.DealEditor(p.Id)))
        {
            await LoadAsync();
        }
    }
}
