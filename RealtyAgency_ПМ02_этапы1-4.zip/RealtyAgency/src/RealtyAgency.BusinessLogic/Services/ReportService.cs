using System.Data;
using System.Globalization;
using System.Text;
using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.BusinessLogic.Logging;
using RealtyAgency.DataAccess;
using RealtyAgency.DataAccess.Interfaces;

namespace RealtyAgency.BusinessLogic.Services;

/// <summary>Отчёты и экспорт.</summary>
public class ReportService : ServiceBase, IReportService
{
    private static readonly CultureInfo Russian = CultureInfo.GetCultureInfo("ru-RU");

    private readonly IReportRepository _repo;

    /// <summary>Инициализирует новый экземпляр класса <see cref="ReportService"/>.</summary>
    /// <param name="repo">Репозиторий отчётов.</param>
    public ReportService(IReportRepository repo) => _repo = repo;

    /// <inheritdoc/>
    public Task<DashboardStats> GetDashboardAsync() =>
        GuardAsync("Показатели главной", () => _repo.GetDashboardStatsAsync());

    /// <inheritdoc/>
    public Task<DataTable> DealsByPeriodAsync(DateTime dateFrom, DateTime dateTo) =>
        GuardAsync("Отчёт: сделки за период", () =>
        {
            CheckPeriod(dateFrom, dateTo);
            return _repo.GetDealsByPeriodAsync(dateFrom, dateTo);
        });

    /// <inheritdoc/>
    public Task<DataTable> RealtorPerformanceAsync(DateTime dateFrom, DateTime dateTo) =>
        GuardAsync("Отчёт: эффективность риэлторов", () =>
        {
            CheckPeriod(dateFrom, dateTo);
            return _repo.GetRealtorPerformanceAsync(dateFrom, dateTo);
        });

    /// <inheritdoc/>
    public Task<DataTable> MarketByDistrictAsync() =>
        GuardAsync("Отчёт: рынок по районам", () => _repo.GetMarketByDistrictAsync());

    /// <inheritdoc/>
    public void ExportCsv(DataTable table, string path)
    {
        try
        {
            var sb = new StringBuilder();
            sb.AppendLine(string.Join(";", table.Columns.Cast<DataColumn>().Select(c => Escape(c.ColumnName))));
            foreach (DataRow row in table.Rows)
            {
                sb.AppendLine(string.Join(";", row.ItemArray.Select(v => Escape(Format(v)))));
            }

            // UTF-8 с BOM — чтобы Excel правильно показал кириллицу
            File.WriteAllText(path, sb.ToString(), new UTF8Encoding(true));
            AppLog.Info("BLL", $"Экспорт CSV: {table.Rows.Count} строк -> {path}");
        }
        catch (IOException ex)
        {
            AppLog.Error("BLL", "Экспорт CSV", ex);
            throw new RealtyException($"Не удалось сохранить файл: {ex.Message}", ex);
        }
        catch (UnauthorizedAccessException ex)
        {
            AppLog.Error("BLL", "Экспорт CSV", ex);
            throw new RealtyException("Нет прав на запись в выбранную папку.", ex);
        }
    }

    private static void CheckPeriod(DateTime dateFrom, DateTime dateTo)
    {
        if (dateFrom.Date > dateTo.Date)
        {
            throw new ValidationException("Дата «с» позже даты «по»");
        }
    }

    private static string Format(object? v) => v switch
    {
        null or DBNull => string.Empty,
        decimal d => d.ToString("0.##", Russian),
        DateTime dt => dt.ToString("dd.MM.yyyy HH:mm", Russian),
        IFormattable f => f.ToString(null, Russian),
        _ => v.ToString() ?? string.Empty,
    };

    private static string Escape(string s) =>
        s.Contains(';') || s.Contains('"') || s.Contains('\n') || s.Contains('\r')
            ? "\"" + s.Replace("\"", "\"\"") + "\""
            : s;
}
