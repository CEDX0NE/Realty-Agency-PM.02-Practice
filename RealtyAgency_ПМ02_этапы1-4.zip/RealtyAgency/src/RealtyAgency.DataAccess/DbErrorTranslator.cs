using Microsoft.EntityFrameworkCore;
using MySqlConnector;

namespace RealtyAgency.DataAccess;

/// <summary>Перевод ошибок MySQL/EF Core в DataAccessException.</summary>
internal static class DbErrorTranslator
{
    // Коды ошибок MySQL (https://dev.mysql.com/doc/mysql-errors/8.0/en/)
    private const int CannotGetHostName = 1042;
    private const int AccessDenied = 1045;
    private const int UnknownDatabase = 1049;
    private const int CannotConnectLocal = 2002;
    private const int CannotConnectRemote = 2003;
    private const int RowIsReferenced = 1451;
    private const int NoReferencedRow = 1452;
    private const int DuplicateEntry = 1062;
    private const int SignalException = 1644;

    /// <summary>Является ли исключение ошибкой базы данных.</summary>
    /// <param name="ex">Исключение.</param>
    /// <returns><see langword="true"/> для ошибок EF Core и MySQL.</returns>
    public static bool IsDbError(Exception ex) =>
        ex is DbUpdateException || FindMySql(ex) is not null;

    /// <summary>Переводит исключение MySQL / EF Core в <see cref="DataAccessException"/> с понятным текстом.</summary>
    /// <param name="ex">Исходное исключение.</param>
    /// <returns>Исключение слоя доступа к данным.</returns>
    public static DataAccessException Translate(Exception ex)
    {
        var mysql = FindMySql(ex);
        if (mysql is null)
        {
            return new DataAccessException("Ошибка сохранения данных: " + ex.Message, DbErrorKind.General, ex);
        }

        return mysql.Number switch
        {
            CannotGetHostName or AccessDenied or UnknownDatabase or CannotConnectLocal or CannotConnectRemote =>
                Error(
                    "Не удалось подключиться к MySQL. Проверьте, что сервер запущен, " +
                    "а строка подключения в appsettings.json верна.\n\n" + mysql.Message,
                    DbErrorKind.Connection),
            RowIsReferenced => Error("Запись используется в других таблицах, удалить её нельзя.", DbErrorKind.ForeignKey),
            NoReferencedRow => Error("Указана несуществующая связанная запись.", DbErrorKind.ForeignKey),
            DuplicateEntry => Error("Такая запись уже существует (нарушена уникальность).", DbErrorKind.Duplicate),
            SignalException => Error(mysql.Message, DbErrorKind.Rule),
            _ => Error($"Ошибка MySQL ({mysql.Number}): {mysql.Message}", DbErrorKind.General),
        };

        DataAccessException Error(string message, DbErrorKind kind) => new(message, kind, ex);
    }

    private static MySqlException? FindMySql(Exception? ex)
    {
        while (ex is not null)
        {
            if (ex is MySqlException m)
            {
                return m;
            }

            ex = ex.InnerException;
        }

        return null;
    }
}
