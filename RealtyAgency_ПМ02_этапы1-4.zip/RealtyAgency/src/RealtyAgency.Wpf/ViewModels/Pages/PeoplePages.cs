using System.Collections.ObjectModel;
using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.Wpf.Infrastructure;

namespace RealtyAgency.Wpf.ViewModels.Pages;

/// <summary>Клиенты агентства.</summary>
public sealed class ClientsViewModel : PageViewModel
{
    private readonly IClientService _service;
    private readonly EditorFactory _editors;

    public ClientsViewModel(IDialogService dialogs, IClientService service, EditorFactory editors)
        : base(dialogs)
    {
        _service = service;
        _editors = editors;
        SearchCommand = new AsyncRelayCommand(LoadAsync);
        AddCommand = new AsyncRelayCommand(AddAsync);
        EditCommand = new AsyncRelayCommand(EditAsync, () => Selected is not null);
        DeleteCommand = new AsyncRelayCommand(DeleteAsync, () => Selected is not null);
    }

    public override string Title => "Клиенты";

    public override string Subtitle => "Собственники, покупатели и арендаторы";

    public ObservableCollection<Client> Items { get; } = new();

    private Client? _selected;

    public Client? Selected { get => _selected; set => Set(ref _selected, value); }

    private string _search = string.Empty;

    public string Search { get => _search; set => Set(ref _search, value); }

    public AsyncRelayCommand SearchCommand { get; }

    public AsyncRelayCommand AddCommand { get; }

    public AsyncRelayCommand EditCommand { get; }

    public AsyncRelayCommand DeleteCommand { get; }

    public override Task LoadAsync() => RunAsync(async () =>
    {
        var list = await _service.GetAllAsync(Search);
        Items.Clear();
        foreach (var c in list)
        {
            Items.Add(c);
        }

        Footer = $"Клиентов: {Items.Count}";
    });

    private async Task AddAsync()
    {
        if (await Dialogs.ShowEditorAsync(_editors.ClientEditor(null)))
        {
            await LoadAsync();
        }
    }

    private async Task EditAsync()
    {
        if (Selected is null)
        {
            return;
        }

        if (await Dialogs.ShowEditorAsync(_editors.ClientEditor(Selected)))
        {
            await LoadAsync();
        }
    }

    private async Task DeleteAsync()
    {
        if (Selected is not { } c)
        {
            return;
        }

        if (!Dialogs.Confirm($"Удалить клиента «{c.FullName}»?"))
        {
            return;
        }

        if (await RunAsync(() => _service.DeleteAsync(c.Id)))
        {
            await LoadAsync();
        }
    }
}

/// <summary>Сотрудники-риэлторы.</summary>
public sealed class RealtorsViewModel : PageViewModel
{
    private readonly IRealtorService _service;
    private readonly EditorFactory _editors;

    public RealtorsViewModel(IDialogService dialogs, IRealtorService service, EditorFactory editors)
        : base(dialogs)
    {
        _service = service;
        _editors = editors;
        AddCommand = new AsyncRelayCommand(AddAsync);
        EditCommand = new AsyncRelayCommand(EditAsync, () => Selected is not null);
        DeleteCommand = new AsyncRelayCommand(DeleteAsync, () => Selected is not null);
    }

    public override string Title => "Риэлторы";

    public override string Subtitle => "Сотрудники агентства и их комиссия";

    public ObservableCollection<Realtor> Items { get; } = new();

    private Realtor? _selected;

    public Realtor? Selected { get => _selected; set => Set(ref _selected, value); }

    private bool _showInactive;

    public bool ShowInactive
    {
        get => _showInactive;
        set
        {
            if (Set(ref _showInactive, value))
            {
                _ = LoadAsync();
            }
        }
    }

    public AsyncRelayCommand AddCommand { get; }

    public AsyncRelayCommand EditCommand { get; }

    public AsyncRelayCommand DeleteCommand { get; }

    public override Task LoadAsync() => RunAsync(async () =>
    {
        var list = await _service.GetAllAsync(onlyActive: !ShowInactive);
        Items.Clear();
        foreach (var r in list)
        {
            Items.Add(r);
        }

        Footer = $"Риэлторов: {Items.Count}";
    });

    private async Task AddAsync()
    {
        if (await Dialogs.ShowEditorAsync(_editors.RealtorEditor(null)))
        {
            await LoadAsync();
        }
    }

    private async Task EditAsync()
    {
        if (Selected is null)
        {
            return;
        }

        if (await Dialogs.ShowEditorAsync(_editors.RealtorEditor(Selected)))
        {
            await LoadAsync();
        }
    }

    private async Task DeleteAsync()
    {
        if (Selected is not { } r)
        {
            return;
        }

        if (!Dialogs.Confirm($"Удалить риэлтора «{r.FullName}»?"))
        {
            return;
        }

        if (await RunAsync(() => _service.DeleteAsync(r.Id)))
        {
            await LoadAsync();
        }
    }
}
