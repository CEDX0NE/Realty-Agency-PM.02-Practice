using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Services;

namespace RealtyAgency.Tests.Unit;

/// <summary>Общие проверки полей (класс Validator).</summary>
[Trait("Category", "Unit")]
public class ValidatorTests
{
    [Theory]
    [InlineData("+7 (916) 200-00-01")]
    [InlineData("+79162000001")]
    [InlineData("8 916 200 00 01")]
    public void IsPhone_ValidFormats_ReturnsTrue(string phone)
    {
        Assert.True(Validator.IsPhone(phone));
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData("12345")]
    [InlineData("+7 (916) abc-00-01")]
    [InlineData(null)]
    public void IsPhone_InvalidValues_ReturnsFalse(string? phone)
    {
        Assert.False(Validator.IsPhone(phone));
    }

    [Theory]
    [InlineData(null, true)]
    [InlineData("", true)]
    [InlineData("ivanov@mail.ru", true)]
    [InlineData("ivanov@mail", false)]
    [InlineData("ivanov mail.ru", false)]
    public void IsEmailOrEmpty_ReturnsExpected(string? email, bool expected)
    {
        Assert.Equal(expected, Validator.IsEmailOrEmpty(email));
    }

    [Fact]
    public void Clean_WhitespaceString_ReturnsNull()
    {
        Assert.Null(Validator.Clean("   "));
        Assert.Equal("текст", Validator.Clean("  текст "));
    }

    [Fact]
    public void ThrowIfInvalid_SeveralErrors_CollectsAllErrors()
    {
        // Arrange
        var validator = new Validator()
            .Require(false, "Ошибка 1")
            .Require(true, "Не должно попасть")
            .Require(false, "Ошибка 2");

        // Act
        var ex = Assert.Throws<ValidationException>(validator.ThrowIfInvalid);

        // Assert
        Assert.Equal(new[] { "Ошибка 1", "Ошибка 2" }, ex.Errors);
    }
}
