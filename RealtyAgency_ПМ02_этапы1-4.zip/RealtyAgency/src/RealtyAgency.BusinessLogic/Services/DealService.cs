using System.Diagnostics;
using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.BusinessLogic.Logging;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Interfaces;

namespace RealtyAgency.BusinessLogic.Services;

/// <summary>
/// Сделки — главный бизнес-процесс агентства.
/// Правила:
///  • сделку можно открыть только по объекту в статусе «Активен»;
///  • покупатель/арендатор ≠ собственник;
///  • комиссия = сумма × процент риэлтора;
///  • открытая сделка резервирует объект, завершённая — закрывает,
///    отменённая — возвращает объект в продажу.
/// </summary>
public class DealService : ServiceBase, IDealService
{
    private readonly IDealRepository _deals;
    private readonly IPropertyRepository _properties;
    private readonly IRealtorRepository _realtors;

    /// <summary>Инициализирует новый экземпляр класса <see cref="DealService"/>.</summary>
    /// <param name="deals">Репозиторий сделок.</param>
    /// <param name="properties">Репозиторий объектов.</param>
    /// <param name="realtors">Репозиторий риэлторов.</param>
    public DealService(IDealRepository deals, IPropertyRepository properties, IRealtorRepository realtors)
    {
        _deals = deals;
        _properties = properties;
        _realtors = realtors;
    }

    /// <inheritdoc/>
    public Task<List<Deal>> GetAllAsync(DealStatus? status = null) =>
        GuardAsync("Список сделок", () => _deals.GetAllAsync(status));

    /// <inheritdoc/>
    public decimal CalculateCommission(decimal amount, decimal percent)
    {
        var commission = Math.Round(amount * percent / 100m, 2, MidpointRounding.AwayFromZero);
        Debug.Assert(commission >= 0, "Комиссия не может быть отрицательной");
        return commission;
    }

    /// <inheritdoc/>
    public Task CreateAsync(Deal deal) =>
        GuardAsync($"Оформление сделки по объекту ID={deal.PropertyId}", async () =>
        {
            Validate(deal);
            var property = await GetAvailablePropertyAsync(deal);
            var realtor = await GetActiveRealtorAsync(deal.RealtorId);

            deal.Commission = CalculateCommission(deal.Amount, realtor.CommissionPercent);
            WarnIfAmountDiffersFromPrice(deal, property);

            var newStatus = deal.Status == DealStatus.Completed ? PropertyStatus.Closed : PropertyStatus.Reserved;
            await _deals.CreateAsync(deal, newStatus);

            AppLog.Info("BLL", $"Сделка ID={deal.Id}: объект {deal.PropertyId}, сумма {deal.Amount:N0}, " +
                               $"комиссия {deal.Commission:N0}, объект -> {newStatus}");
        });

    /// <inheritdoc/>
    public Task CompleteAsync(int dealId) => ChangeAsync(dealId, DealStatus.Completed, PropertyStatus.Closed);

    /// <inheritdoc/>
    public Task CancelAsync(int dealId) => ChangeAsync(dealId, DealStatus.Cancelled, PropertyStatus.Active);

    private static void Validate(Deal deal) =>
        new Validator()
            .Require(deal.PropertyId > 0, "Выберите объект")
            .Require(deal.ClientId > 0, "Выберите клиента (покупателя / арендатора)")
            .Require(deal.RealtorId > 0, "Выберите риэлтора")
            .Require(deal.Amount > 0, "Сумма сделки должна быть больше нуля")
            .Require(deal.Amount <= Limits.MaxMoney, "Сумма сделки — не больше 999 999 999 999,99 ₽")
            .Require(deal.Status != DealStatus.Cancelled, "Новая сделка не может быть сразу отменённой")
            .Require(deal.DealDate.Date <= DateTime.Today, "Дата сделки не может быть в будущем")
            .ThrowIfInvalid();

    private static void WarnIfAmountDiffersFromPrice(Deal deal, Property property)
    {
        var deviation = Math.Abs(deal.Amount - property.Price) / property.Price;
        if (deviation > Limits.PriceDeviationWarning)
        {
            AppLog.Warn("BLL", $"Сумма сделки {deal.Amount:N0} отличается от цены объекта " +
                               $"{property.Price:N0} более чем на {Limits.PriceDeviationWarning:P0}");
        }
    }

    private async Task<Property> GetAvailablePropertyAsync(Deal deal)
    {
        var property = await _properties.GetByIdAsync(deal.PropertyId)
                       ?? throw new EntityNotFoundException("Выбранный объект не найден");

        if (property.Status != PropertyStatus.Active)
        {
            var reason = property.Status switch
            {
                PropertyStatus.Reserved => "по нему уже есть открытая сделка",
                PropertyStatus.Closed => "он уже продан/сдан",
                _ => "он снят с продажи",
            };
            throw new PropertyNotAvailableException(
                property.Id,
                $"Нельзя оформить сделку по «{property.Address}»: {reason}.");
        }

        if (property.OwnerId == deal.ClientId)
        {
            throw new ValidationException("Покупатель/арендатор не может быть собственником объекта");
        }

        return property;
    }

    private async Task<Realtor> GetActiveRealtorAsync(int realtorId)
    {
        var realtor = await _realtors.GetByIdAsync(realtorId)
                      ?? throw new EntityNotFoundException("Выбранный риэлтор не найден");
        if (!realtor.IsActive)
        {
            throw new ValidationException($"Риэлтор {realtor.FullName} больше не работает в агентстве");
        }

        return realtor;
    }

    private Task ChangeAsync(int dealId, DealStatus status, PropertyStatus propertyStatus) =>
        GuardAsync($"Сделка ID={dealId} -> {status}", async () =>
        {
            var deal = await _deals.GetByIdAsync(dealId)
                       ?? throw new EntityNotFoundException($"Сделка ID={dealId} не найдена");

            if (deal.Status != DealStatus.Open)
            {
                throw new BusinessRuleException("Изменить можно только открытую сделку.");
            }

            await _deals.ChangeStatusAsync(dealId, status, propertyStatus);
            AppLog.Info("BLL", $"Сделка ID={dealId}: {deal.Status} -> {status}");
        });
}
