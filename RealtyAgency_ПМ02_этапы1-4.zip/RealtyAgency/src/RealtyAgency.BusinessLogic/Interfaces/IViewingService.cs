using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.BusinessLogic.Interfaces;

/// <summary>Показы объектов клиентам.</summary>
public interface IViewingService
{
    /// <summary>Возвращает показы.</summary>
    /// <param name="status">Статус для отбора или <see langword="null"/> — все.</param>
    /// <returns>Список показов.</returns>
    Task<List<Viewing>> GetAllAsync(ViewingStatus? status = null);

    /// <summary>Добавить (Id = 0) или сохранить показ.</summary>
    /// <param name="viewing">Показ.</param>
    /// <returns>Задача.</returns>
    /// <exception cref="Exceptions.RealtorBusyException">У риэлтора другой показ ближе чем за час.</exception>
    /// <exception cref="Exceptions.PropertyNotAvailableException">Объект закрыт или снят.</exception>
    Task SaveAsync(Viewing viewing);

    /// <summary>Отмечает показ проведённым или отменённым.</summary>
    /// <param name="id">Код показа.</param>
    /// <param name="status">Новый статус.</param>
    /// <param name="feedback">Отзыв клиента (необязательно).</param>
    /// <returns>Задача.</returns>
    Task SetStatusAsync(int id, ViewingStatus status, string? feedback);

    /// <summary>Удаляет показ.</summary>
    /// <param name="id">Код показа.</param>
    /// <returns>Задача.</returns>
    Task DeleteAsync(int id);
}
