using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.BusinessLogic.Interfaces;

/// <summary>Риэлторы агентства.</summary>
public interface IRealtorService
{
    /// <summary>Возвращает риэлторов.</summary>
    /// <param name="onlyActive"><see langword="true"/> — только работающие.</param>
    /// <returns>Список риэлторов.</returns>
    Task<List<Realtor>> GetAllAsync(bool onlyActive = false);

    /// <summary>Добавить (Id = 0) или сохранить изменения.</summary>
    /// <param name="realtor">Риэлтор.</param>
    /// <returns>Задача.</returns>
    /// <exception cref="Exceptions.ValidationException">Поля заполнены неверно или телефон занят.</exception>
    Task SaveAsync(Realtor realtor);

    /// <summary>Удаляет риэлтора.</summary>
    /// <param name="id">Код риэлтора.</param>
    /// <returns>Задача.</returns>
    /// <exception cref="Exceptions.DeleteRestrictedException">У риэлтора есть объекты, показы или сделки.</exception>
    Task DeleteAsync(int id);
}
