namespace RealtyAgency.BusinessLogic.Exceptions;

/// <summary>Неверно заполнены поля формы.</summary>
public class ValidationException : RealtyException
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="ValidationException"/> со списком ошибок.</summary>
    /// <param name="errors">Тексты ошибок для показа пользователю.</param>
    public ValidationException(IReadOnlyList<string> errors)
        : base("Проверьте введённые данные:\n• " + string.Join("\n• ", errors))
    {
        Errors = errors;
    }

    /// <summary>Инициализирует новый экземпляр класса <see cref="ValidationException"/> с одной ошибкой.</summary>
    /// <param name="error">Текст ошибки.</param>
    public ValidationException(string error)
        : this(new[] { error })
    {
    }

    /// <summary>Получает все найденные ошибки.</summary>
    public IReadOnlyList<string> Errors { get; }
}
