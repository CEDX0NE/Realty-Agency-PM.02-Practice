namespace RealtyAgency.DataAccess.Entities;

/// <summary>Статус сделки.</summary>
public enum DealStatus
{
    /// <summary>Открыта: объект зарезервирован.</summary>
    Open,

    /// <summary>Завершена: объект продан или сдан.</summary>
    Completed,

    /// <summary>Отменена: объект возвращён в продажу.</summary>
    Cancelled,
}
