using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Logging;
using RealtyAgency.Wpf.Infrastructure;

namespace RealtyAgency.Wpf.ViewModels;

/// <summary>Базовый класс страницы (раздела) приложения.</summary>
public abstract class PageViewModel : ObservableObject
{
    protected PageViewModel(IDialogService dialogs) => Dialogs = dialogs;

    public abstract string Title { get; }

    public abstract string Subtitle { get; }

    private bool _isBusy;

    public bool IsBusy { get => _isBusy; set => Set(ref _isBusy, value); }

    private string _footer = string.Empty;

    /// <summary>Получает или задает строку под таблицей: «Найдено: 12» и т.п.</summary>
    public string Footer { get => _footer; set => Set(ref _footer, value); }

    /// <summary>Получает сервис диалогов (сообщения, подтверждения, формы).</summary>
    protected IDialogService Dialogs { get; }

    /// <summary>Загрузить данные страницы (вызывается при каждом переходе на неё).</summary>
    public abstract Task LoadAsync();

    /// <summary>
    /// Выполнить действие с обработкой ошибок: исключения бизнес-логики
    /// показываются пользователю понятным сообщением, а не «падают».
    /// </summary>
    protected async Task<bool> RunAsync(Func<Task> action)
    {
        IsBusy = true;
        try
        {
            await action();
            return true;
        }
        catch (ValidationException ex)
        {
            Dialogs.Error(ex.Message, "Проверьте данные");
        }
        catch (DatabaseException ex)
        {
            Dialogs.Error(ex.Message, "Ошибка базы данных");
        }
        catch (RealtyException ex)
        {
            Dialogs.Error(ex.Message, "Операция невозможна");
        }
        finally
        {
            IsBusy = false;
        }

        AppLog.Warn("UI", $"{GetType().Name}: действие завершилось ошибкой (показана пользователю)");
        return false;
    }
}
