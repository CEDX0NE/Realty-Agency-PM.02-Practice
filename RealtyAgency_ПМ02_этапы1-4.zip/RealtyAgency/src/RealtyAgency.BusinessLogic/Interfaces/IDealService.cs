using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.BusinessLogic.Interfaces;

/// <summary>Сделки купли-продажи и аренды.</summary>
public interface IDealService
{
    /// <summary>Возвращает сделки.</summary>
    /// <param name="status">Статус для отбора или <see langword="null"/> — все.</param>
    /// <returns>Список сделок.</returns>
    Task<List<Deal>> GetAllAsync(DealStatus? status = null);

    /// <summary>Комиссия агентства: сумма × процент / 100, округление до копеек.</summary>
    /// <param name="amount">Сумма сделки.</param>
    /// <param name="percent">Процент комиссии риэлтора.</param>
    /// <returns>Комиссия в рублях.</returns>
    decimal CalculateCommission(decimal amount, decimal percent);

    /// <summary>Оформить сделку. Объект становится «Зарезервирован» или «Закрыт».</summary>
    /// <param name="deal">Сделка; комиссия рассчитывается автоматически.</param>
    /// <returns>Задача.</returns>
    /// <exception cref="Exceptions.PropertyNotAvailableException">Объект не активен.</exception>
    /// <exception cref="Exceptions.ValidationException">Поля заполнены неверно или покупатель — собственник.</exception>
    Task CreateAsync(Deal deal);

    /// <summary>Завершает открытую сделку; объект становится «Закрыт».</summary>
    /// <param name="dealId">Код сделки.</param>
    /// <returns>Задача.</returns>
    Task CompleteAsync(int dealId);

    /// <summary>Отменяет открытую сделку; объект возвращается в продажу.</summary>
    /// <param name="dealId">Код сделки.</param>
    /// <returns>Задача.</returns>
    Task CancelAsync(int dealId);
}
