using Microsoft.EntityFrameworkCore;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Interfaces;

namespace RealtyAgency.DataAccess.Repositories;

/// <summary>Клиенты.</summary>
public class ClientRepository : RepositoryBase, IClientRepository
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="ClientRepository"/>.</summary>
    /// <param name="factory">Фабрика контекстов EF Core.</param>
    public ClientRepository(IDbContextFactory<RealtyDbContext> factory)
        : base(factory)
    {
    }

    /// <inheritdoc/>
    public Task<List<Client>> GetAllAsync(string? search) =>
        QueryAsync("Список клиентов", db =>
        {
            var q = db.Clients.AsNoTracking();
            if (!string.IsNullOrWhiteSpace(search))
            {
                // EF Core сам превращает это в параметризованный LIKE — SQL-инъекция невозможна
                var s = search.Trim();
                q = q.Where(c => c.FullName.Contains(s) || c.Phone.Contains(s)
                                 || (c.Email != null && c.Email.Contains(s)));
            }

            return q.OrderBy(c => c.FullName).ToListAsync();
        });

    /// <inheritdoc/>
    public Task<Client?> GetByIdAsync(int id) =>
        QueryAsync($"Клиент ID={id}", db =>
            db.Clients.AsNoTracking().FirstOrDefaultAsync(c => c.Id == id));

    /// <inheritdoc/>
    public Task<bool> PhoneExistsAsync(string phone, int excludeId) =>
        QueryAsync("Проверка телефона клиента", db =>
            db.Clients.AnyAsync(c => c.Phone == phone && c.Id != excludeId));

    /// <inheritdoc/>
    public Task AddAsync(Client client) =>
        ExecuteAsync($"Добавление клиента «{client.FullName}»", async db =>
        {
            db.Clients.Add(client);
            await db.SaveChangesAsync();
        });

    /// <inheritdoc/>
    public Task UpdateAsync(Client client) =>
        ExecuteAsync($"Изменение клиента ID={client.Id}", async db =>
        {
            var existing = await db.Clients.FindAsync(client.Id) ?? throw NotFound("Клиент", client.Id);
            db.Entry(existing).CurrentValues.SetValues(client);
            await db.SaveChangesAsync();
        });

    /// <inheritdoc/>
    public Task DeleteAsync(int id) =>
        ExecuteAsync($"Удаление клиента ID={id}", async db =>
        {
            var existing = await db.Clients.FindAsync(id) ?? throw NotFound("Клиент", id);
            db.Clients.Remove(existing);
            await db.SaveChangesAsync();
        });
}
