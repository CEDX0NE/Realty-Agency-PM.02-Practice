using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.DataAccess.Interfaces;

/// <summary>Риэлторы.</summary>
public interface IRealtorRepository
{
    /// <summary>Возвращает риэлторов по алфавиту.</summary>
    /// <param name="onlyActive"><see langword="true"/> — только работающие.</param>
    /// <returns>Список риэлторов.</returns>
    Task<List<Realtor>> GetAllAsync(bool onlyActive);

    /// <summary>Находит риэлтора по коду.</summary>
    /// <param name="id">Код риэлтора.</param>
    /// <returns>Риэлтор или <see langword="null"/>.</returns>
    Task<Realtor?> GetByIdAsync(int id);

    /// <summary>Проверяет, занят ли телефон другим риэлтором.</summary>
    /// <param name="phone">Телефон.</param>
    /// <param name="excludeId">Код риэлтора, которого не учитывать (при редактировании).</param>
    /// <returns><see langword="true"/>, если телефон занят.</returns>
    Task<bool> PhoneExistsAsync(string phone, int excludeId);

    /// <summary>Добавляет риэлтора; после вызова заполнен <see cref="Realtor.Id"/>.</summary>
    /// <param name="realtor">Риэлтор.</param>
    /// <returns>Задача.</returns>
    Task AddAsync(Realtor realtor);

    /// <summary>Сохраняет изменения риэлтора.</summary>
    /// <param name="realtor">Риэлтор.</param>
    /// <returns>Задача.</returns>
    Task UpdateAsync(Realtor realtor);

    /// <summary>Удаляет риэлтора.</summary>
    /// <param name="id">Код риэлтора.</param>
    /// <returns>Задача.</returns>
    Task DeleteAsync(int id);
}
