-- =====================================================================
--  Тестовые данные. Запускать после 01_schema.sql
-- =====================================================================
USE realty_agency;

INSERT INTO districts(name) VALUES
('Центральный'), ('Северный'), ('Южный'), ('Западный'), ('Восточный'), ('Пригород');

INSERT INTO property_types(name) VALUES
('Квартира'), ('Комната'), ('Дом'), ('Таунхаус'), ('Коммерческое помещение'), ('Земельный участок');

INSERT INTO realtors(full_name, phone, email, commission_percent, hire_date, is_active) VALUES
('Орлова Марина Сергеевна',   '+7 (901) 111-22-01', 'orlova@kluch.local',   3.00, '2021-03-15', 1),
('Беляев Дмитрий Андреевич',  '+7 (901) 111-22-02', 'belyaev@kluch.local',  2.50, '2022-06-01', 1),
('Кузнецова Елена Игоревна',  '+7 (901) 111-22-03', 'kuznetsova@kluch.local', 3.50, '2020-09-10', 1),
('Лебедев Артём Олегович',    '+7 (901) 111-22-04', 'lebedev@kluch.local',  2.00, '2024-01-20', 1),
('Соколова Ирина Павловна',   '+7 (901) 111-22-05', 'sokolova@kluch.local', 3.00, '2019-11-05', 0);

INSERT INTO clients(full_name, phone, email, notes) VALUES
('Иванов Сергей Петрович',     '+7 (916) 200-00-01', 'ivanov@mail.local',   'Продаёт квартиру, переезжает'),
('Петрова Анна Викторовна',    '+7 (916) 200-00-02', 'petrova@mail.local',  'Ищет 2-комн. в центре'),
('Сидоров Алексей Иванович',   '+7 (916) 200-00-03', NULL,                  'Собственник двух объектов'),
('Козлова Мария Андреевна',    '+7 (916) 200-00-04', 'kozlova@mail.local',  'Аренда на длительный срок'),
('Морозов Павел Николаевич',   '+7 (916) 200-00-05', 'morozov@mail.local',  'Инвестор'),
('Волкова Ольга Дмитриевна',   '+7 (916) 200-00-06', NULL,                  'Ищет дом за городом'),
('Новиков Игорь Валерьевич',   '+7 (916) 200-00-07', 'novikov@mail.local',  'Сдаёт офис'),
('Фёдорова Татьяна Юрьевна',   '+7 (916) 200-00-08', 'fedorova@mail.local', NULL),
('Егоров Константин Ильич',    '+7 (916) 200-00-09', NULL,                  'Ипотека одобрена'),
('Михайлова Светлана Олеговна','+7 (916) 200-00-10', 'mikh@mail.local',     'Студентка, аренда комнаты'),
('Захаров Роман Евгеньевич',   '+7 (916) 200-00-11', 'zakharov@mail.local', 'Продаёт участок'),
('Никитина Дарья Сергеевна',   '+7 (916) 200-00-12', NULL,                  'Ищет таунхаус');

-- offer_type: sale — продажа, rent — аренда (цена за месяц)
INSERT INTO properties(address, district_id, property_type_id, owner_id, realtor_id, offer_type,
                       price, area, rooms, floor, total_floors, description, status, created_at) VALUES
('ул. Ленина, д. 12, кв. 45',        1, 1, 1, 1, 'sale', 12500000, 64.5, 2, 5,  9,  'Ремонт 2022 года, вид на парк', 'active',   NOW() - INTERVAL 60 DAY),
('пр. Мира, д. 3, кв. 101',          1, 1, 3, 3, 'sale', 18900000, 82.0, 3, 12, 16, 'Панорамные окна, паркинг',      'active',   NOW() - INTERVAL 40 DAY),
('ул. Садовая, д. 7, кв. 8',         2, 1, 3, 2, 'rent',    45000, 38.0, 1, 2,  5,  'Мебель и техника',              'active',   NOW() - INTERVAL 35 DAY),
('ул. Гагарина, д. 21, комн. 3',     3, 2, 8, 4, 'rent',    18000, 14.0, 1, 3,  5,  'Комната в 3-комн. квартире',    'active',   NOW() - INTERVAL 20 DAY),
('пос. Лесной, ул. Сосновая, 4',     6, 3, 5, 1, 'sale', 23500000, 160.0, 5, NULL, 2, 'Участок 12 соток, баня',      'reserved', NOW() - INTERVAL 30 DAY),
('ул. Новая, д. 15, кв. 22',         5, 1, 1, 2, 'sale',  8700000, 41.3, 1, 7,  17, 'Новостройка, отделка white box','active',   NOW() - INTERVAL 15 DAY),
('пр. Победы, д. 50, пом. 1',        4, 5, 7, 3, 'rent',   120000, 95.0, 0, 1,  9,  'Отдельный вход, первая линия',  'active',   NOW() - INTERVAL 25 DAY),
('ул. Речная, д. 9, кв. 3',          3, 1, 5, 4, 'sale',  9900000, 52.0, 2, 1,  5,  'Требует ремонта',               'active',   NOW() - INTERVAL 10 DAY),
('КП «Ясное», таунхаус 14',          6, 4, 3, 1, 'sale', 15400000, 120.0, 4, NULL, 3, 'Свой двор, 2 машиноместа',   'active',   NOW() - INTERVAL 8 DAY),
('д. Ключи, уч. 47',                 6, 6, 11, 2, 'sale', 2100000, 1500.0, 0, NULL, NULL, 'ИЖС, электричество по границе', 'active', NOW() - INTERVAL 5 DAY),
('ул. Центральная, д. 1, кв. 77',    1, 1, 7, 3, 'rent',    75000, 70.0, 2, 9,  12, 'Бизнес-класс, консьерж',        'active',   NOW() - INTERVAL 3 DAY),
('ул. Заводская, д. 44, кв. 12',     5, 1, 8, 4, 'sale',  6300000, 33.0, 1, 4,  5,  'Рядом метро',                   'archived', NOW() - INTERVAL 90 DAY),
('ул. Школьная, д. 5, кв. 60',       2, 1, 5, 1, 'sale', 11200000, 58.7, 2, 8,  10, 'Двор без машин, школа рядом',   'active',   NOW() - INTERVAL 2 DAY),
('пр. Строителей, д. 18, кв. 4',     4, 1, 1, 3, 'rent',    38000, 31.0, 1, 2,  9,  'Можно с животными',             'active',   NOW() - INTERVAL 1 DAY);

INSERT INTO viewings(property_id, client_id, realtor_id, scheduled_at, status, feedback) VALUES
(1,  2, 1, NOW() - INTERVAL 55 DAY, 'done',      'Понравилась планировка'),
(1,  9, 1, NOW() - INTERVAL 54 DAY, 'done',      'Дорого'),
(3,  4, 2, NOW() - INTERVAL 33 DAY, 'done',      'Готова заехать сразу'),
(5,  6, 1, NOW() - INTERVAL 20 DAY, 'done',      'Внесён задаток'),
(2,  2, 3, NOW() - INTERVAL 7 DAY,  'cancelled', 'Клиент заболел'),
(2,  5, 3, NOW() + INTERVAL 1 DAY + INTERVAL 11 HOUR, 'planned', NULL),
(4, 10, 4, NOW() + INTERVAL 2 DAY + INTERVAL 15 HOUR, 'planned', NULL),
(9, 12, 1, NOW() + INTERVAL 3 DAY + INTERVAL 12 HOUR, 'planned', NULL),
(13, 9, 1, NOW() + INTERVAL 4 DAY + INTERVAL 17 HOUR, 'planned', NULL),
(7,  5, 3, NOW() - INTERVAL 2 DAY,  'done',      'Думает');

-- Сделки (комиссия = сумма × процент риэлтора)
INSERT INTO deals(property_id, client_id, realtor_id, deal_date, amount, commission, status) VALUES
(1, 2, 1, NOW() - INTERVAL 45 DAY, 12300000, 369000.00, 'completed'),
(3, 4, 2, NOW() - INTERVAL 30 DAY,    45000,   1125.00, 'completed'),
(5, 6, 1, NOW() - INTERVAL 18 DAY, 23000000, 690000.00, 'open');

-- Объекты 1 и 3 закрываем ПОСЛЕ вставки сделок
-- (иначе триггер trg_deals_before_insert не пропустит сделку по закрытому объекту)
UPDATE properties SET status = 'closed' WHERE id IN (1, 3);
