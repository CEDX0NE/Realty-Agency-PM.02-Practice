using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Services;
using RealtyAgency.DataAccess;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.Tests.Fakes;

namespace RealtyAgency.Tests.Unit;

/// <summary>Объекты: проверки при сохранении, поиск, снятие с продажи (US-04 – US-06).</summary>
[Trait("Category", "Unit")]
public class PropertyServiceTests
{
    private readonly TestWorld _w = new();
    private readonly PropertyService _service;

    public PropertyServiceTests()
    {
        _service = new PropertyService(_w.Properties);
    }

    private static Property NewInput() => new()
    {
        Address = "  ул. Новая, д. 1, кв. 5 ", DistrictId = 1, PropertyTypeId = 1, OwnerId = 1, RealtorId = 1,
        Price = 9_900_000m, Area = 52m, Rooms = 2, Floor = 3, TotalFloors = 9,
    };

    [Fact]
    [Trait("TC", "ТК-05")]
    public async Task SaveAsync_NewValidProperty_AddsActiveWithTrimmedAddress()
    {
        var p = NewInput();
        p.Status = PropertyStatus.Closed;

        await _service.SaveAsync(p);

        var saved = _w.Properties.Get(p.Id);
        Assert.Equal("ул. Новая, д. 1, кв. 5", saved.Address);
        Assert.Equal(PropertyStatus.Active, saved.Status);
    }

    [Fact]
    [Trait("TC", "ТК-06")]
    public async Task SaveAsync_SeveralInvalidFields_ReportsEveryError()
    {
        var p = NewInput();
        p.Address = "ул.";
        p.Price = 0;
        p.Area = -1;
        p.Floor = 10;

        var ex = await Assert.ThrowsAsync<ValidationException>(() => _service.SaveAsync(p));

        Assert.Equal(4, ex.Errors.Count);
    }

    [Theory]
    [InlineData(0, false)]
    [InlineData(0.01, true)]
    [InlineData(999_999_999_999.99, true)]
    public async Task SaveAsync_PriceBoundaries(decimal price, bool valid)
    {
        var p = NewInput();
        p.Price = price;

        var ex = await Record.ExceptionAsync(() => _service.SaveAsync(p));

        Assert.Equal(valid, ex is null);
    }

    [Fact]
    [Trait("TC", "ТК-07")]
    [Trait("Defect", "DEF-04")]
    public async Task SaveAsync_PriceAboveColumnLimit_ThrowsValidation()
    {
        var p = NewInput();
        p.Price = 1_000_000_000_000m;

        var ex = await Assert.ThrowsAsync<ValidationException>(() => _service.SaveAsync(p));

        Assert.Contains(ex.Errors, e => e.Contains("Цена"));
    }

    [Fact]
    public async Task SaveAsync_ExistingProperty_KeepsStatusFromDatabase()
    {
        var p = NewInput();
        p.Id = 2;
        p.Status = PropertyStatus.Active;

        await _service.SaveAsync(p);

        Assert.Equal(PropertyStatus.Reserved, _w.Properties.Get(2).Status);
    }

    [Fact]
    [Trait("TC", "ТК-08")]
    public async Task SearchAsync_MinPriceGreaterThanMax_ThrowsValidation()
    {
        var filter = new PropertyFilter { MinPrice = 10_000_000m, MaxPrice = 5_000_000m };

        await Assert.ThrowsAsync<ValidationException>(() => _service.SearchAsync(filter));
        Assert.Null(_w.Properties.LastFilter);
    }

    [Fact]
    public async Task SearchAsync_EqualMinAndMax_PassesFilterToRepository()
    {
        var filter = new PropertyFilter { MinPrice = 5_000_000m, MaxPrice = 5_000_000m };

        await _service.SearchAsync(filter);

        Assert.Same(filter, _w.Properties.LastFilter);
    }

    [Theory]
    [Trait("TC", "ТК-09")]
    [InlineData(1, PropertyStatus.Archived)]
    [InlineData(4, PropertyStatus.Active)]
    public async Task ToggleArchiveAsync_ActiveOrArchived_SwitchesStatus(int id, PropertyStatus expected)
    {
        await _service.ToggleArchiveAsync(id);

        Assert.Equal(expected, _w.Properties.Get(id).Status);
    }

    [Theory]
    [InlineData(2)]
    [InlineData(3)]
    public async Task ToggleArchiveAsync_ReservedOrClosed_ThrowsPropertyNotAvailable(int id)
    {
        await Assert.ThrowsAsync<PropertyNotAvailableException>(() => _service.ToggleArchiveAsync(id));
    }

    [Fact]
    public async Task DeleteAsync_PropertyWithDeals_ThrowsDeleteRestricted()
    {
        _w.Properties.FailWith = new DataAccessException("SIGNAL 45000", DbErrorKind.Rule);

        var ex = await Assert.ThrowsAsync<DeleteRestrictedException>(() => _service.DeleteAsync(1));

        Assert.Contains("Снять с продажи", ex.Message);
    }

    [Fact]
    public async Task SearchAsync_ConnectionLost_ThrowsDatabaseException()
    {
        _w.Properties.FailWith = new DataAccessException("Нет связи", DbErrorKind.Connection);

        await Assert.ThrowsAsync<DatabaseException>(() => _service.SearchAsync(new PropertyFilter()));
    }
}
