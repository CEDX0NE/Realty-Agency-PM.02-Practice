using Microsoft.EntityFrameworkCore;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Interfaces;

namespace RealtyAgency.DataAccess.Repositories;

/// <summary>Сделки. Смена статуса сделки и объекта — в одной транзакции.</summary>
public class DealRepository : RepositoryBase, IDealRepository
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="DealRepository"/>.</summary>
    /// <param name="factory">Фабрика контекстов EF Core.</param>
    public DealRepository(IDbContextFactory<RealtyDbContext> factory)
        : base(factory)
    {
    }

    /// <inheritdoc/>
    public Task<List<Deal>> GetAllAsync(DealStatus? status) =>
        QueryAsync("Список сделок", db =>
        {
            var q = db.Deals.AsNoTracking()
                .Include(d => d.Property)
                .Include(d => d.Client)
                .Include(d => d.Realtor)
                .AsQueryable();
            if (status is DealStatus st)
            {
                q = q.Where(d => d.Status == st);
            }

            return q.OrderByDescending(d => d.DealDate).ToListAsync();
        });

    /// <inheritdoc/>
    public Task<Deal?> GetByIdAsync(int id) =>
        QueryAsync($"Сделка ID={id}", db =>
            db.Deals.AsNoTracking().FirstOrDefaultAsync(d => d.Id == id));

    /// <inheritdoc/>
    public Task<bool> HasOpenDealAsync(int propertyId) =>
        QueryAsync($"Есть ли открытая сделка по объекту ID={propertyId}", db =>
            db.Deals.AnyAsync(d => d.PropertyId == propertyId && d.Status == DealStatus.Open));

    /// <inheritdoc/>
    public Task CreateAsync(Deal deal, PropertyStatus newPropertyStatus) =>
        ExecuteAsync($"Создание сделки по объекту ID={deal.PropertyId}", async db =>
        {
            await using var tx = await db.Database.BeginTransactionAsync();

            // 1. Сначала сделка (триггер trg_deals_before_insert проверит объект)
            db.Deals.Add(deal);
            await db.SaveChangesAsync();

            // 2. Потом статус объекта
            var property = await db.Properties.FindAsync(deal.PropertyId)
                           ?? throw NotFound("Объект", deal.PropertyId);
            property.Status = newPropertyStatus;
            await db.SaveChangesAsync();

            await tx.CommitAsync();
        });

    /// <inheritdoc/>
    public Task ChangeStatusAsync(int dealId, DealStatus status, PropertyStatus newPropertyStatus) =>
        ExecuteAsync($"Смена статуса сделки ID={dealId} на {status}", async db =>
        {
            await using var tx = await db.Database.BeginTransactionAsync();

            var deal = await db.Deals.FindAsync(dealId) ?? throw NotFound("Сделка", dealId);
            deal.Status = status;

            var property = await db.Properties.FindAsync(deal.PropertyId)
                           ?? throw NotFound("Объект", deal.PropertyId);
            property.Status = newPropertyStatus;

            await db.SaveChangesAsync();
            await tx.CommitAsync();
        });
}
