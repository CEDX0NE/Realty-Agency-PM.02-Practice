using System.Data;
using RealtyAgency.DataAccess;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Interfaces;

namespace RealtyAgency.Tests.Fakes;

// =====================================================================
//  Заглушки репозиториев для модульных тестов: данные хранятся в списках,
//  база данных не нужна. Через свойство FailWith можно имитировать
//  ошибку слоя доступа к данным (DataAccessException).
// =====================================================================

public abstract class FakeBase
{
    public DataAccessException? FailWith { get; set; }

    protected void ThrowIfFail()
    {
        if (FailWith is not null) throw FailWith;
    }
}

public sealed class FakeClientRepository : FakeBase, IClientRepository
{
    public List<Client> Items { get; } = new();

    public Task<List<Client>> GetAllAsync(string? search)
    {
        ThrowIfFail();
        var q = Items.AsEnumerable();
        if (!string.IsNullOrWhiteSpace(search))
            q = q.Where(c => c.FullName.Contains(search.Trim(), StringComparison.OrdinalIgnoreCase) || c.Phone.Contains(search.Trim()));
        return Task.FromResult(q.ToList());
    }

    public Task<Client?> GetByIdAsync(int id)
    {
        ThrowIfFail();
        return Task.FromResult(Items.FirstOrDefault(c => c.Id == id));
    }

    // Как в MySQL: телефон сравнивается как строка
    public Task<bool> PhoneExistsAsync(string phone, int excludeId) =>
        Task.FromResult(Items.Any(c => c.Phone == phone && c.Id != excludeId));

    public Task AddAsync(Client client)
    {
        ThrowIfFail();
        client.Id = Items.Count == 0 ? 1 : Items.Max(c => c.Id) + 1;
        Items.Add(client);
        return Task.CompletedTask;
    }

    public Task UpdateAsync(Client client)
    {
        ThrowIfFail();
        Items.RemoveAll(c => c.Id == client.Id);
        Items.Add(client);
        return Task.CompletedTask;
    }

    public Task DeleteAsync(int id)
    {
        ThrowIfFail();
        Items.RemoveAll(c => c.Id == id);
        return Task.CompletedTask;
    }
}

public sealed class FakeRealtorRepository : FakeBase, IRealtorRepository
{
    public List<Realtor> Items { get; } = new();

    public Task<List<Realtor>> GetAllAsync(bool onlyActive) =>
        Task.FromResult(Items.Where(r => !onlyActive || r.IsActive).ToList());

    public Task<Realtor?> GetByIdAsync(int id) => Task.FromResult(Items.FirstOrDefault(r => r.Id == id));

    public Task<bool> PhoneExistsAsync(string phone, int excludeId) =>
        Task.FromResult(Items.Any(r => r.Phone == phone && r.Id != excludeId));

    public Task AddAsync(Realtor realtor)
    {
        ThrowIfFail();
        realtor.Id = Items.Count + 1;
        Items.Add(realtor);
        return Task.CompletedTask;
    }

    public Task UpdateAsync(Realtor realtor)
    {
        ThrowIfFail();
        Items.RemoveAll(r => r.Id == realtor.Id);
        Items.Add(realtor);
        return Task.CompletedTask;
    }

    public Task DeleteAsync(int id)
    {
        ThrowIfFail();
        Items.RemoveAll(r => r.Id == id);
        return Task.CompletedTask;
    }
}

public sealed class FakePropertyRepository : FakeBase, IPropertyRepository
{
    public List<Property> Items { get; } = new();

    public PropertyFilter? LastFilter { get; private set; }

    public Task<List<Property>> SearchAsync(PropertyFilter filter)
    {
        ThrowIfFail();
        LastFilter = filter;
        return Task.FromResult(Items.ToList());
    }

    public Task<List<Property>> GetAvailableAsync() =>
        Task.FromResult(Items.Where(p => p.Status is PropertyStatus.Active or PropertyStatus.Reserved).ToList());

    public Task<Property?> GetByIdAsync(int id)
    {
        ThrowIfFail();
        var p = Items.FirstOrDefault(x => x.Id == id);
        // Репозиторий возвращает копию (как AsNoTracking), а не сам объект из «базы»
        return Task.FromResult(p is null ? null : Copy(p));
    }

    public Task AddAsync(Property property)
    {
        ThrowIfFail();
        property.Id = Items.Count == 0 ? 1 : Items.Max(p => p.Id) + 1;
        Items.Add(Copy(property));
        return Task.CompletedTask;
    }

    public Task UpdateAsync(Property property)
    {
        ThrowIfFail();
        Items.RemoveAll(p => p.Id == property.Id);
        Items.Add(Copy(property));
        return Task.CompletedTask;
    }

    public Task DeleteAsync(int id)
    {
        ThrowIfFail();
        Items.RemoveAll(p => p.Id == id);
        return Task.CompletedTask;
    }

    public Property Get(int id) => Items.Single(p => p.Id == id);

    private static Property Copy(Property p) => new()
    {
        Id = p.Id, Address = p.Address, DistrictId = p.DistrictId, PropertyTypeId = p.PropertyTypeId,
        OwnerId = p.OwnerId, RealtorId = p.RealtorId, OfferType = p.OfferType, Price = p.Price, Area = p.Area,
        Rooms = p.Rooms, Floor = p.Floor, TotalFloors = p.TotalFloors, Description = p.Description,
        Status = p.Status, CreatedAt = p.CreatedAt,
    };
}

public sealed class FakeDealRepository : FakeBase, IDealRepository
{
    private readonly FakePropertyRepository _properties;

    public FakeDealRepository(FakePropertyRepository properties) => _properties = properties;

    public List<Deal> Items { get; } = new();

    public Task<List<Deal>> GetAllAsync(DealStatus? status) =>
        Task.FromResult(Items.Where(d => status is null || d.Status == status).ToList());

    public Task<Deal?> GetByIdAsync(int id) => Task.FromResult(Items.FirstOrDefault(d => d.Id == id));

    public Task<bool> HasOpenDealAsync(int propertyId) =>
        Task.FromResult(Items.Any(d => d.PropertyId == propertyId && d.Status == DealStatus.Open));

    public Task CreateAsync(Deal deal, PropertyStatus newPropertyStatus)
    {
        ThrowIfFail();
        deal.Id = Items.Count + 1;
        Items.Add(deal);
        _properties.Get(deal.PropertyId).Status = newPropertyStatus;
        return Task.CompletedTask;
    }

    public Task ChangeStatusAsync(int dealId, DealStatus status, PropertyStatus newPropertyStatus)
    {
        ThrowIfFail();
        var deal = Items.Single(d => d.Id == dealId);
        deal.Status = status;
        _properties.Get(deal.PropertyId).Status = newPropertyStatus;
        return Task.CompletedTask;
    }
}

public sealed class FakeViewingRepository : FakeBase, IViewingRepository
{
    public List<Viewing> Items { get; } = new();

    public bool Conflict { get; set; }

    public Task<List<Viewing>> GetAllAsync(ViewingStatus? status) =>
        Task.FromResult(Items.Where(v => status is null || v.Status == status).ToList());

    public Task<Viewing?> GetByIdAsync(int id) => Task.FromResult(Items.FirstOrDefault(v => v.Id == id));

    public Task<bool> HasRealtorConflictAsync(int realtorId, DateTime time, TimeSpan window, int excludeId) =>
        Task.FromResult(Conflict);

    public Task AddAsync(Viewing viewing)
    {
        viewing.Id = Items.Count + 1;
        Items.Add(viewing);
        return Task.CompletedTask;
    }

    public Task UpdateAsync(Viewing viewing)
    {
        Items.RemoveAll(v => v.Id == viewing.Id);
        Items.Add(viewing);
        return Task.CompletedTask;
    }

    public Task DeleteAsync(int id)
    {
        Items.RemoveAll(v => v.Id == id);
        return Task.CompletedTask;
    }
}

public sealed class FakeReportRepository : FakeBase, IReportRepository
{
    public int Calls { get; private set; }

    public Task<DataTable> GetDealsByPeriodAsync(DateTime from, DateTime to)
    {
        Calls++;
        return Task.FromResult(new DataTable());
    }

    public Task<DataTable> GetRealtorPerformanceAsync(DateTime from, DateTime to)
    {
        Calls++;
        return Task.FromResult(new DataTable());
    }

    public Task<DataTable> GetMarketByDistrictAsync() => Task.FromResult(new DataTable());

    public Task<DashboardStats> GetDashboardStatsAsync()
    {
        ThrowIfFail();
        return Task.FromResult(new DashboardStats(1, 2, 3, 4m, 5, 6));
    }
}

/// <summary>Готовый набор данных для тестов сделок и показов.</summary>
public sealed class TestWorld
{
    public TestWorld()
    {
        Deals = new FakeDealRepository(Properties);
        Clients.Items.AddRange(new[]
        {
            new Client { Id = 1, FullName = "Иванов Сергей Петрович", Phone = "+7 (916) 200-00-01" },
            new Client { Id = 2, FullName = "Петрова Анна Викторовна", Phone = "+7 (916) 200-00-02" },
        });
        Realtors.Items.AddRange(new[]
        {
            new Realtor { Id = 1, FullName = "Орлова Марина Сергеевна", Phone = "+7 (901) 111-22-01", CommissionPercent = 3m },
            new Realtor { Id = 2, FullName = "Соколова Ирина Павловна", Phone = "+7 (901) 111-22-05", CommissionPercent = 3m, IsActive = false },
        });
        Properties.Items.AddRange(new[]
        {
            NewProperty(1, PropertyStatus.Active, 12_500_000m),
            NewProperty(2, PropertyStatus.Reserved, 18_900_000m),
            NewProperty(3, PropertyStatus.Closed, 45_000m),
            NewProperty(4, PropertyStatus.Archived, 6_300_000m),
        });
    }

    public FakeClientRepository Clients { get; } = new();

    public FakeRealtorRepository Realtors { get; } = new();

    public FakePropertyRepository Properties { get; } = new();

    public FakeDealRepository Deals { get; }

    public FakeViewingRepository Viewings { get; } = new();

    public static Property NewProperty(int id, PropertyStatus status, decimal price) => new()
    {
        Id = id, Address = $"ул. Тестовая, д. {id}", DistrictId = 1, PropertyTypeId = 1, OwnerId = 1, RealtorId = 1,
        OfferType = OfferType.Sale, Price = price, Area = 50m, Rooms = 2, Status = status,
    };

    public static Deal NewDeal(int propertyId = 1, decimal amount = 12_300_000m) => new()
    {
        PropertyId = propertyId, ClientId = 2, RealtorId = 1, Amount = amount, DealDate = DateTime.Today,
    };
}

public sealed class FakeReferenceRepository : IReferenceRepository
{
    public int Calls { get; private set; }

    public Task<List<District>> GetDistrictsAsync()
    {
        Calls++;
        return Task.FromResult(new List<District> { new() { Id = 1, Name = "Центральный" } });
    }

    public Task<List<PropertyType>> GetPropertyTypesAsync()
    {
        Calls++;
        return Task.FromResult(new List<PropertyType> { new() { Id = 1, Name = "Квартира" } });
    }
}
