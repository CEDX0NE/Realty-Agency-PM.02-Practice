using Microsoft.EntityFrameworkCore;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Interfaces;

namespace RealtyAgency.DataAccess.Repositories;

/// <summary>Риэлторы.</summary>
public class RealtorRepository : RepositoryBase, IRealtorRepository
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="RealtorRepository"/>.</summary>
    /// <param name="factory">Фабрика контекстов EF Core.</param>
    public RealtorRepository(IDbContextFactory<RealtyDbContext> factory)
        : base(factory)
    {
    }

    /// <inheritdoc/>
    public Task<List<Realtor>> GetAllAsync(bool onlyActive) =>
        QueryAsync("Список риэлторов", db =>
        {
            var q = db.Realtors.AsNoTracking();
            if (onlyActive)
            {
                q = q.Where(r => r.IsActive);
            }

            return q.OrderBy(r => r.FullName).ToListAsync();
        });

    /// <inheritdoc/>
    public Task<Realtor?> GetByIdAsync(int id) =>
        QueryAsync($"Риэлтор ID={id}", db =>
            db.Realtors.AsNoTracking().FirstOrDefaultAsync(r => r.Id == id));

    /// <inheritdoc/>
    public Task<bool> PhoneExistsAsync(string phone, int excludeId) =>
        QueryAsync("Проверка телефона риэлтора", db =>
            db.Realtors.AnyAsync(r => r.Phone == phone && r.Id != excludeId));

    /// <inheritdoc/>
    public Task AddAsync(Realtor realtor) =>
        ExecuteAsync($"Добавление риэлтора «{realtor.FullName}»", async db =>
        {
            db.Realtors.Add(realtor);
            await db.SaveChangesAsync();
        });

    /// <inheritdoc/>
    public Task UpdateAsync(Realtor realtor) =>
        ExecuteAsync($"Изменение риэлтора ID={realtor.Id}", async db =>
        {
            var existing = await db.Realtors.FindAsync(realtor.Id) ?? throw NotFound("Риэлтор", realtor.Id);
            db.Entry(existing).CurrentValues.SetValues(realtor);
            await db.SaveChangesAsync();
        });

    /// <inheritdoc/>
    public Task DeleteAsync(int id) =>
        ExecuteAsync($"Удаление риэлтора ID={id}", async db =>
        {
            var existing = await db.Realtors.FindAsync(id) ?? throw NotFound("Риэлтор", id);
            db.Realtors.Remove(existing);
            await db.SaveChangesAsync();
        });
}
