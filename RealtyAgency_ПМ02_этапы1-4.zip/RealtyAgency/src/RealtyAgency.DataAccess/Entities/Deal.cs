namespace RealtyAgency.DataAccess.Entities;

/// <summary>Сделка купли-продажи или аренды (таблица deals).</summary>
public class Deal
{
    /// <summary>Получает или задает код сделки.</summary>
    public int Id { get; set; }

    /// <summary>Получает или задает код объекта.</summary>
    public int PropertyId { get; set; }

    /// <summary>Получает или задает код покупателя или арендатора.</summary>
    public int ClientId { get; set; }

    /// <summary>Получает или задает код риэлтора.</summary>
    public int RealtorId { get; set; }

    /// <summary>Получает или задает дату сделки.</summary>
    public DateTime DealDate { get; set; } = DateTime.Now;

    /// <summary>Получает или задает сумму сделки, ₽.</summary>
    public decimal Amount { get; set; }

    /// <summary>Получает или задает комиссию агентства, ₽ (рассчитывается сервисом).</summary>
    public decimal Commission { get; set; }

    /// <summary>Получает или задает статус: открыта, завершена, отменена.</summary>
    public DealStatus Status { get; set; } = DealStatus.Open;

    /// <summary>Получает или задает объект.</summary>
    public Property? Property { get; set; }

    /// <summary>Получает или задает покупателя или арендатора.</summary>
    public Client? Client { get; set; }

    /// <summary>Получает или задает риэлтора.</summary>
    public Realtor? Realtor { get; set; }
}
