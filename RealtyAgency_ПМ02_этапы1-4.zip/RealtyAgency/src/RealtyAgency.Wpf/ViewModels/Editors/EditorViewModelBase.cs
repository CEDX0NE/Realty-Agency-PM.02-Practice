using System.Globalization;
using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Logging;
using RealtyAgency.Wpf.Infrastructure;

namespace RealtyAgency.Wpf.ViewModels.Editors;

/// <summary>
/// База для форм добавления/редактирования. Окно EditorWindow одно на все
/// формы: внутри него показывается нужный UserControl (по DataTemplate).
/// </summary>
public abstract class EditorViewModelBase : ObservableObject
{
    protected EditorViewModelBase()
    {
        SaveCommand = new AsyncRelayCommand(SaveAsync);
    }

    public abstract string Title { get; }

    public virtual string SaveText => "Сохранить";

    public virtual double FormWidth => 520;

    private string? _errorText;

    /// <summary>Получает или задает текст ошибок под формой (красная плашка).</summary>
    public string? ErrorText { get => _errorText; set => Set(ref _errorText, value); }

    public AsyncRelayCommand SaveCommand { get; }

    /// <summary>Окно подписывается и закрывается с DialogResult = true/false.</summary>
    public event Action<bool>? CloseRequested;

    /// <summary>Загрузка списков для ComboBox (вызывается до показа окна).</summary>
    public virtual Task LoadAsync() => Task.CompletedTask;

    /// <summary>
    /// Собрать сущность из полей формы и передать в сервис.
    /// Ошибки разбора чисел/дат складываются в parseErrors — тогда сервис не вызывается.
    /// </summary>
    protected abstract Task SaveCoreAsync(List<string> parseErrors);

    private async Task SaveAsync()
    {
        ErrorText = null;
        var parseErrors = new List<string>();
        try
        {
            await SaveCoreAsync(parseErrors);
            if (parseErrors.Count > 0)
            {
                ErrorText = "• " + string.Join("\n• ", parseErrors);
                return;
            }

            CloseRequested?.Invoke(true);
        }
        catch (ValidationException ex)
        {
            ErrorText = "• " + string.Join("\n• ", ex.Errors);
        }
        catch (RealtyException ex)
        {
            ErrorText = ex.Message;
        }
        finally
        {
            if (ErrorText is not null)
            {
                AppLog.Warn("UI", $"{Title}: не сохранено — {ErrorText.Replace('\n', ' ')}");
            }
        }
    }

    // ---------- Разбор чисел из текстовых полей ----------

    /// <summary>«12 500 000,50» → 12500000.50; пусто → null.</summary>
    protected static decimal? ParseDecimal(string? text, string field, List<string> errors, bool required = true)
    {
        if (NumberText.Normalize(text).Length == 0)
        {
            if (required)
            {
                errors.Add($"Заполните поле «{field}»");
            }

            return null;
        }

        if (NumberText.TryParseDecimal(text, out var value))
        {
            return value;
        }

        errors.Add($"Поле «{field}»: введите число");
        return null;
    }

    protected static int? ParseInt(string? text, string field, List<string> errors, bool required = true)
    {
        if (NumberText.Normalize(text).Length == 0)
        {
            if (required)
            {
                errors.Add($"Заполните поле «{field}»");
            }

            return null;
        }

        if (NumberText.TryParseInt(text, out var value))
        {
            return value;
        }

        errors.Add($"Поле «{field}»: введите целое число");
        return null;
    }

    protected static string Format(decimal value) => value.ToString("0.##", CultureInfo.InvariantCulture);
}
