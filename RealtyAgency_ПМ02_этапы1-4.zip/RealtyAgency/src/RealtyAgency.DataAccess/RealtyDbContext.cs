using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.DataAccess;

/// <summary>
/// Контекст Entity Framework Core для базы realty_agency (MySQL).
/// Настраивается в App.xaml.cs через AddDbContextFactory + UseMySql.
/// </summary>
public class RealtyDbContext : DbContext
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="RealtyDbContext"/>.</summary>
    /// <param name="options">Параметры подключения (UseMySql).</param>
    public RealtyDbContext(DbContextOptions<RealtyDbContext> options)
        : base(options)
    {
    }

    /// <summary>Получает районы.</summary>
    public DbSet<District> Districts => Set<District>();

    /// <summary>Получает типы недвижимости.</summary>
    public DbSet<PropertyType> PropertyTypes => Set<PropertyType>();

    /// <summary>Получает риэлторов.</summary>
    public DbSet<Realtor> Realtors => Set<Realtor>();

    /// <summary>Получает клиентов.</summary>
    public DbSet<Client> Clients => Set<Client>();

    /// <summary>Получает объекты.</summary>
    public DbSet<Property> Properties => Set<Property>();

    /// <summary>Получает показы.</summary>
    public DbSet<Viewing> Viewings => Set<Viewing>();

    /// <summary>Получает сделки.</summary>
    public DbSet<Deal> Deals => Set<Deal>();

    /// <inheritdoc/>
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        ConfigureTables(modelBuilder);
        ConfigureColumns(modelBuilder);
        ConfigureEnums(modelBuilder);
        ConfigureRelations(modelBuilder);
    }

    /// <summary>Имена таблиц MySQL.</summary>
    private static void ConfigureTables(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<District>().ToTable("districts");
        modelBuilder.Entity<PropertyType>().ToTable("property_types");
        modelBuilder.Entity<Realtor>().ToTable("realtors");
        modelBuilder.Entity<Client>().ToTable("clients");
        modelBuilder.Entity<Property>().ToTable("properties");
        modelBuilder.Entity<Viewing>().ToTable("viewings");
        modelBuilder.Entity<Deal>().ToTable("deals");
    }

    /// <summary>Длины строк, точность чисел, уникальные индексы.</summary>
    private static void ConfigureColumns(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<District>().Property(x => x.Name).HasMaxLength(100).IsRequired();
        modelBuilder.Entity<PropertyType>().Property(x => x.Name).HasMaxLength(100).IsRequired();

        modelBuilder.Entity<Realtor>().Property(x => x.FullName).HasMaxLength(200).IsRequired();
        modelBuilder.Entity<Realtor>().Property(x => x.Phone).HasMaxLength(20).IsRequired();
        modelBuilder.Entity<Realtor>().Property(x => x.CommissionPercent).HasPrecision(5, 2);
        modelBuilder.Entity<Realtor>().HasIndex(x => x.Phone).IsUnique();

        modelBuilder.Entity<Client>().Property(x => x.FullName).HasMaxLength(200).IsRequired();
        modelBuilder.Entity<Client>().Property(x => x.Phone).HasMaxLength(20).IsRequired();
        modelBuilder.Entity<Client>().HasIndex(x => x.Phone).IsUnique();

        modelBuilder.Entity<Property>().Property(x => x.Address).HasMaxLength(300).IsRequired();
        modelBuilder.Entity<Property>().Property(x => x.Price).HasPrecision(14, 2);
        modelBuilder.Entity<Property>().Property(x => x.Area).HasPrecision(8, 2);

        modelBuilder.Entity<Deal>().Property(x => x.Amount).HasPrecision(14, 2);
        modelBuilder.Entity<Deal>().Property(x => x.Commission).HasPrecision(14, 2);
    }

    /// <summary>ENUM-колонки MySQL ↔ enum C#: в БД хранятся строки в нижнем регистре.</summary>
    private static void ConfigureEnums(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Property>().Property(x => x.OfferType).HasConversion(LowerEnum<OfferType>());
        modelBuilder.Entity<Property>().Property(x => x.Status).HasConversion(LowerEnum<PropertyStatus>());
        modelBuilder.Entity<Viewing>().Property(x => x.Status).HasConversion(LowerEnum<ViewingStatus>());
        modelBuilder.Entity<Deal>().Property(x => x.Status).HasConversion(LowerEnum<DealStatus>());
    }

    /// <summary>Связи; удаление — RESTRICT (показы объекта — CASCADE), как в 01_schema.sql.</summary>
    private static void ConfigureRelations(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Property>().HasOne(x => x.District).WithMany(x => x.Properties)
            .HasForeignKey(x => x.DistrictId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Property>().HasOne(x => x.PropertyType).WithMany(x => x.Properties)
            .HasForeignKey(x => x.PropertyTypeId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Property>().HasOne(x => x.Owner).WithMany(x => x.OwnedProperties)
            .HasForeignKey(x => x.OwnerId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Property>().HasOne(x => x.Realtor).WithMany(x => x.Properties)
            .HasForeignKey(x => x.RealtorId).OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Viewing>().HasOne(x => x.Property).WithMany(x => x.Viewings)
            .HasForeignKey(x => x.PropertyId).OnDelete(DeleteBehavior.Cascade);
        modelBuilder.Entity<Viewing>().HasOne(x => x.Client).WithMany(x => x.Viewings)
            .HasForeignKey(x => x.ClientId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Viewing>().HasOne(x => x.Realtor).WithMany(x => x.Viewings)
            .HasForeignKey(x => x.RealtorId).OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Deal>().HasOne(x => x.Property).WithMany(x => x.Deals)
            .HasForeignKey(x => x.PropertyId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Deal>().HasOne(x => x.Client).WithMany(x => x.Deals)
            .HasForeignKey(x => x.ClientId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Deal>().HasOne(x => x.Realtor).WithMany(x => x.Deals)
            .HasForeignKey(x => x.RealtorId).OnDelete(DeleteBehavior.Restrict);
    }

    /// <summary>Конвертер enum &lt;-&gt; строка в нижнем регистре.</summary>
    private static ValueConverter<TEnum, string> LowerEnum<TEnum>()
        where TEnum : struct, Enum =>
        new(v => v.ToString().ToLowerInvariant(), s => Enum.Parse<TEnum>(s, true));
}
