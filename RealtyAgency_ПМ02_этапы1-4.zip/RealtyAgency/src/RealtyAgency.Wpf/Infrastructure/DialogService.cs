using System.Windows;
using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.Wpf.ViewModels.Editors;
using RealtyAgency.Wpf.Views;

namespace RealtyAgency.Wpf.Infrastructure;

/// <summary>
/// Окна и сообщения. ViewModel не создаёт окна сам — он просит об этом сервис,
/// поэтому логику ViewModel можно тестировать без интерфейса.
/// </summary>
public interface IDialogService
{
    /// <summary>Открыть форму редактирования. true — пользователь сохранил данные.</summary>
    Task<bool> ShowEditorAsync(EditorViewModelBase editor);

    bool Confirm(string message, string title = "Подтверждение");

    void Error(string message, string title = "Ошибка");

    void Info(string message, string title = "Готово");

    string? AskSavePath(string defaultName, string filter);
}

public sealed class DialogService : IDialogService
{
    private static Window? Owner =>
        Application.Current.Windows.OfType<Window>().FirstOrDefault(w => w.IsActive)
        ?? Application.Current.MainWindow;

    public async Task<bool> ShowEditorAsync(EditorViewModelBase editor)
    {
        // Сначала загружаем списки для выпадающих полей
        try
        {
            await editor.LoadAsync();
        }
        catch (RealtyException ex)
        {
            Error(ex.Message);
            return false;
        }

        var window = new EditorWindow { DataContext = editor };
        if (Owner is { } owner && owner.IsLoaded)
        {
            window.Owner = owner;
        }

        return window.ShowDialog() == true;
    }

    public bool Confirm(string message, string title = "Подтверждение") =>
        Show(message, title, MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;

    public void Error(string message, string title = "Ошибка") =>
        Show(message, title, MessageBoxButton.OK, MessageBoxImage.Warning);

    public void Info(string message, string title = "Готово") =>
        Show(message, title, MessageBoxButton.OK, MessageBoxImage.Information);

    public string? AskSavePath(string defaultName, string filter)
    {
        var dlg = new Microsoft.Win32.SaveFileDialog { FileName = defaultName, Filter = filter };
        var owner = Owner;
        var ok = owner is null ? dlg.ShowDialog() : dlg.ShowDialog(owner);
        return ok == true ? dlg.FileName : null;
    }

    private static MessageBoxResult Show(string text, string title, MessageBoxButton buttons, MessageBoxImage icon)
    {
        var owner = Owner;
        return owner is null
            ? MessageBox.Show(text, title, buttons, icon)
            : MessageBox.Show(owner, text, title, buttons, icon);
    }
}
