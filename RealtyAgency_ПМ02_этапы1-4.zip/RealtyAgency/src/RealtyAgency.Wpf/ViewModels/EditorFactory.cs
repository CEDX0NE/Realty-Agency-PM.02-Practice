using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.Wpf.ViewModels.Editors;

namespace RealtyAgency.Wpf.ViewModels;

/// <summary>Создаёт ViewModel-и форм редактирования с нужными сервисами.</summary>
public sealed class EditorFactory
{
    private readonly IPropertyService _properties;
    private readonly IClientService _clients;
    private readonly IRealtorService _realtors;
    private readonly IViewingService _viewings;
    private readonly IDealService _deals;
    private readonly IReferenceService _references;

    public EditorFactory(
        IPropertyService properties,
        IClientService clients,
        IRealtorService realtors,
        IViewingService viewings,
        IDealService deals,
        IReferenceService references)
    {
        _properties = properties;
        _clients = clients;
        _realtors = realtors;
        _viewings = viewings;
        _deals = deals;
        _references = references;
    }

    public PropertyEditorViewModel PropertyEditor(Property? existing) =>
        new(_properties, _references, _clients, _realtors, existing);

    public ClientEditorViewModel ClientEditor(Client? existing) => new(_clients, existing);

    public RealtorEditorViewModel RealtorEditor(Realtor? existing) => new(_realtors, existing);

    public ViewingEditorViewModel ViewingEditor(Viewing? existing, int? propertyId = null) =>
        new(_viewings, _properties, _clients, _realtors, existing, propertyId);

    public DealEditorViewModel DealEditor(int? propertyId = null) =>
        new(_deals, _properties, _clients, _realtors, propertyId);
}
