using System.Text.RegularExpressions;
using RealtyAgency.BusinessLogic.Exceptions;

namespace RealtyAgency.BusinessLogic.Services;

/// <summary>Сборщик ошибок валидации: проверяем все поля, потом бросаем одно исключение.</summary>
public sealed class Validator
{
    private static readonly Regex PhoneRx = new(@"^\+?[\d\s\-\(\)]{10,20}$");

    private static readonly Regex EmailRx = new(@"^[^@\s]+@[^@\s]+\.[^@\s]+$");

    private readonly List<string> _errors = new();

    /// <summary>Проверяет, что строка похожа на телефон: допустимые символы и не меньше 10 цифр.</summary>
    /// <param name="s">Строка.</param>
    /// <returns><see langword="true"/>, если это телефон.</returns>
    public static bool IsPhone(string? s) =>
        !string.IsNullOrWhiteSpace(s) && PhoneRx.IsMatch(s.Trim()) && s.Count(char.IsDigit) >= 10;

    /// <summary>Проверяет e-mail; пустое значение допустимо (поле необязательное).</summary>
    /// <param name="s">Строка.</param>
    /// <returns><see langword="true"/>, если адрес пустой или корректный.</returns>
    public static bool IsEmailOrEmpty(string? s) =>
        string.IsNullOrWhiteSpace(s) || EmailRx.IsMatch(s.Trim());

    /// <summary>Обрезает пробелы; пустую строку заменяет на <see langword="null"/>.</summary>
    /// <param name="s">Строка.</param>
    /// <returns>Очищенная строка или <see langword="null"/>.</returns>
    public static string? Clean(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

    /// <summary>
    /// Приводит российский номер к единому виду «+7 (916) 200-00-01»:
    /// «89162000001», «+79162000001» и «8 (916) 200-00-01» — один и тот же телефон.
    /// Номера другого формата возвращаются без изменений (только Trim).
    /// </summary>
    /// <param name="phone">Телефон в любом формате.</param>
    /// <returns>Телефон в едином формате.</returns>
    public static string NormalizePhone(string phone)
    {
        var digits = new string(phone.Where(char.IsDigit).ToArray());
        if (digits.Length == 11 && (digits[0] == '7' || digits[0] == '8'))
        {
            digits = digits[1..];
        }

        if (digits.Length != 10)
        {
            return phone.Trim();
        }

        return $"+7 ({digits[..3]}) {digits[3..6]}-{digits[6..8]}-{digits[8..]}";
    }

    /// <summary>Добавляет ошибку, если условие не выполнено.</summary>
    /// <param name="condition">Условие корректности.</param>
    /// <param name="error">Текст ошибки.</param>
    /// <returns>Этот же сборщик (для цепочки вызовов).</returns>
    public Validator Require(bool condition, string error)
    {
        if (!condition)
        {
            _errors.Add(error);
        }

        return this;
    }

    /// <summary>Бросает <see cref="ValidationException"/>, если найдена хотя бы одна ошибка.</summary>
    public void ThrowIfInvalid()
    {
        if (_errors.Count > 0)
        {
            throw new ValidationException(_errors);
        }
    }
}
