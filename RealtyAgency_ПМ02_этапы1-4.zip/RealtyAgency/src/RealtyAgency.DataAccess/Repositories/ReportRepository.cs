using System.Data;
using System.Diagnostics;
using System.Globalization;
using MySqlConnector;
using RealtyAgency.DataAccess.Interfaces;

namespace RealtyAgency.DataAccess.Repositories;

/// <summary>
/// Отчёты через «чистый» ADO.NET: MySqlConnection → MySqlCommand → MySqlDataReader.
/// Все значения от пользователя передаются ПАРАМЕТРАМИ (@from, @to) —
/// это защита от SQL-инъекций.
/// </summary>
public class ReportRepository : IReportRepository
{
    private readonly string _connectionString;

    /// <summary>Инициализирует новый экземпляр класса <see cref="ReportRepository"/>.</summary>
    /// <param name="settings">Настройки подключения.</param>
    public ReportRepository(DbSettings settings) => _connectionString = settings.ConnectionString;

    /// <inheritdoc/>
    public Task<DataTable> GetDealsByPeriodAsync(DateTime dateFrom, DateTime dateTo) =>
        QueryTableAsync(
            "Отчёт: сделки за период",
            """
            SELECT DATE_FORMAT(dl.deal_date, '%d.%m.%Y')         AS `Дата`,
                   p.address                                     AS `Объект`,
                   IF(p.offer_type = 'sale', 'Продажа', 'Аренда') AS `Тип`,
                   cl.full_name                                  AS `Клиент`,
                   r.full_name                                   AS `Риэлтор`,
                   dl.amount                                     AS `Сумма ₽`,
                   dl.commission                                 AS `Комиссия ₽`,
                   CASE dl.status WHEN 'open' THEN 'Открыта'
                                  WHEN 'completed' THEN 'Завершена'
                                  ELSE 'Отменена' END            AS `Статус`
            FROM deals dl
            JOIN properties p  ON p.id  = dl.property_id
            JOIN clients    cl ON cl.id = dl.client_id
            JOIN realtors   r  ON r.id  = dl.realtor_id
            WHERE dl.deal_date >= @from AND dl.deal_date < @to
            ORDER BY dl.deal_date;
            """,
            new MySqlParameter("@from", dateFrom.Date),
            new MySqlParameter("@to", dateTo.Date.AddDays(1)));

    /// <inheritdoc/>
    public Task<DataTable> GetRealtorPerformanceAsync(DateTime dateFrom, DateTime dateTo) =>
        QueryTableAsync(
            "Отчёт: эффективность риэлторов",
            """
            SELECT r.full_name AS `Риэлтор`,
                   (SELECT COUNT(*) FROM viewings v
                     WHERE v.realtor_id = r.id AND v.status = 'done'
                       AND v.scheduled_at >= @from AND v.scheduled_at < @to)      AS `Показов проведено`,
                   (SELECT COUNT(*) FROM deals d
                     WHERE d.realtor_id = r.id AND d.status = 'completed'
                       AND d.deal_date >= @from AND d.deal_date < @to)            AS `Сделок закрыто`,
                   (SELECT COALESCE(SUM(d.amount), 0) FROM deals d
                     WHERE d.realtor_id = r.id AND d.status = 'completed'
                       AND d.deal_date >= @from AND d.deal_date < @to)            AS `Оборот ₽`,
                   (SELECT COALESCE(SUM(d.commission), 0) FROM deals d
                     WHERE d.realtor_id = r.id AND d.status = 'completed'
                       AND d.deal_date >= @from AND d.deal_date < @to)            AS `Комиссия ₽`
            FROM realtors r
            -- уволенные риэлторы попадают в отчёт, если у них были показы или сделки в периоде
            WHERE r.is_active = 1
               OR EXISTS (SELECT 1 FROM deals d
                           WHERE d.realtor_id = r.id AND d.deal_date >= @from AND d.deal_date < @to)
               OR EXISTS (SELECT 1 FROM viewings v
                           WHERE v.realtor_id = r.id AND v.scheduled_at >= @from AND v.scheduled_at < @to)
            ORDER BY `Комиссия ₽` DESC;
            """,
            new MySqlParameter("@from", dateFrom.Date),
            new MySqlParameter("@to", dateTo.Date.AddDays(1)));

    /// <inheritdoc/>
    public Task<DataTable> GetMarketByDistrictAsync() =>
        QueryTableAsync(
            "Отчёт: рынок по районам",
            """
            SELECT d.name                                    AS `Район`,
                   t.name                                    AS `Тип`,
                   IF(p.offer_type = 'sale', 'Продажа', 'Аренда') AS `Предложение`,
                   COUNT(*)                                  AS `Объектов`,
                   ROUND(AVG(p.price), 0)                    AS `Средняя цена ₽`,
                   ROUND(AVG(p.price / p.area), 0)           AS `Цена за м² ₽`
            FROM properties p
            JOIN districts d      ON d.id = p.district_id
            JOIN property_types t ON t.id = p.property_type_id
            WHERE p.status IN ('active', 'reserved')
            GROUP BY d.name, t.name, p.offer_type
            ORDER BY d.name, t.name;
            """);

    /// <inheritdoc/>
    public async Task<DashboardStats> GetDashboardStatsAsync()
    {
        var table = await QueryTableAsync(
            "Показатели главной страницы",
            """
            SELECT
              (SELECT COUNT(*) FROM properties WHERE status = 'active')                         AS active_properties,
              (SELECT COUNT(*) FROM deals WHERE status = 'open')                                AS open_deals,
              (SELECT COUNT(*) FROM deals WHERE status = 'completed' AND deal_date >= @month)    AS deals_month,
              (SELECT COALESCE(SUM(commission), 0) FROM deals
                WHERE status = 'completed' AND deal_date >= @month)                             AS commission_month,
              (SELECT COUNT(*) FROM viewings WHERE status = 'planned' AND scheduled_at >= @now) AS upcoming_viewings,
              (SELECT COUNT(*) FROM clients)                                                    AS clients_count;
            """,
            new MySqlParameter("@month", new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1)),
            new MySqlParameter("@now", DateTime.Now));

        var row = table.Rows[0];
        return new DashboardStats(
            Convert.ToInt32(row["active_properties"], CultureInfo.InvariantCulture),
            Convert.ToInt32(row["open_deals"], CultureInfo.InvariantCulture),
            Convert.ToInt32(row["deals_month"], CultureInfo.InvariantCulture),
            Convert.ToDecimal(row["commission_month"], CultureInfo.InvariantCulture),
            Convert.ToInt32(row["upcoming_viewings"], CultureInfo.InvariantCulture),
            Convert.ToInt32(row["clients_count"], CultureInfo.InvariantCulture));
    }

    /// <summary>Выполняет SELECT и возвращает результат в виде DataTable.</summary>
    private async Task<DataTable> QueryTableAsync(string operation, string sql, params MySqlParameter[] parameters)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            await using var connection = new MySqlConnection(_connectionString);
            await using var command = new MySqlCommand(sql, connection);
            command.Parameters.AddRange(parameters);

            await connection.OpenAsync();
            await using var reader = await command.ExecuteReaderAsync();

            var table = new DataTable();
            table.Load(reader);

            Trace.WriteLine($"[DAL] {operation}: {table.Rows.Count} строк ({sw.ElapsedMilliseconds} мс)");
            return table;
        }
        catch (MySqlException ex)
        {
            var translated = DbErrorTranslator.Translate(ex);
            Trace.WriteLine($"[DAL][ERROR] {operation}: {ex.Message}");
            throw translated;
        }
    }
}
