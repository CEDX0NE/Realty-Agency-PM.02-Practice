# Риэлторское агентство «Ключ» — учебная практика ПМ.02 (этапы 1–4)

Десктопное приложение для агентства недвижимости: объекты, клиенты, риэлторы,
показы, сделки и отчёты.

**Стек:** C# / .NET 8, WPF (MVVM), Entity Framework Core 8 + Pomelo (MySQL),
ADO.NET (MySqlConnector), MySQL 8.x, внедрение зависимостей Microsoft.Extensions.DependencyInjection.

---

## 1. Как запустить

### 1.1. База данных (MySQL Workbench или консоль `mysql` под root)
Выполнить скрипты из папки `sql/` строго по порядку:

| № | Файл | Что делает |
|---|------|-----------|
| 1 | `01_schema.sql` | создаёт базу `realty_agency`: таблицы, индексы, триггеры, представления |
| 2 | `02_seed.sql` | тестовые данные (6 районов, 5 риэлторов, 12 клиентов, 14 объектов, показы, сделки) |
| 3 | `03_security.sql` | роли `ra_admin / ra_app / ra_report` и пользователей MySQL |
| 4 | `05_audit.sql` | триггеры аудита → таблица `audit_log` |

`04_backup_restore.bat` — резервное копирование (запускается отдельно, двойным кликом).

> В Workbench: открыть файл → кнопка ⚡ «Execute» (выполнить весь скрипт целиком).

### 1.2. Строка подключения
Файл `src/RealtyAgency.Wpf/appsettings.json`. По умолчанию приложение входит пользователем
`realty_app` (создаётся скриптом 03). Если хотите работать под root — поменяйте
`User ID` и `Password` на свои.

### 1.3. Сборка
1. Открыть `RealtyAgency.sln` в Visual Studio 2022.
2. ПКМ по `RealtyAgency.Wpf` → **Назначить автозагружаемым проектом**.
3. **Сборка → Пересобрать решение** (NuGet-пакеты скачаются сами).
4. **F5**.

Если MySQL не запущен или пароль неверный — приложение не упадёт, а покажет сообщение
«Не удалось подключиться к MySQL…». Подробности — в журнале (путь показан внизу меню).

---

## 2. Структура решения (3 слоя)

```
RealtyAgency.sln
├── sql/                               SQL-скрипты MySQL
├── docs/diagrams/                     ER-диаграмма, диаграмма компонентов, схема интеграции
└── src/
    ├── RealtyAgency.DataAccess/       DAL — доступ к данным
    │   ├── Entities/                  POCO-классы (District, Realtor, Client, Property, Viewing, Deal)
    │   ├── Interfaces/                контракты репозиториев (IPropertyRepository …)
    │   ├── Repositories/              реализации (EF Core + LINQ; ReportRepository — ADO.NET)
    │   ├── RealtyDbContext.cs         DbContext + Fluent API
    │   └── DataAccessException.cs     перевод ошибок MySQL в понятные
    ├── RealtyAgency.BusinessLogic/    BLL — бизнес-логика
    │   ├── Interfaces/                контракты сервисов (IPropertyService, IDealService …)
    │   ├── Services/                  сервисы с проверками и правилами
    │   ├── Exceptions/                пользовательские классы-исключения
    │   └── Logging/AppLog.cs          журнал на Debug/Trace + файл
    └── RealtyAgency.Wpf/              Presentation — интерфейс
        ├── App.xaml.cs                точка входа, регистрация зависимостей (DI)
        ├── Themes/Theme.xaml          оформление (цвета, кнопки, таблицы)
        ├── ViewModels/                MVVM: страницы и формы
        └── Views/                     XAML: главное окно, страницы, формы
```

Ссылки между проектами: **Wpf → BusinessLogic → DataAccess**.
`App.xaml.cs` — единственное место, где «видны» все три слоя: там они связываются через DI.

---

## 3. Где в коде шаги этапа 2

| Шаг задания | Где смотреть |
|---|---|
| 1. Solution по слоям, NuGet, Git | `RealtyAgency.sln`, три `.csproj` |
| 2. DAL: POCO, DbContext, репозитории, параметризованные запросы | `DataAccess/Entities`, `RealtyDbContext.cs`, `Repositories/*`, `ReportRepository.cs` (параметры `@from`, `@to`) |
| 3. BLL: сервисы, бизнес-правила, валидация | `BusinessLogic/Services/*`, класс `Validator` в `ServiceBase.cs` |
| 4. WPF: окна, ViewModel, команды | `Wpf/Views/*`, `Wpf/ViewModels/*`, `Infrastructure/Mvvm.cs` |
| 5. Отладка: точки останова | см. раздел 4 ниже |
| 6. Debug и Trace, журнал в файл | `Logging/AppLog.cs`, `Debug.WriteLine` / `Trace.WriteLine` во всех слоях, `Debug.Assert` в `DealService` |
| 7. Классы-исключения, try/catch/finally | `Exceptions/RealtyExceptions.cs`, `ServiceBase.GuardAsync`, `PageViewModel.RunAsync` |
| 8. Интерфейсы (контракты) | `DataAccess/Interfaces/IRepositories.cs`, `BusinessLogic/Interfaces/IServices.cs` |
| 9. Интеграция через DI | `Wpf/App.xaml.cs` → `ConfigureServices` |
| 10. Сквозной сценарий | «Объекты» → «Оформить сделку» → объект стал «Зарезервирован» → «Сделки» → «Завершить» → объект «Закрыт» |

---

## 4. Сценарии для отладки (скриншоты для протокола)

| № | Что сделать | Куда поставить точку останова (F9) | Что увидеть |
|---|---|---|---|
| 1 | Открыть «Объекты» | `PropertyRepository.SearchAsync` | в окне Locals — фильтр; в Output — SQL-запрос EF Core |
| 2 | Оформить сделку | `DealService.CreateAsync`, строка с `CalculateCommission` | в Watch: `d.Amount`, `realtor.CommissionPercent`, `d.Commission` |
| 3 | Оформить вторую сделку по тому же объекту | `DealService.CreateAsync` (проверка статуса) | `PropertyNotAvailableException`, сообщение в форме |
| 4 | Назначить два показа одному риэлтору с разницей 30 минут | `ViewingService.SaveAsync` | `RealtorBusyException` |
| 5 | Удалить клиента-собственника | `ClientService.DeleteAsync` | `DataAccessException(ForeignKey)` → `DeleteRestrictedException` |
| 6 | Ввести в цену «abc» | `EditorViewModelBase.ParseDecimal` | ошибка «введите число», в БД ничего не ушло |
| 7 | Остановить MySQL (или неверный пароль) и открыть «Главную» | `DbErrorTranslator.Translate` | `Number = 1042/1045` → `DatabaseException` |

После каждого сценария откройте файл журнала `bin/Debug/net8.0-windows/logs/realty_ГГГГ-ММ-ДД.log` —
там видны строки `[UI]`, `[BLL]`, `[DAL]` с временем.

---

## 5. Тесты (этап 3)

Проект `tests/RealtyAgency.Tests` (xUnit): **112 проверок** — 83 модульных (заглушки репозиториев) и
29 интеграционных на настоящем MySQL. Интеграционные тесты сами создают базу **realty_agency_test**
из скриптов `sql/01, 02, 05` — рабочая база `realty_agency` не трогается.

1. Укажите пароль root в `tests/RealtyAgency.Tests/testsettings.json` (или в переменной окружения
   `REALTY_TEST_MYSQL`).
2. Visual Studio: **Тест → Обозреватель тестов → Запустить все**. Или в PowerShell:
   ```
   .\run-tests.ps1
   ```
   (скрипт также строит HTML-отчёт о покрытии в `coverage/index.html`; один раз установите
   `dotnet tool install -g dotnet-reportgenerator-globaltool`).

Найденные дефекты DEF-01…DEF-04 и их исправления — коммиты `fix(DEF-0N)`, подробности — `docs/testing/README.md`.

## 6. Стандарт кодирования (этап 4)

Анализаторы подключены в `src/Directory.Build.props` (StyleCop.Analyzers + .NET Analyzers),
правила — в `.editorconfig`, пороги метрик — в `CodeMetricsConfig.txt`. Сборка решения даёт
**0 предупреждений**. Отчёт до/после и протокол инспекции — `docs/inspection/README.md`.
`.editorconfig.before` — полный набор правил, которым снимался первый отчёт.

> ⚠️ База приложения называется `realty_agency`. Скрипты практики ПМ.11 используют другую базу
> (`realty_pm11`), но если база `realty_agency` была перезаписана, просто выполните заново
> `sql/01_schema.sql`, `02_seed.sql`, `03_security.sql`, `05_audit.sql`.
