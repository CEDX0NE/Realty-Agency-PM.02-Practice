@echo off
chcp 65001 > nul
REM =====================================================================
REM  Резервное копирование БД realty_agency (полный дамп).
REM  Можно поставить в Планировщик заданий Windows на ежедневный запуск.
REM =====================================================================
set MYSQL_BIN=C:\Program Files\MySQL\MySQL Server 8.0\bin
set OUT=C:\RealtyBackups
set DB=realty_agency
set USER=realty_admin
set PASS=Kluch_Admin_2026!

if not exist "%OUT%" mkdir "%OUT%"

for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd_HH-mm"') do set STAMP=%%i

"%MYSQL_BIN%\mysqldump.exe" -u%USER% -p%PASS% --single-transaction --routines --triggers --databases %DB% > "%OUT%\%DB%_%STAMP%.sql"

if %ERRORLEVEL%==0 (
    echo %STAMP% FULL OK  >> "%OUT%\backup.log"
    echo Резервная копия создана: %OUT%\%DB%_%STAMP%.sql
) else (
    echo %STAMP% FULL FAIL >> "%OUT%\backup.log"
    echo ОШИБКА резервного копирования, см. backup.log
)

REM ----- Восстановление (выполнить вручную) -----
REM "%MYSQL_BIN%\mysql.exe" -u%USER% -p%PASS% < "%OUT%\realty_agency_ДАТА.sql"
pause
