using System.ComponentModel.DataAnnotations.Schema;
using System.Globalization;

namespace RealtyAgency.DataAccess.Entities;

/// <summary>Объект недвижимости в продаже или аренде (таблица properties).</summary>
public class Property
{
    /// <summary>Получает или задает код объекта.</summary>
    public int Id { get; set; }

    /// <summary>Получает или задает адрес.</summary>
    public string Address { get; set; } = string.Empty;

    /// <summary>Получает или задает код района.</summary>
    public int DistrictId { get; set; }

    /// <summary>Получает или задает код типа недвижимости.</summary>
    public int PropertyTypeId { get; set; }

    /// <summary>Получает или задает код собственника (клиента).</summary>
    public int OwnerId { get; set; }

    /// <summary>Получает или задает код ответственного риэлтора.</summary>
    public int RealtorId { get; set; }

    /// <summary>Получает или задает вид предложения: продажа или аренда.</summary>
    public OfferType OfferType { get; set; } = OfferType.Sale;

    /// <summary>Получает или задает цену продажи или месячную арендную плату, ₽.</summary>
    public decimal Price { get; set; }

    /// <summary>Получает или задает площадь, м².</summary>
    public decimal Area { get; set; }

    /// <summary>Получает или задает число комнат (0 — студия, участок, помещение).</summary>
    public int Rooms { get; set; } = 1;

    /// <summary>Получает или задает этаж (необязательно).</summary>
    public int? Floor { get; set; }

    /// <summary>Получает или задает этажность дома (необязательно).</summary>
    public int? TotalFloors { get; set; }

    /// <summary>Получает или задает описание объекта.</summary>
    public string? Description { get; set; }

    /// <summary>Получает или задает статус: активен, зарезервирован, закрыт, снят.</summary>
    public PropertyStatus Status { get; set; } = PropertyStatus.Active;

    /// <summary>Получает или задает дату добавления объекта.</summary>
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    /// <summary>Получает или задает район.</summary>
    public District? District { get; set; }

    /// <summary>Получает или задает тип недвижимости.</summary>
    public PropertyType? PropertyType { get; set; }

    /// <summary>Получает или задает собственника.</summary>
    public Client? Owner { get; set; }

    /// <summary>Получает или задает ответственного риэлтора.</summary>
    public Realtor? Realtor { get; set; }

    /// <summary>Получает или задает показы объекта.</summary>
    public ICollection<Viewing> Viewings { get; set; } = new List<Viewing>();

    /// <summary>Получает или задает сделки по объекту.</summary>
    public ICollection<Deal> Deals { get; set; } = new List<Deal>();

    /// <summary>Получает цену за квадратный метр (вычисляется, в БД не хранится).</summary>
    [NotMapped]
    public decimal PricePerMeter => Area > 0 ? Math.Round(Price / Area, 0) : 0;

    /// <summary>Получает этаж для таблицы: «5 / 9», «— / 2».</summary>
    [NotMapped]
    public string FloorText => Floor is null && TotalFloors is null
        ? "—"
        : $"{Floor?.ToString(CultureInfo.InvariantCulture) ?? "—"} / {TotalFloors?.ToString(CultureInfo.InvariantCulture) ?? "—"}";

    /// <summary>Получает строку для выпадающих списков.</summary>
    [NotMapped]
    public string DisplayName => $"{Address} · {Area:0.#} м²";

    /// <inheritdoc/>
    public override string ToString() => DisplayName;
}
