using System.Globalization;
using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.Wpf.ViewModels.Editors;

/// <summary>Форма объекта недвижимости.</summary>
public sealed class PropertyEditorViewModel : EditorViewModelBase
{
    private readonly IPropertyService _service;
    private readonly IReferenceService _references;
    private readonly IClientService _clients;
    private readonly IRealtorService _realtors;
    private readonly Property? _existing;

    public PropertyEditorViewModel(
        IPropertyService service,
        IReferenceService references,
        IClientService clients,
        IRealtorService realtors,
        Property? existing)
    {
        _service = service;
        _references = references;
        _clients = clients;
        _realtors = realtors;
        _existing = existing;

        if (existing is not null)
        {
            _address = existing.Address;
            _districtId = existing.DistrictId;
            _propertyTypeId = existing.PropertyTypeId;
            _ownerId = existing.OwnerId;
            _realtorId = existing.RealtorId;
            _isRent = existing.OfferType == OfferType.Rent;
            _price = Format(existing.Price);
            _area = Format(existing.Area);
            _rooms = existing.Rooms.ToString(CultureInfo.InvariantCulture);
            _floor = existing.Floor?.ToString(CultureInfo.InvariantCulture) ?? string.Empty;
            _totalFloors = existing.TotalFloors?.ToString(CultureInfo.InvariantCulture) ?? string.Empty;
            _description = existing.Description ?? string.Empty;
        }
    }

    public override string Title => _existing is null ? "Новый объект" : "Редактирование объекта";

    public override double FormWidth => 640;

    // ---------- Списки ----------
    public List<District> Districts { get; private set; } = new();

    public List<PropertyType> Types { get; private set; } = new();

    public List<Client> Clients { get; private set; } = new();

    public List<Realtor> Realtors { get; private set; } = new();

    public override async Task LoadAsync()
    {
        Districts = await _references.GetDistrictsAsync();
        Types = await _references.GetPropertyTypesAsync();
        Clients = await _clients.GetAllAsync();

        // Неработающих риэлторов не предлагаем, но текущего оставляем
        Realtors = (await _realtors.GetAllAsync())
            .Where(r => r.IsActive || r.Id == _existing?.RealtorId)
            .ToList();

        OnPropertyChanged(nameof(Districts));
        OnPropertyChanged(nameof(Types));
        OnPropertyChanged(nameof(Clients));
        OnPropertyChanged(nameof(Realtors));
    }

    // ---------- Поля ----------
    private string _address = string.Empty;

    public string Address { get => _address; set => Set(ref _address, value); }

    private int? _districtId;

    public int? DistrictId { get => _districtId; set => Set(ref _districtId, value); }

    private int? _propertyTypeId;

    public int? PropertyTypeId { get => _propertyTypeId; set => Set(ref _propertyTypeId, value); }

    private int? _ownerId;

    public int? OwnerId { get => _ownerId; set => Set(ref _ownerId, value); }

    private int? _realtorId;

    public int? RealtorId { get => _realtorId; set => Set(ref _realtorId, value); }

    private bool _isRent;

    public bool IsRent
    {
        get => _isRent;
        set
        {
            if (Set(ref _isRent, value))
            {
                OnPropertyChanged(nameof(IsSale));
                OnPropertyChanged(nameof(PriceLabel));
            }
        }
    }

    public bool IsSale { get => !IsRent; set => IsRent = !value; }

    public string PriceLabel => IsRent ? "Аренда в месяц, ₽" : "Цена, ₽";

    private string _price = string.Empty;

    public string Price { get => _price; set => Set(ref _price, value); }

    private string _area = string.Empty;

    public string Area { get => _area; set => Set(ref _area, value); }

    private string _rooms = "1";

    public string Rooms { get => _rooms; set => Set(ref _rooms, value); }

    private string _floor = string.Empty;

    public string Floor { get => _floor; set => Set(ref _floor, value); }

    private string _totalFloors = string.Empty;

    public string TotalFloors { get => _totalFloors; set => Set(ref _totalFloors, value); }

    private string _description = string.Empty;

    public string Description { get => _description; set => Set(ref _description, value); }

    protected override async Task SaveCoreAsync(List<string> parseErrors)
    {
        var price = ParseDecimal(Price, PriceLabel, parseErrors);
        var area = ParseDecimal(Area, "Площадь, м²", parseErrors);
        var rooms = ParseInt(Rooms, "Комнат", parseErrors);
        var floor = ParseInt(Floor, "Этаж", parseErrors, required: false);
        var totalFloors = ParseInt(TotalFloors, "Этажей в доме", parseErrors, required: false);
        if (parseErrors.Count > 0)
        {
            return;
        }

        await _service.SaveAsync(new Property
        {
            Id = _existing?.Id ?? 0,
            Address = Address,
            DistrictId = DistrictId ?? 0,
            PropertyTypeId = PropertyTypeId ?? 0,
            OwnerId = OwnerId ?? 0,
            RealtorId = RealtorId ?? 0,
            OfferType = IsRent ? OfferType.Rent : OfferType.Sale,
            Price = price!.Value,
            Area = area!.Value,
            Rooms = rooms!.Value,
            Floor = floor,
            TotalFloors = totalFloors,
            Description = Description,
        });
    }
}
