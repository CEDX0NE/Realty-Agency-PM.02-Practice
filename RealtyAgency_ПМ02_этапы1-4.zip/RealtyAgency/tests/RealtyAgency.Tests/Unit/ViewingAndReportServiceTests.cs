using System.Data;
using System.Text;
using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Services;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.Tests.Fakes;

namespace RealtyAgency.Tests.Unit;

/// <summary>Показы и отчёты (US-09 – US-12).</summary>
[Trait("Category", "Unit")]
public class ViewingAndReportServiceTests
{
    private readonly TestWorld _w = new();
    private readonly ViewingService _viewings;

    public ViewingAndReportServiceTests()
    {
        _viewings = new ViewingService(_w.Viewings, _w.Properties, _w.Realtors);
    }

    private static Viewing NewViewing(int propertyId = 1) => new()
    {
        PropertyId = propertyId, ClientId = 2, RealtorId = 1, ScheduledAt = DateTime.Now.AddDays(1),
    };

    [Fact]
    [Trait("TC", "ТК-16")]
    public async Task SaveAsync_ValidViewing_Adds()
    {
        await _viewings.SaveAsync(NewViewing());

        Assert.Single(_w.Viewings.Items);
    }

    [Fact]
    public async Task SaveAsync_NewViewingInPast_ThrowsValidation()
    {
        var v = NewViewing();
        v.ScheduledAt = DateTime.Now.AddMinutes(-1);

        await Assert.ThrowsAsync<ValidationException>(() => _viewings.SaveAsync(v));
    }

    [Theory]
    [InlineData(3)]
    [InlineData(4)]
    public async Task SaveAsync_ClosedOrArchivedProperty_ThrowsPropertyNotAvailable(int propertyId)
    {
        await Assert.ThrowsAsync<PropertyNotAvailableException>(() => _viewings.SaveAsync(NewViewing(propertyId)));
    }

    [Fact]
    public async Task SaveAsync_ReservedProperty_Allowed()
    {
        await _viewings.SaveAsync(NewViewing(2));

        Assert.Single(_w.Viewings.Items);
    }

    [Fact]
    public async Task SaveAsync_ClientIsOwner_ThrowsValidation()
    {
        var v = NewViewing();
        v.ClientId = 1;

        await Assert.ThrowsAsync<ValidationException>(() => _viewings.SaveAsync(v));
    }

    [Fact]
    [Trait("TC", "ТК-17")]
    public async Task SaveAsync_RealtorBusy_ThrowsRealtorBusy()
    {
        _w.Viewings.Conflict = true;

        var ex = await Assert.ThrowsAsync<RealtorBusyException>(() => _viewings.SaveAsync(NewViewing()));

        Assert.Contains("Орлова", ex.Message);
    }

    [Fact]
    [Trait("TC", "ТК-23")]
    public async Task SetStatusAsync_DoneInFuture_ThrowsBusinessRule()
    {
        var v = NewViewing();
        await _viewings.SaveAsync(v);

        await Assert.ThrowsAsync<BusinessRuleException>(() => _viewings.SetStatusAsync(v.Id, ViewingStatus.Done, null));
    }

    [Fact]
    [Trait("TC", "ТК-23")]
    public async Task SetStatusAsync_Cancel_SavesFeedback()
    {
        var v = NewViewing();
        await _viewings.SaveAsync(v);

        await _viewings.SetStatusAsync(v.Id, ViewingStatus.Cancelled, "  Клиент передумал ");

        Assert.Equal(ViewingStatus.Cancelled, v.Status);
        Assert.Equal("Клиент передумал", v.Feedback);
    }

    [Fact]
    [Trait("TC", "ТК-19")]
    public async Task DealsByPeriodAsync_FromAfterTo_ThrowsValidationWithoutQuery()
    {
        var repo = new FakeReportRepository();
        var service = new ReportService(repo);

        await Assert.ThrowsAsync<ValidationException>(
            () => service.DealsByPeriodAsync(new DateTime(2026, 10, 2), new DateTime(2026, 10, 1)));
        Assert.Equal(0, repo.Calls);
    }

    [Fact]
    public async Task RealtorPerformanceAsync_SameDay_IsValidPeriod()
    {
        var repo = new FakeReportRepository();
        var service = new ReportService(repo);

        await service.RealtorPerformanceAsync(DateTime.Today, DateTime.Today);

        Assert.Equal(1, repo.Calls);
    }

    [Fact]
    [Trait("TC", "ТК-20")]
    public void ExportCsv_WritesBomHeaderAndEscapesValues()
    {
        // Arrange
        var table = new DataTable();
        table.Columns.Add("Объект");
        table.Columns.Add("Сумма ₽", typeof(decimal));
        table.Rows.Add("ул. Ленина; д. 12", 12_300_000.5m);
        table.Rows.Add("пр. \"Мира\"", 45_000m);
        var path = Path.Combine(Path.GetTempPath(), $"report_{Guid.NewGuid():N}.csv");
        var service = new ReportService(new FakeReportRepository());

        try
        {
            // Act
            service.ExportCsv(table, path);

            // Assert
            var bytes = File.ReadAllBytes(path);
            Assert.Equal(new byte[] { 0xEF, 0xBB, 0xBF }, bytes.Take(3).ToArray());
            var lines = File.ReadAllLines(path, Encoding.UTF8);
            Assert.Equal("Объект;Сумма ₽", lines[0]);
            Assert.Equal("\"ул. Ленина; д. 12\";12300000,5", lines[1]);
            Assert.Equal("\"пр. \"\"Мира\"\"\";45000", lines[2]);
        }
        finally
        {
            File.Delete(path);
        }
    }

    [Fact]
    public void ExportCsv_FolderDoesNotExist_ThrowsRealtyException()
    {
        var service = new ReportService(new FakeReportRepository());
        var path = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("N"), "x.csv");

        Assert.Throws<RealtyException>(() => service.ExportCsv(new DataTable(), path));
    }

    [Fact]
    [Trait("TC", "ТК-24")]
    public async Task GetDashboardAsync_ReturnsRepositoryStats()
    {
        var service = new ReportService(new FakeReportRepository());

        var stats = await service.GetDashboardAsync();

        Assert.Equal(6, stats.ClientsCount);
    }
}
