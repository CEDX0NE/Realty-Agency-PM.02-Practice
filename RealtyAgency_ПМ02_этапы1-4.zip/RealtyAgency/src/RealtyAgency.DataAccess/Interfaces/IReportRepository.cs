using System.Data;

namespace RealtyAgency.DataAccess.Interfaces;

/// <summary>Отчёты (ADO.NET + параметризованные SQL-запросы).</summary>
public interface IReportRepository
{
    /// <summary>Сделки за период; обе даты включаются.</summary>
    /// <param name="dateFrom">Первый день периода.</param>
    /// <param name="dateTo">Последний день периода.</param>
    /// <returns>Таблица отчёта.</returns>
    Task<DataTable> GetDealsByPeriodAsync(DateTime dateFrom, DateTime dateTo);

    /// <summary>Показатели риэлторов за период (работающих и тех, у кого были показы или сделки).</summary>
    /// <param name="dateFrom">Первый день периода.</param>
    /// <param name="dateTo">Последний день периода.</param>
    /// <returns>Таблица отчёта.</returns>
    Task<DataTable> GetRealtorPerformanceAsync(DateTime dateFrom, DateTime dateTo);

    /// <summary>Средние цены доступных объектов по районам и типам.</summary>
    /// <returns>Таблица отчёта.</returns>
    Task<DataTable> GetMarketByDistrictAsync();

    /// <summary>Показатели главной страницы.</summary>
    /// <returns>Сводные показатели.</returns>
    Task<DashboardStats> GetDashboardStatsAsync();
}
