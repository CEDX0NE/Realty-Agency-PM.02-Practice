using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.Wpf.ViewModels.Editors;

/// <summary>Форма клиента.</summary>
public sealed class ClientEditorViewModel : EditorViewModelBase
{
    private readonly IClientService _service;
    private readonly Client? _existing;

    public ClientEditorViewModel(IClientService service, Client? existing)
    {
        _service = service;
        _existing = existing;
        if (existing is not null)
        {
            _fullName = existing.FullName;
            _phone = existing.Phone;
            _email = existing.Email ?? string.Empty;
            _notes = existing.Notes ?? string.Empty;
        }
    }

    public override string Title => _existing is null ? "Новый клиент" : "Редактирование клиента";

    private string _fullName = string.Empty;

    public string FullName { get => _fullName; set => Set(ref _fullName, value); }

    private string _phone = "+7 ";

    public string Phone { get => _phone; set => Set(ref _phone, value); }

    private string _email = string.Empty;

    public string Email { get => _email; set => Set(ref _email, value); }

    private string _notes = string.Empty;

    public string Notes { get => _notes; set => Set(ref _notes, value); }

    protected override Task SaveCoreAsync(List<string> parseErrors) =>
        _service.SaveAsync(new Client
        {
            Id = _existing?.Id ?? 0,
            FullName = FullName,
            Phone = Phone,
            Email = Email,
            Notes = Notes,
            RegisteredAt = _existing?.RegisteredAt ?? DateTime.Now,
        });
}

/// <summary>Форма риэлтора.</summary>
public sealed class RealtorEditorViewModel : EditorViewModelBase
{
    private readonly IRealtorService _service;
    private readonly Realtor? _existing;

    public RealtorEditorViewModel(IRealtorService service, Realtor? existing)
    {
        _service = service;
        _existing = existing;
        if (existing is not null)
        {
            _fullName = existing.FullName;
            _phone = existing.Phone;
            _email = existing.Email ?? string.Empty;
            _commission = Format(existing.CommissionPercent);
            _hireDate = existing.HireDate;
            _isActive = existing.IsActive;
        }
    }

    public override string Title => _existing is null ? "Новый риэлтор" : "Редактирование риэлтора";

    private string _fullName = string.Empty;

    public string FullName { get => _fullName; set => Set(ref _fullName, value); }

    private string _phone = "+7 ";

    public string Phone { get => _phone; set => Set(ref _phone, value); }

    private string _email = string.Empty;

    public string Email { get => _email; set => Set(ref _email, value); }

    private string _commission = "3";

    public string Commission { get => _commission; set => Set(ref _commission, value); }

    private DateTime? _hireDate = DateTime.Today;

    public DateTime? HireDate { get => _hireDate; set => Set(ref _hireDate, value); }

    private bool _isActive = true;

    public bool IsActive { get => _isActive; set => Set(ref _isActive, value); }

    protected override async Task SaveCoreAsync(List<string> parseErrors)
    {
        var commission = ParseDecimal(Commission, "Комиссия, %", parseErrors);
        if (HireDate is null)
        {
            parseErrors.Add("Укажите дату приёма на работу");
        }

        if (parseErrors.Count > 0)
        {
            return;
        }

        await _service.SaveAsync(new Realtor
        {
            Id = _existing?.Id ?? 0,
            FullName = FullName,
            Phone = Phone,
            Email = Email,
            CommissionPercent = commission!.Value,
            HireDate = HireDate!.Value.Date,
            IsActive = IsActive,
        });
    }
}
