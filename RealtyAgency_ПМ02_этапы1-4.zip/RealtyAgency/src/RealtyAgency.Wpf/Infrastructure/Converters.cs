using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.Wpf.Infrastructure;

/// <summary>Перевод значений enum на русский (для таблиц и бейджей).</summary>
public sealed class EnumTextConverter : IValueConverter
{
    public static string ToText(object? value) => value switch
    {
        OfferType.Sale => "Продажа",
        OfferType.Rent => "Аренда",
        PropertyStatus.Active => "Активен",
        PropertyStatus.Reserved => "Зарезервирован",
        PropertyStatus.Closed => "Закрыт",
        PropertyStatus.Archived => "Снят",
        ViewingStatus.Planned => "Запланирован",
        ViewingStatus.Done => "Проведён",
        ViewingStatus.Cancelled => "Отменён",
        DealStatus.Open => "Открыта",
        DealStatus.Completed => "Завершена",
        DealStatus.Cancelled => "Отменена",
        null => string.Empty,
        _ => value.ToString() ?? string.Empty,
    };

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) => ToText(value);

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

/// <summary>
/// Цвет бейджа статуса. ConverterParameter: "bg" — фон, "fg" — текст.
/// </summary>
public sealed class StatusBrushConverter : IValueConverter
{
    private enum Tone
    {
        Green,
        Amber,
        Blue,
        Gray,
        Red,
    }

    private static Tone ToneOf(object? value) => value switch
    {
        PropertyStatus.Active or ViewingStatus.Done or DealStatus.Completed => Tone.Green,
        PropertyStatus.Reserved or DealStatus.Open => Tone.Amber,
        PropertyStatus.Closed or ViewingStatus.Planned => Tone.Blue,
        OfferType.Sale => Tone.Blue,
        OfferType.Rent => Tone.Amber,
        _ => Tone.Gray,
    };

    private static readonly Dictionary<Tone, (string Bg, string Fg)> Palette = new()
    {
        [Tone.Green] = ("#DCFCE7", "#166534"),
        [Tone.Amber] = ("#FEF3C7", "#92400E"),
        [Tone.Blue] = ("#DBEAFE", "#1E40AF"),
        [Tone.Gray] = ("#EEF0F3", "#4B5563"),
        [Tone.Red] = ("#FEE2E2", "#991B1B"),
    };

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var (bg, fg) = Palette[ToneOf(value)];
        var hex = (parameter as string) == "fg" ? fg : bg;
        var brush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex));
        brush.Freeze();
        return brush;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

/// <summary>true → Visible, false → Collapsed. Parameter "invert" — наоборот.</summary>
public sealed class BoolToVisibilityConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var flag = value is bool b && b;
        if ((parameter as string) == "invert")
        {
            flag = !flag;
        }

        return flag ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

/// <summary>Пустая строка / null → Collapsed, иначе Visible.</summary>
public sealed class EmptyToCollapsedConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        value is null || (value is string s && string.IsNullOrWhiteSpace(s)) || (value is int i && i == 0)
            ? Visibility.Collapsed
            : Visibility.Visible;

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
