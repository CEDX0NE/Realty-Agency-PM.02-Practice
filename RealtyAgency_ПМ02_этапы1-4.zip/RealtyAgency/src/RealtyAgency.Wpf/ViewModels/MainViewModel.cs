using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.DependencyInjection;
using RealtyAgency.BusinessLogic.Logging;
using RealtyAgency.Wpf.Infrastructure;
using RealtyAgency.Wpf.ViewModels.Pages;

namespace RealtyAgency.Wpf.ViewModels;

/// <summary>Пункт бокового меню.</summary>
public sealed class NavItem
{
    public NavItem(string title, string glyph, Type pageType)
    {
        Title = title;
        Glyph = glyph;
        PageType = pageType;
    }

    public string Title { get; }

    /// <summary>Получает символ из шрифта Segoe MDL2 Assets.</summary>
    public string Glyph { get; }

    public Type PageType { get; }
}

/// <summary>Главное окно: меню слева, текущая страница справа.</summary>
public sealed class MainViewModel : ObservableObject
{
    private readonly IServiceProvider _services;
    private readonly Dictionary<Type, PageViewModel> _pages = new();

    public MainViewModel(IServiceProvider services)
    {
        _services = services;
        NavItems = new ObservableCollection<NavItem>
        {
            new("Главная",   "", typeof(DashboardViewModel)),
            new("Объекты",   "", typeof(PropertiesViewModel)),
            new("Клиенты",   "", typeof(ClientsViewModel)),
            new("Риэлторы",  "", typeof(RealtorsViewModel)),
            new("Показы",    "", typeof(ViewingsViewModel)),
            new("Сделки",    "", typeof(DealsViewModel)),
            new("Отчёты",    "", typeof(ReportsViewModel)),
        };
    }

    public ObservableCollection<NavItem> NavItems { get; }

    private NavItem? _selectedNav;

    public NavItem? SelectedNav
    {
        get => _selectedNav;
        set
        {
            if (Set(ref _selectedNav, value) && value is not null)
            {
                _ = NavigateAsync(value);
            }
        }
    }

    private PageViewModel? _currentPage;

    public PageViewModel? CurrentPage { get => _currentPage; private set => Set(ref _currentPage, value); }

    [SuppressMessage("Performance", "CA1822", Justification = "Свойство экземпляра нужно для привязки {Binding LogPath} в XAML")]
    public string LogPath => AppLog.LogFilePath ?? string.Empty;

    private async Task NavigateAsync(NavItem item)
    {
        if (!_pages.TryGetValue(item.PageType, out var page))
        {
            page = (PageViewModel)_services.GetRequiredService(item.PageType);
            _pages[item.PageType] = page;
        }

        AppLog.Info("UI", $"Переход: {item.Title}");
        CurrentPage = page;
        await page.LoadAsync();
    }
}
