using System.Globalization;

namespace RealtyAgency.BusinessLogic.Exceptions;

/// <summary>У риэлтора уже есть показ в это время.</summary>
public class RealtorBusyException : RealtyException
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="RealtorBusyException"/>.</summary>
    /// <param name="realtorName">ФИО риэлтора.</param>
    /// <param name="time">Время, на которое назначали показ.</param>
    public RealtorBusyException(string realtorName, DateTime time)
        : base($"У риэлтора {realtorName} уже есть показ около {time.ToString("dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture)}. " +
               "Выберите другое время (интервал между показами — не меньше часа).")
    {
    }
}
