using Microsoft.EntityFrameworkCore;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Interfaces;

namespace RealtyAgency.DataAccess.Repositories;

/// <summary>Показы объектов.</summary>
public class ViewingRepository : RepositoryBase, IViewingRepository
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="ViewingRepository"/>.</summary>
    /// <param name="factory">Фабрика контекстов EF Core.</param>
    public ViewingRepository(IDbContextFactory<RealtyDbContext> factory)
        : base(factory)
    {
    }

    /// <inheritdoc/>
    public Task<List<Viewing>> GetAllAsync(ViewingStatus? status) =>
        QueryAsync("Список показов", db =>
        {
            var q = db.Viewings.AsNoTracking()
                .Include(v => v.Property)
                .Include(v => v.Client)
                .Include(v => v.Realtor)
                .AsQueryable();
            if (status is ViewingStatus st)
            {
                q = q.Where(v => v.Status == st);
            }

            return q.OrderByDescending(v => v.ScheduledAt).ToListAsync();
        });

    /// <inheritdoc/>
    public Task<Viewing?> GetByIdAsync(int id) =>
        QueryAsync($"Показ ID={id}", db =>
            db.Viewings.AsNoTracking().FirstOrDefaultAsync(v => v.Id == id));

    /// <inheritdoc/>
    public Task<bool> HasRealtorConflictAsync(int realtorId, DateTime time, TimeSpan window, int excludeId)
    {
        var from = time - window;
        var to = time + window;
        return QueryAsync("Проверка занятости риэлтора", db =>
            db.Viewings.AnyAsync(v => v.RealtorId == realtorId
                                      && v.Id != excludeId
                                      && v.Status == ViewingStatus.Planned
                                      && v.ScheduledAt > from && v.ScheduledAt < to));
    }

    /// <inheritdoc/>
    public Task AddAsync(Viewing viewing) =>
        ExecuteAsync("Добавление показа", async db =>
        {
            db.Viewings.Add(viewing);
            await db.SaveChangesAsync();
        });

    /// <inheritdoc/>
    public Task UpdateAsync(Viewing viewing) =>
        ExecuteAsync($"Изменение показа ID={viewing.Id}", async db =>
        {
            var existing = await db.Viewings.FindAsync(viewing.Id) ?? throw NotFound("Показ", viewing.Id);
            db.Entry(existing).CurrentValues.SetValues(viewing);
            await db.SaveChangesAsync();
        });

    /// <inheritdoc/>
    public Task DeleteAsync(int id) =>
        ExecuteAsync($"Удаление показа ID={id}", async db =>
        {
            var existing = await db.Viewings.FindAsync(id) ?? throw NotFound("Показ", id);
            db.Viewings.Remove(existing);
            await db.SaveChangesAsync();
        });
}
