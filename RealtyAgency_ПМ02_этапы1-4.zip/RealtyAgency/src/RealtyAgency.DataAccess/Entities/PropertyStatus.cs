namespace RealtyAgency.DataAccess.Entities;

/// <summary>Статус объекта недвижимости.</summary>
public enum PropertyStatus
{
    /// <summary>В продаже / сдаётся.</summary>
    Active,

    /// <summary>Есть открытая сделка (задаток).</summary>
    Reserved,

    /// <summary>Продан / сдан.</summary>
    Closed,

    /// <summary>Снят с продажи.</summary>
    Archived,
}
