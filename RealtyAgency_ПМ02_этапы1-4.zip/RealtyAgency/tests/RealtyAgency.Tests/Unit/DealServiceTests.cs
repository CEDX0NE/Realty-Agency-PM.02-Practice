using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Services;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.Tests.Fakes;

namespace RealtyAgency.Tests.Unit;

/// <summary>Сделки: расчёт комиссии, правила оформления, смена статусов (US-07, US-08).</summary>
[Trait("Category", "Unit")]
public class DealServiceTests
{
    private readonly TestWorld _w = new();
    private readonly DealService _service;

    public DealServiceTests()
    {
        _service = new DealService(_w.Deals, _w.Properties, _w.Realtors);
    }

    [Theory]
    [InlineData(12_300_000, 3, 369_000)]
    [InlineData(45_000, 2.5, 1_125)]
    [InlineData(1_000_000, 0, 0)]
    [InlineData(1_000_001, 3.5, 35_000.04)]
    [InlineData(100.5, 1, 1.01)]
    public void CalculateCommission_ReturnsAmountTimesPercent(decimal amount, decimal percent, decimal expected)
    {
        Assert.Equal(expected, _service.CalculateCommission(amount, percent));
    }

    [Fact]
    [Trait("TC", "ТК-10")]
    public async Task CreateAsync_ActiveProperty_ReservesPropertyAndCalculatesCommission()
    {
        // Arrange
        var deal = TestWorld.NewDeal();

        // Act
        await _service.CreateAsync(deal);

        // Assert
        Assert.Equal(369_000m, deal.Commission);
        Assert.Equal(PropertyStatus.Reserved, _w.Properties.Get(1).Status);
        Assert.Single(_w.Deals.Items);
    }

    [Fact]
    public async Task CreateAsync_CompletedDeal_ClosesPropertyAtOnce()
    {
        var deal = TestWorld.NewDeal();
        deal.Status = DealStatus.Completed;

        await _service.CreateAsync(deal);

        Assert.Equal(PropertyStatus.Closed, _w.Properties.Get(1).Status);
    }

    [Theory]
    [Trait("TC", "ТК-11")]
    [InlineData(2, "уже есть открытая сделка")]
    [InlineData(3, "уже продан")]
    [InlineData(4, "снят с продажи")]
    public async Task CreateAsync_PropertyNotActive_ThrowsPropertyNotAvailable(int propertyId, string reason)
    {
        var ex = await Assert.ThrowsAsync<PropertyNotAvailableException>(
            () => _service.CreateAsync(TestWorld.NewDeal(propertyId)));

        Assert.Contains(reason, ex.Message);
        Assert.Empty(_w.Deals.Items);
    }

    [Fact]
    [Trait("TC", "ТК-12")]
    public async Task CreateAsync_ClientIsOwner_ThrowsValidation()
    {
        var deal = TestWorld.NewDeal();
        deal.ClientId = 1;

        var ex = await Assert.ThrowsAsync<ValidationException>(() => _service.CreateAsync(deal));

        Assert.Contains(ex.Errors, e => e.Contains("собственником"));
    }

    [Fact]
    public async Task CreateAsync_InactiveRealtor_ThrowsValidation()
    {
        var deal = TestWorld.NewDeal();
        deal.RealtorId = 2;

        await Assert.ThrowsAsync<ValidationException>(() => _service.CreateAsync(deal));
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    public async Task CreateAsync_AmountNotPositive_ThrowsValidation(decimal amount)
    {
        await Assert.ThrowsAsync<ValidationException>(() => _service.CreateAsync(TestWorld.NewDeal(amount: amount)));
    }

    [Fact]
    [Trait("TC", "ТК-13")]
    [Trait("Defect", "DEF-04")]
    public async Task CreateAsync_AmountAboveColumnLimit_ThrowsValidation()
    {
        // Граничное значение: в БД сумма — DECIMAL(14,2), максимум 999 999 999 999,99
        var deal = TestWorld.NewDeal(amount: 1_000_000_000_000m);

        var ex = await Assert.ThrowsAsync<ValidationException>(() => _service.CreateAsync(deal));

        Assert.Contains(ex.Errors, e => e.Contains("Сумма"));
    }

    [Fact]
    public async Task CreateAsync_FutureDate_ThrowsValidation()
    {
        var deal = TestWorld.NewDeal();
        deal.DealDate = DateTime.Today.AddDays(1);

        await Assert.ThrowsAsync<ValidationException>(() => _service.CreateAsync(deal));
    }

    [Fact]
    public async Task CreateAsync_UnknownProperty_ThrowsEntityNotFound()
    {
        await Assert.ThrowsAsync<EntityNotFoundException>(() => _service.CreateAsync(TestWorld.NewDeal(propertyId: 99)));
    }

    [Fact]
    [Trait("TC", "ТК-14")]
    public async Task CompleteAsync_OpenDeal_ClosesProperty()
    {
        var deal = TestWorld.NewDeal();
        await _service.CreateAsync(deal);

        await _service.CompleteAsync(deal.Id);

        Assert.Equal(DealStatus.Completed, deal.Status);
        Assert.Equal(PropertyStatus.Closed, _w.Properties.Get(1).Status);
    }

    [Fact]
    [Trait("TC", "ТК-15")]
    public async Task CancelAsync_OpenDeal_ReturnsPropertyToSale()
    {
        var deal = TestWorld.NewDeal();
        await _service.CreateAsync(deal);

        await _service.CancelAsync(deal.Id);

        Assert.Equal(DealStatus.Cancelled, deal.Status);
        Assert.Equal(PropertyStatus.Active, _w.Properties.Get(1).Status);
    }

    [Fact]
    public async Task CompleteAsync_AlreadyCompleted_ThrowsBusinessRule()
    {
        var deal = TestWorld.NewDeal();
        await _service.CreateAsync(deal);
        await _service.CompleteAsync(deal.Id);

        await Assert.ThrowsAsync<BusinessRuleException>(() => _service.CancelAsync(deal.Id));
    }

    [Fact]
    public async Task CompleteAsync_UnknownDeal_ThrowsEntityNotFound()
    {
        await Assert.ThrowsAsync<EntityNotFoundException>(() => _service.CompleteAsync(42));
    }
}
