using Microsoft.EntityFrameworkCore;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Interfaces;

namespace RealtyAgency.DataAccess.Repositories;

/// <summary>Объекты недвижимости (EF Core + LINQ).</summary>
public class PropertyRepository : RepositoryBase, IPropertyRepository
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="PropertyRepository"/>.</summary>
    /// <param name="factory">Фабрика контекстов EF Core.</param>
    public PropertyRepository(IDbContextFactory<RealtyDbContext> factory)
        : base(factory)
    {
    }

    /// <inheritdoc/>
    public Task<List<Property>> SearchAsync(PropertyFilter filter) =>
        QueryAsync("Поиск объектов", db =>
            ApplyRanges(ApplyText(ApplyCategories(WithDetails(db), filter), filter), filter)
                .OrderByDescending(p => p.CreatedAt)
                .ToListAsync());

    /// <inheritdoc/>
    public Task<List<Property>> GetAvailableAsync() =>
        QueryAsync("Доступные объекты", db =>
            WithDetails(db)
                .Where(p => p.Status == PropertyStatus.Active || p.Status == PropertyStatus.Reserved)
                .OrderBy(p => p.Address)
                .ToListAsync());

    /// <inheritdoc/>
    public Task<Property?> GetByIdAsync(int id) =>
        QueryAsync($"Объект ID={id}", db =>
            WithDetails(db).FirstOrDefaultAsync(p => p.Id == id));

    /// <inheritdoc/>
    public Task AddAsync(Property property) =>
        ExecuteAsync($"Добавление объекта «{property.Address}»", async db =>
        {
            db.Properties.Add(property);
            await db.SaveChangesAsync();
        });

    /// <inheritdoc/>
    public Task UpdateAsync(Property property) =>
        ExecuteAsync($"Изменение объекта ID={property.Id}", async db =>
        {
            var existing = await db.Properties.FindAsync(property.Id) ?? throw NotFound("Объект", property.Id);
            db.Entry(existing).CurrentValues.SetValues(property);
            await db.SaveChangesAsync();
        });

    /// <inheritdoc/>
    public Task DeleteAsync(int id) =>
        ExecuteAsync($"Удаление объекта ID={id}", async db =>
        {
            var existing = await db.Properties.FindAsync(id) ?? throw NotFound("Объект", id);
            db.Properties.Remove(existing);
            await db.SaveChangesAsync();
        });

    private static IQueryable<Property> WithDetails(RealtyDbContext db) =>
        db.Properties.AsNoTracking()
            .Include(p => p.District)
            .Include(p => p.PropertyType)
            .Include(p => p.Owner)
            .Include(p => p.Realtor);

    /// <summary>Фильтры-справочники: район, тип, вид предложения, статус.</summary>
    private static IQueryable<Property> ApplyCategories(IQueryable<Property> query, PropertyFilter filter)
    {
        if (filter.DistrictId is int district)
        {
            query = query.Where(p => p.DistrictId == district);
        }

        if (filter.PropertyTypeId is int type)
        {
            query = query.Where(p => p.PropertyTypeId == type);
        }

        if (filter.OfferType is OfferType offer)
        {
            query = query.Where(p => p.OfferType == offer);
        }

        if (filter.Status is PropertyStatus status)
        {
            query = query.Where(p => p.Status == status);
        }

        return query;
    }

    /// <summary>Поиск по части адреса или описания (EF Core передаёт строку параметром LIKE).</summary>
    private static IQueryable<Property> ApplyText(IQueryable<Property> query, PropertyFilter filter)
    {
        if (string.IsNullOrWhiteSpace(filter.Search))
        {
            return query;
        }

        var text = filter.Search.Trim();
        return query.Where(p => p.Address.Contains(text) || (p.Description != null && p.Description.Contains(text)));
    }

    /// <summary>Диапазоны: цена «от»/«до» (включительно) и минимальное число комнат.</summary>
    private static IQueryable<Property> ApplyRanges(IQueryable<Property> query, PropertyFilter filter)
    {
        if (filter.MinPrice is decimal min)
        {
            query = query.Where(p => p.Price >= min);
        }

        if (filter.MaxPrice is decimal max)
        {
            query = query.Where(p => p.Price <= max);
        }

        if (filter.MinRooms is int rooms)
        {
            query = query.Where(p => p.Rooms >= rooms);
        }

        return query;
    }
}
