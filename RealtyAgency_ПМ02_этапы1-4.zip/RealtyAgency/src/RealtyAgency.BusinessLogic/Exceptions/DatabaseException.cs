namespace RealtyAgency.BusinessLogic.Exceptions;

/// <summary>Ошибка базы данных (сервер недоступен, сбой запроса и т.п.).</summary>
public class DatabaseException : RealtyException
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="DatabaseException"/>.</summary>
    /// <param name="message">Текст для пользователя.</param>
    /// <param name="inner">Исходное исключение.</param>
    public DatabaseException(string message, Exception? inner = null)
        : base(message, inner)
    {
    }
}
