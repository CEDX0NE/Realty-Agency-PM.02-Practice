namespace RealtyAgency.DataAccess.Entities;

/// <summary>Показ объекта клиенту (таблица viewings).</summary>
public class Viewing
{
    /// <summary>Получает или задает код показа.</summary>
    public int Id { get; set; }

    /// <summary>Получает или задает код объекта.</summary>
    public int PropertyId { get; set; }

    /// <summary>Получает или задает код клиента.</summary>
    public int ClientId { get; set; }

    /// <summary>Получает или задает код риэлтора.</summary>
    public int RealtorId { get; set; }

    /// <summary>Получает или задает дату и время показа.</summary>
    public DateTime ScheduledAt { get; set; }

    /// <summary>Получает или задает статус: запланирован, проведён, отменён.</summary>
    public ViewingStatus Status { get; set; } = ViewingStatus.Planned;

    /// <summary>Получает или задает отзыв клиента.</summary>
    public string? Feedback { get; set; }

    /// <summary>Получает или задает объект.</summary>
    public Property? Property { get; set; }

    /// <summary>Получает или задает клиента.</summary>
    public Client? Client { get; set; }

    /// <summary>Получает или задает риэлтора.</summary>
    public Realtor? Realtor { get; set; }
}
