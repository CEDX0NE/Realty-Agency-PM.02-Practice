namespace RealtyAgency.DataAccess.Entities;

/// <summary>Статус показа.</summary>
public enum ViewingStatus
{
    /// <summary>Запланирован.</summary>
    Planned,

    /// <summary>Проведён.</summary>
    Done,

    /// <summary>Отменён.</summary>
    Cancelled,
}
