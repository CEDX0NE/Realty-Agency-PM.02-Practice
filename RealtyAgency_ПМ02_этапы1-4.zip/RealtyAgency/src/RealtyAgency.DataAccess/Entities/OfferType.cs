namespace RealtyAgency.DataAccess.Entities;

/// <summary>Тип предложения: продажа или аренда.</summary>
public enum OfferType
{
    /// <summary>Продажа.</summary>
    Sale,

    /// <summary>Аренда (цена — за месяц).</summary>
    Rent,
}
