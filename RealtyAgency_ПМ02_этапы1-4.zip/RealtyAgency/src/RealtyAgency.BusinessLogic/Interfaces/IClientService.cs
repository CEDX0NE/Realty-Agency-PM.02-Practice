using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.BusinessLogic.Interfaces;

/// <summary>Клиенты: собственники, покупатели и арендаторы.</summary>
public interface IClientService
{
    /// <summary>Возвращает клиентов, при необходимости — найденных по части ФИО, телефона или e-mail.</summary>
    /// <param name="search">Строка поиска или <see langword="null"/>.</param>
    /// <returns>Список клиентов.</returns>
    Task<List<Client>> GetAllAsync(string? search = null);

    /// <summary>Добавить (Id = 0) или сохранить изменения. Телефон приводится к виду +7 (XXX) XXX-XX-XX.</summary>
    /// <param name="client">Клиент.</param>
    /// <returns>Задача.</returns>
    /// <exception cref="Exceptions.ValidationException">Поля заполнены неверно или телефон занят.</exception>
    Task SaveAsync(Client client);

    /// <summary>Удаляет клиента.</summary>
    /// <param name="id">Код клиента.</param>
    /// <returns>Задача.</returns>
    /// <exception cref="Exceptions.DeleteRestrictedException">Клиент участвует в объектах, показах или сделках.</exception>
    Task DeleteAsync(int id);
}
