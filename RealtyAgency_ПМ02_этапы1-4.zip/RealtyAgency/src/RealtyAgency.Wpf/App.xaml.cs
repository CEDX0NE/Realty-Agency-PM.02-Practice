using System.Diagnostics;
using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using RealtyAgency.BusinessLogic.Logging;
using RealtyAgency.Wpf.Infrastructure;
using RealtyAgency.Wpf.ViewModels;
using RealtyAgency.Wpf.Views;

namespace RealtyAgency.Wpf;

/// <summary>
/// Точка входа и «точка сборки» приложения (Composition Root, Шаг 9 этапа 2):
/// здесь все слои соединяются через интерфейсы с помощью внедрения зависимостей (DI).
/// </summary>
public partial class App : Application
{
    /// <summary>Получает контейнер зависимостей приложения.</summary>
    public static IServiceProvider Services { get; private set; } = null!;

    /// <inheritdoc/>
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        AppEnvironment.UseRussianCulture();
        AppEnvironment.StartLog();
        AppEnvironment.CatchUnhandledErrors(this);

        Services = new ServiceCollection()
            .AddDataAccess(AppEnvironment.ReadConnectionString())
            .AddBusinessLogic()
            .AddPresentation()
            .BuildServiceProvider();

        var window = new MainWindow { DataContext = Services.GetRequiredService<MainViewModel>() };
        MainWindow = window;
        window.Show();
    }

    /// <inheritdoc/>
    protected override void OnExit(ExitEventArgs e)
    {
        AppLog.Info("APP", "Завершение работы");
        Trace.Flush();
        base.OnExit(e);
    }
}
