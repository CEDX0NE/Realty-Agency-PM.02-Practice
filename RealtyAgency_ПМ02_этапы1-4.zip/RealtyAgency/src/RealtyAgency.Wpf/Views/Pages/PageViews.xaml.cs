using System.Windows.Controls;
using System.Windows.Data;

namespace RealtyAgency.Wpf.Views.Pages;

// Code-behind страниц пустой: вся логика — во ViewModel (MVVM).
public partial class DashboardView : UserControl
{
    public DashboardView() => InitializeComponent();
}

public partial class PropertiesView : UserControl
{
    public PropertiesView() => InitializeComponent();
}

public partial class ClientsView : UserControl
{
    public ClientsView() => InitializeComponent();
}

public partial class RealtorsView : UserControl
{
    public RealtorsView() => InitializeComponent();
}

public partial class ViewingsView : UserControl
{
    public ViewingsView() => InitializeComponent();
}

public partial class DealsView : UserControl
{
    public DealsView() => InitializeComponent();
}

public partial class ReportsView : UserControl
{
    public ReportsView() => InitializeComponent();

    /// <summary>
    /// Оформление автоматически созданных колонок отчёта:
    /// привязка через индексатор (имена колонок с пробелами и «₽»)
    /// и формат чисел с разделителем тысяч.
    /// </summary>
    private void Grid_AutoGeneratingColumn(object? sender, DataGridAutoGeneratingColumnEventArgs e)
    {
        if (e.Column is not DataGridTextColumn column)
        {
            return;
        }

        var binding = new Binding($"[{e.PropertyName}]");
        if (e.PropertyType == typeof(decimal) || e.PropertyType == typeof(double))
        {
            binding.StringFormat = "N0";
        }

        column.Binding = binding;
        column.Header = e.PropertyName;
        column.MinWidth = 90;
        column.Width = new DataGridLength(1, DataGridLengthUnitType.Auto);
    }
}
