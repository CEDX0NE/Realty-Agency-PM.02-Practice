using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.DataAccess.Interfaces;

/// <summary>Клиенты.</summary>
public interface IClientRepository
{
    /// <summary>Возвращает клиентов по алфавиту; поиск — по части ФИО, телефона или e-mail.</summary>
    /// <param name="search">Строка поиска или <see langword="null"/>.</param>
    /// <returns>Список клиентов.</returns>
    Task<List<Client>> GetAllAsync(string? search);

    /// <summary>Находит клиента по коду.</summary>
    /// <param name="id">Код клиента.</param>
    /// <returns>Риэлтор или <see langword="null"/>.</returns>
    Task<Client?> GetByIdAsync(int id);

    /// <summary>Проверяет, занят ли телефон другим клиентом.</summary>
    /// <param name="phone">Телефон.</param>
    /// <param name="excludeId">Код клиента, которого не учитывать (при редактировании).</param>
    /// <returns><see langword="true"/>, если телефон занят.</returns>
    Task<bool> PhoneExistsAsync(string phone, int excludeId);

    /// <summary>Добавляет клиента; после вызова заполнен <see cref="Client.Id"/>.</summary>
    /// <param name="client">Риэлтор.</param>
    /// <returns>Задача.</returns>
    Task AddAsync(Client client);

    /// <summary>Сохраняет изменения клиента.</summary>
    /// <param name="client">Риэлтор.</param>
    /// <returns>Задача.</returns>
    Task UpdateAsync(Client client);

    /// <summary>Удаляет клиента.</summary>
    /// <param name="id">Код клиента.</param>
    /// <returns>Задача.</returns>
    Task DeleteAsync(int id);
}
