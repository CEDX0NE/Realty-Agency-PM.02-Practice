using System.Data;
using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.Wpf.Infrastructure;

namespace RealtyAgency.Wpf.ViewModels.Pages;

/// <summary>Описание отчёта для списка слева.</summary>
public sealed record ReportKind(string Key, string Title, string Description, bool NeedsPeriod);

/// <summary>Отчёты с параметрами и выгрузкой в CSV.</summary>
public sealed class ReportsViewModel : PageViewModel
{
    private readonly IReportService _service;

    public ReportsViewModel(IDialogService dialogs, IReportService service)
        : base(dialogs)
    {
        _service = service;
        _selected = Kinds[0];
        BuildCommand = new AsyncRelayCommand(LoadAsync);
        ExportCommand = new RelayCommand(_ => Export(), _ => Table is { Count: > 0 });
    }

    public override string Title => "Отчёты";

    public override string Subtitle => "Выборки по сделкам, сотрудникам и рынку";

    public List<ReportKind> Kinds { get; } = new()
    {
        new("deals", "Сделки за период", "Все сделки с суммой и комиссией", true),
        new("realtors", "Эффективность риэлторов", "Показы, сделки, оборот и комиссия", true),
        new("market", "Рынок по районам", "Средние цены активных объектов", false),
    };

    private ReportKind _selected;

    public ReportKind Selected
    {
        get => _selected;
        set
        {
            if (Set(ref _selected, value))
            {
                _ = LoadAsync();
            }
        }
    }

    private DateTime? _from = new DateTime(DateTime.Today.Year, 1, 1);

    public DateTime? From { get => _from; set => Set(ref _from, value); }

    private DateTime? _to = DateTime.Today;

    public DateTime? To { get => _to; set => Set(ref _to, value); }

    private DataView? _table;

    public DataView? Table { get => _table; private set => Set(ref _table, value); }

    public AsyncRelayCommand BuildCommand { get; }

    public RelayCommand ExportCommand { get; }

    public override Task LoadAsync() => RunAsync(async () =>
    {
        var from = From ?? DateTime.Today.AddYears(-1);
        var to = To ?? DateTime.Today;

        DataTable table = Selected.Key switch
        {
            "deals" => await _service.DealsByPeriodAsync(from, to),
            "realtors" => await _service.RealtorPerformanceAsync(from, to),
            _ => await _service.MarketByDistrictAsync(),
        };

        Table = table.DefaultView;
        Footer = $"Строк в отчёте: {table.Rows.Count}";
    });

    private void Export()
    {
        if (Table is null)
        {
            return;
        }

        var path = Dialogs.AskSavePath($"{Selected.Title} {DateTime.Now:yyyy-MM-dd}.csv", "CSV (Excel)|*.csv");
        if (path is null)
        {
            return;
        }

        try
        {
            _service.ExportCsv(Table.Table!, path);
            Dialogs.Info($"Отчёт сохранён:\n{path}");
        }
        catch (RealtyException ex)
        {
            Dialogs.Error(ex.Message);
        }
    }
}
