using RealtyAgency.DataAccess;
using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.BusinessLogic.Interfaces;

/// <summary>Объекты недвижимости.</summary>
public interface IPropertyService
{
    /// <summary>Ищет объекты по фильтру; границы цены включаются.</summary>
    /// <param name="filter">Параметры поиска.</param>
    /// <returns>Найденные объекты.</returns>
    /// <exception cref="Exceptions.ValidationException">Цена «от» больше цены «до».</exception>
    Task<List<Property>> SearchAsync(PropertyFilter filter);

    /// <summary>Возвращает объекты, доступные для показов и сделок (активные и зарезервированные).</summary>
    /// <returns>Список объектов.</returns>
    Task<List<Property>> GetAvailableAsync();

    /// <summary>Добавить (Id = 0) или сохранить изменения; статус меняется только через сделки.</summary>
    /// <param name="property">Объект.</param>
    /// <returns>Задача.</returns>
    /// <exception cref="Exceptions.ValidationException">Поля заполнены неверно.</exception>
    Task SaveAsync(Property property);

    /// <summary>Удаляет объект вместе с его показами.</summary>
    /// <param name="id">Код объекта.</param>
    /// <returns>Задача.</returns>
    /// <exception cref="Exceptions.DeleteRestrictedException">По объекту есть сделки.</exception>
    Task DeleteAsync(int id);

    /// <summary>Снять с продажи / вернуть в продажу.</summary>
    /// <param name="id">Код объекта.</param>
    /// <returns>Задача.</returns>
    /// <exception cref="Exceptions.PropertyNotAvailableException">Объект зарезервирован или закрыт.</exception>
    Task ToggleArchiveAsync(int id);
}
