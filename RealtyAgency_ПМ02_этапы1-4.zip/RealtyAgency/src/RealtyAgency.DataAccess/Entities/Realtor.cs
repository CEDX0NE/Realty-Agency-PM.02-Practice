namespace RealtyAgency.DataAccess.Entities;

/// <summary>Риэлтор — сотрудник агентства (таблица realtors).</summary>
public class Realtor
{
    /// <summary>Получает или задает код риэлтора.</summary>
    public int Id { get; set; }

    /// <summary>Получает или задает фамилию, имя и отчество.</summary>
    public string FullName { get; set; } = string.Empty;

    /// <summary>Получает или задает телефон в формате +7 (XXX) XXX-XX-XX (уникальный).</summary>
    public string Phone { get; set; } = string.Empty;

    /// <summary>Получает или задает e-mail (необязательно).</summary>
    public string? Email { get; set; }

    /// <summary>Получает или задает процент комиссии с суммы сделки (0–50).</summary>
    public decimal CommissionPercent { get; set; } = 3m;

    /// <summary>Получает или задает дату приёма на работу.</summary>
    public DateTime HireDate { get; set; } = DateTime.Today;

    /// <summary>Получает или задает значение, показывающее, работает ли риэлтор в агентстве.</summary>
    public bool IsActive { get; set; } = true;

    /// <summary>Получает или задает объекты, за которые отвечает риэлтор.</summary>
    public ICollection<Property> Properties { get; set; } = new List<Property>();

    /// <summary>Получает или задает показы, проведённые риэлтором.</summary>
    public ICollection<Viewing> Viewings { get; set; } = new List<Viewing>();

    /// <summary>Получает или задает сделки риэлтора.</summary>
    public ICollection<Deal> Deals { get; set; } = new List<Deal>();

    /// <inheritdoc/>
    public override string ToString() => FullName;
}
