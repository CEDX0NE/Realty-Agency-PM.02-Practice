using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.BusinessLogic.Logging;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Interfaces;

namespace RealtyAgency.BusinessLogic.Services;

/// <summary>Риэлторы.</summary>
public class RealtorService : ServiceBase, IRealtorService
{
    private readonly IRealtorRepository _repo;

    /// <summary>Инициализирует новый экземпляр класса <see cref="RealtorService"/>.</summary>
    /// <param name="repo">Репозиторий риэлторов.</param>
    public RealtorService(IRealtorRepository repo) => _repo = repo;

    /// <inheritdoc/>
    public Task<List<Realtor>> GetAllAsync(bool onlyActive = false) =>
        GuardAsync("Список риэлторов", () => _repo.GetAllAsync(onlyActive));

    /// <inheritdoc/>
    public Task SaveAsync(Realtor realtor) =>
        GuardAsync($"Сохранение риэлтора «{realtor.FullName}»", async () =>
        {
            realtor.FullName = realtor.FullName.Trim();
            realtor.Phone = Validator.NormalizePhone(realtor.Phone);
            realtor.Email = Validator.Clean(realtor.Email);

            new Validator()
                .Require(realtor.FullName.Length >= Limits.MinNameLength, $"ФИО риэлтора — не короче {Limits.MinNameLength} символов")
                .Require(Validator.IsPhone(realtor.Phone), "Телефон — минимум 10 цифр, например +7 (900) 123-45-67")
                .Require(Validator.IsEmailOrEmpty(realtor.Email), "E-mail указан неверно")
                .Require(
                    realtor.CommissionPercent >= 0m && realtor.CommissionPercent <= Limits.MaxCommissionPercent,
                    $"Комиссия — от 0 до {Limits.MaxCommissionPercent} %")
                .Require(realtor.HireDate <= DateTime.Today, "Дата приёма не может быть в будущем")
                .ThrowIfInvalid();

            if (await _repo.PhoneExistsAsync(realtor.Phone, realtor.Id))
            {
                throw new ValidationException("Риэлтор с таким телефоном уже есть");
            }

            if (realtor.Id == 0)
            {
                await _repo.AddAsync(realtor);
            }
            else
            {
                await _repo.UpdateAsync(realtor);
            }

            AppLog.Info("BLL", $"Риэлтор сохранён: ID={realtor.Id}, {realtor.FullName}");
        });

    /// <inheritdoc/>
    public Task DeleteAsync(int id) =>
        GuardAsync($"Удаление риэлтора ID={id}", () => DeleteOrExplainAsync(
            () => _repo.DeleteAsync(id),
            "У риэлтора есть объекты, показы или сделки — удалить его нельзя. " +
            "Снимите галочку «Работает», чтобы скрыть его из списков."));
}
