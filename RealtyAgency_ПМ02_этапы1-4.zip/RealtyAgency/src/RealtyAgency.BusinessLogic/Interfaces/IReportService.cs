using System.Data;
using RealtyAgency.DataAccess;

namespace RealtyAgency.BusinessLogic.Interfaces;

/// <summary>Отчёты и экспорт в CSV.</summary>
public interface IReportService
{
    /// <summary>Возвращает показатели главной страницы.</summary>
    /// <returns>Сводные показатели.</returns>
    Task<DashboardStats> GetDashboardAsync();

    /// <summary>Сделки за период (обе даты включаются).</summary>
    /// <param name="dateFrom">Первый день периода.</param>
    /// <param name="dateTo">Последний день периода.</param>
    /// <returns>Таблица отчёта.</returns>
    Task<DataTable> DealsByPeriodAsync(DateTime dateFrom, DateTime dateTo);

    /// <summary>Показы, закрытые сделки, оборот и комиссия по каждому риэлтору за период.</summary>
    /// <param name="dateFrom">Первый день периода.</param>
    /// <param name="dateTo">Последний день периода.</param>
    /// <returns>Таблица отчёта.</returns>
    Task<DataTable> RealtorPerformanceAsync(DateTime dateFrom, DateTime dateTo);

    /// <summary>Средние цены по районам и типам недвижимости.</summary>
    /// <returns>Таблица отчёта.</returns>
    Task<DataTable> MarketByDistrictAsync();

    /// <summary>Сохранить таблицу в CSV (разделитель «;», открывается в Excel).</summary>
    /// <param name="table">Таблица отчёта.</param>
    /// <param name="path">Путь к файлу.</param>
    void ExportCsv(DataTable table, string path);
}
