namespace RealtyAgency.BusinessLogic.Exceptions;

/// <summary>Недопустимая операция с учётом текущего состояния данных.</summary>
public class BusinessRuleException : RealtyException
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="BusinessRuleException"/>.</summary>
    /// <param name="message">Текст для пользователя.</param>
    public BusinessRuleException(string message)
        : base(message)
    {
    }
}
