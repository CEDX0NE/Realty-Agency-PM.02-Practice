# =====================================================================
#  Запуск всех тестов с измерением покрытия (этап 3).
#  Требуется: .NET 8 SDK и запущенный MySQL 8 (тестовая база
#  realty_agency_test создаётся автоматически, рабочая не трогается).
#  Пароль root задаётся в tests/RealtyAgency.Tests/testsettings.json
#  или переменной окружения REALTY_TEST_MYSQL.
# =====================================================================
$ErrorActionPreference = "Stop"
Remove-Item -Recurse -Force TestResults, coverage -ErrorAction SilentlyContinue

dotnet test tests/RealtyAgency.Tests --collect:"XPlat Code Coverage" --results-directory TestResults --logger "trx;LogFileName=results.trx"

# HTML-отчёт о покрытии (один раз: dotnet tool install -g dotnet-reportgenerator-globaltool)
reportgenerator -reports:"TestResults/*/coverage.cobertura.xml" -targetdir:coverage -reporttypes:"Html;TextSummary"
Get-Content coverage/Summary.txt -TotalCount 18
Start-Process coverage/index.html
