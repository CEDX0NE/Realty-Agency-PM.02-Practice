using Microsoft.EntityFrameworkCore;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Interfaces;

namespace RealtyAgency.DataAccess.Repositories;

/// <summary>Справочники (районы, типы недвижимости).</summary>
public class ReferenceRepository : RepositoryBase, IReferenceRepository
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="ReferenceRepository"/>.</summary>
    /// <param name="factory">Фабрика контекстов EF Core.</param>
    public ReferenceRepository(IDbContextFactory<RealtyDbContext> factory)
        : base(factory)
    {
    }

    /// <inheritdoc/>
    public Task<List<District>> GetDistrictsAsync() =>
        QueryAsync("Справочник районов", db =>
            db.Districts.AsNoTracking().OrderBy(x => x.Name).ToListAsync());

    /// <inheritdoc/>
    public Task<List<PropertyType>> GetPropertyTypesAsync() =>
        QueryAsync("Справочник типов недвижимости", db =>
            db.PropertyTypes.AsNoTracking().OrderBy(x => x.Name).ToListAsync());
}
