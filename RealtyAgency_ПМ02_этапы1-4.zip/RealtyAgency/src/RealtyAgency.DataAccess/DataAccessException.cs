namespace RealtyAgency.DataAccess;

/// <summary>
/// Исключение слоя доступа к данным. Скрывает от верхних слоёв
/// конкретные типы ошибок MySQL / EF Core.
/// </summary>
public class DataAccessException : Exception
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="DataAccessException"/>.</summary>
    /// <param name="message">Понятный пользователю текст.</param>
    /// <param name="kind">Вид ошибки.</param>
    /// <param name="inner">Исходное исключение MySQL / EF Core.</param>
    public DataAccessException(string message, DbErrorKind kind, Exception? inner = null)
        : base(message, inner)
    {
        Kind = kind;
    }

    /// <summary>Получает вид ошибки.</summary>
    public DbErrorKind Kind { get; }
}
