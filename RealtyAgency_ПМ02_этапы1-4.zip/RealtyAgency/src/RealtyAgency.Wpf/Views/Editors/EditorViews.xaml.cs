using System.Windows.Controls;

namespace RealtyAgency.Wpf.Views.Editors;

// Разметка форм редактирования. Логика — в ViewModels/Editors.
public partial class PropertyEditorView : UserControl
{
    public PropertyEditorView() => InitializeComponent();
}

public partial class ClientEditorView : UserControl
{
    public ClientEditorView() => InitializeComponent();
}

public partial class RealtorEditorView : UserControl
{
    public RealtorEditorView() => InitializeComponent();
}

public partial class ViewingEditorView : UserControl
{
    public ViewingEditorView() => InitializeComponent();
}

public partial class DealEditorView : UserControl
{
    public DealEditorView() => InitializeComponent();
}
