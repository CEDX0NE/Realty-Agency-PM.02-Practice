using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Repositories;

namespace RealtyAgency.Tests.Integration;

/// <summary>Операции чтения и записи справочников, риэлторов и показов.</summary>
public class CrudIntegrationTests : IntegrationTestBase
{
    public CrudIntegrationTests(MySqlDatabase db)
        : base(db)
    {
    }

    [Fact]
    public async Task References_LoadedSortedByName()
    {
        var repo = new ReferenceRepository(Db.ContextFactory());

        var districts = await repo.GetDistrictsAsync();
        var types = await repo.GetPropertyTypesAsync();

        Assert.Equal(6, districts.Count);
        Assert.Equal(districts.Select(d => d.Name).OrderBy(n => n), districts.Select(d => d.Name));
        Assert.Equal(6, types.Count);
    }

    [Fact]
    [Trait("TC", "ТК-22")]
    public async Task Realtor_AddUpdateDelete()
    {
        var repo = new RealtorRepository(Db.ContextFactory());
        var realtor = new Realtor { FullName = "Новиков Пётр Ильич", Phone = "+7 (901) 111-22-09", CommissionPercent = 2.75m };

        await repo.AddAsync(realtor);
        realtor.IsActive = false;
        await repo.UpdateAsync(realtor);
        var active = await repo.GetAllAsync(onlyActive: true);
        var loaded = await repo.GetByIdAsync(realtor.Id);
        var phoneTaken = await repo.PhoneExistsAsync("+7 (901) 111-22-09", 0);
        await repo.DeleteAsync(realtor.Id);

        Assert.Equal(2.75m, loaded!.CommissionPercent);
        Assert.False(loaded.IsActive);
        Assert.DoesNotContain(active, r => r.Id == realtor.Id);
        Assert.True(phoneTaken);
        Assert.Null(await repo.GetByIdAsync(realtor.Id));
    }

    [Fact]
    public async Task Viewing_AddUpdateFilterDelete()
    {
        var repo = new ViewingRepository(Db.ContextFactory());
        var viewing = new Viewing { PropertyId = 6, ClientId = 2, RealtorId = 2, ScheduledAt = DateTime.Today.AddDays(5).AddHours(10) };

        await repo.AddAsync(viewing);
        viewing.Status = ViewingStatus.Cancelled;
        viewing.Feedback = "Перенос";
        await repo.UpdateAsync(viewing);
        var cancelled = await repo.GetAllAsync(ViewingStatus.Cancelled);
        await repo.DeleteAsync(viewing.Id);

        Assert.Contains(cancelled, v => v.Id == viewing.Id && v.Feedback == "Перенос" && v.Property != null);
        Assert.Null(await repo.GetByIdAsync(viewing.Id));
    }

    [Fact]
    public async Task Deals_FilterByStatus()
    {
        var repo = new DealRepository(Db.ContextFactory());

        var completed = await repo.GetAllAsync(DealStatus.Completed);
        var hasOpen = await repo.HasOpenDealAsync(5);

        Assert.Equal(2, completed.Count);
        Assert.All(completed, d => Assert.NotNull(d.Realtor));
        Assert.True(hasOpen);
    }
}
