using System.Diagnostics;
using Microsoft.EntityFrameworkCore;

namespace RealtyAgency.DataAccess.Repositories;

/// <summary>
/// Базовый класс репозиториев. Каждая операция:
///  1) создаёт короткоживущий DbContext (нет «залипших» данных между окнами);
///  2) пишет в журнал (Trace) начало, время выполнения и ошибки;
///  3) переводит ошибки MySQL/EF в DataAccessException.
/// </summary>
public abstract class RepositoryBase
{
    private readonly IDbContextFactory<RealtyDbContext> _factory;

    /// <summary>Инициализирует новый экземпляр класса <see cref="RepositoryBase"/>.</summary>
    /// <param name="factory">Фабрика контекстов EF Core.</param>
    protected RepositoryBase(IDbContextFactory<RealtyDbContext> factory) => _factory = factory;

    /// <summary>Создаёт исключение «запись не найдена».</summary>
    /// <param name="what">Что искали («Объект», «Сделка»…).</param>
    /// <param name="id">Код записи.</param>
    /// <returns>Исключение для броска.</returns>
    protected static DataAccessException NotFound(string what, int id) =>
        new($"{what} с ID={id} не найден(а) — возможно, запись уже удалена.", DbErrorKind.NotFound);

    /// <summary>Выполняет запрос в новом контексте с журналом и переводом ошибок.</summary>
    /// <typeparam name="T">Тип результата.</typeparam>
    /// <param name="operation">Название операции для журнала.</param>
    /// <param name="action">Запрос.</param>
    /// <returns>Результат запроса.</returns>
    protected async Task<T> QueryAsync<T>(string operation, Func<RealtyDbContext, Task<T>> action)
    {
        var sw = Stopwatch.StartNew();
        Debug.WriteLine($"[DAL] -> {operation}");
        try
        {
            await using var db = await _factory.CreateDbContextAsync();
            var result = await action(db);
            Trace.WriteLine($"[DAL] {operation}: OK ({sw.ElapsedMilliseconds} мс)");
            return result;
        }
        catch (Exception ex) when (ex is not DataAccessException && DbErrorTranslator.IsDbError(ex))
        {
            var translated = DbErrorTranslator.Translate(ex);
            Trace.WriteLine($"[DAL][ERROR] {operation}: {translated.Kind} — {ex.GetBaseException().Message}");
            throw translated;
        }
    }

    /// <summary>Выполняет изменение данных в новом контексте с журналом и переводом ошибок.</summary>
    /// <param name="operation">Название операции для журнала.</param>
    /// <param name="action">Изменение.</param>
    /// <returns>Задача.</returns>
    protected Task ExecuteAsync(string operation, Func<RealtyDbContext, Task> action) =>
        QueryAsync<bool>(operation, async db =>
        {
            await action(db);
            return true;
        });
}
