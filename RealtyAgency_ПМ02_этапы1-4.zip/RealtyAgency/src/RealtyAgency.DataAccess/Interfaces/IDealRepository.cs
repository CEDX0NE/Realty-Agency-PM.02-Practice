using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.DataAccess.Interfaces;

/// <summary>Сделки.</summary>
public interface IDealRepository
{
    /// <summary>Возвращает сделки, новые — первыми.</summary>
    /// <param name="status">Статус для отбора или <see langword="null"/> — все.</param>
    /// <returns>Список сделок.</returns>
    Task<List<Deal>> GetAllAsync(DealStatus? status);

    /// <summary>Находит сделку по коду.</summary>
    /// <param name="id">Код сделки.</param>
    /// <returns>Сделка или <see langword="null"/>.</returns>
    Task<Deal?> GetByIdAsync(int id);

    /// <summary>Есть ли по объекту открытая сделка.</summary>
    /// <param name="propertyId">Код объекта.</param>
    /// <returns><see langword="true"/>, если есть.</returns>
    Task<bool> HasOpenDealAsync(int propertyId);

    /// <summary>Создать сделку и в той же транзакции сменить статус объекта.</summary>
    /// <param name="deal">Сделка.</param>
    /// <param name="newPropertyStatus">Новый статус объекта.</param>
    /// <returns>Задача.</returns>
    Task CreateAsync(Deal deal, PropertyStatus newPropertyStatus);

    /// <summary>Сменить статус сделки и в той же транзакции — статус объекта.</summary>
    /// <param name="dealId">Код сделки.</param>
    /// <param name="status">Новый статус сделки.</param>
    /// <param name="newPropertyStatus">Новый статус объекта.</param>
    /// <returns>Задача.</returns>
    Task ChangeStatusAsync(int dealId, DealStatus status, PropertyStatus newPropertyStatus);
}
