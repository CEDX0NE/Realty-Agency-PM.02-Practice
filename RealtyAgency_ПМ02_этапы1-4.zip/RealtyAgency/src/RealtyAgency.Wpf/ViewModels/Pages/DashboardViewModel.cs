using System.Collections.ObjectModel;
using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.DataAccess;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.Wpf.Infrastructure;

namespace RealtyAgency.Wpf.ViewModels.Pages;

/// <summary>Главная: ключевые показатели, ближайшие показы, последние сделки.</summary>
public sealed class DashboardViewModel : PageViewModel
{
    private readonly IReportService _reports;
    private readonly IViewingService _viewings;
    private readonly IDealService _deals;

    public DashboardViewModel(
        IDialogService dialogs,
        IReportService reports,
        IViewingService viewings,
        IDealService deals)
        : base(dialogs)
    {
        _reports = reports;
        _viewings = viewings;
        _deals = deals;
        RefreshCommand = new AsyncRelayCommand(LoadAsync);
    }

    public override string Title => "Главная";

    public override string Subtitle => $"Сводка по агентству на {DateTime.Now:dd MMMM yyyy}";

    public AsyncRelayCommand RefreshCommand { get; }

    private DashboardStats? _stats;

    public DashboardStats? Stats { get => _stats; private set => Set(ref _stats, value); }

    public ObservableCollection<Viewing> UpcomingViewings { get; } = new();

    public ObservableCollection<Deal> RecentDeals { get; } = new();

    public override Task LoadAsync() => RunAsync(async () =>
    {
        Stats = await _reports.GetDashboardAsync();

        var viewings = await _viewings.GetAllAsync(ViewingStatus.Planned);
        UpcomingViewings.Clear();
        foreach (var v in viewings.Where(v => v.ScheduledAt >= DateTime.Now)
                                  .OrderBy(v => v.ScheduledAt).Take(6))
        {
            UpcomingViewings.Add(v);
        }

        var deals = await _deals.GetAllAsync();
        RecentDeals.Clear();
        foreach (var d in deals.Take(6))
        {
            RecentDeals.Add(d);
        }
    });
}
