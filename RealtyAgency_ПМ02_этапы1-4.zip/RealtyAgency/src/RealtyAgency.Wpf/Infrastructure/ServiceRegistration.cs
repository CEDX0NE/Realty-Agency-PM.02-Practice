using System.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.BusinessLogic.Services;
using RealtyAgency.DataAccess;
using RealtyAgency.DataAccess.Interfaces;
using RealtyAgency.DataAccess.Repositories;
using RealtyAgency.Wpf.ViewModels;
using RealtyAgency.Wpf.ViewModels.Pages;

namespace RealtyAgency.Wpf.Infrastructure;

/// <summary>
/// Регистрация зависимостей по слоям (Composition Root). Раньше всё было в одном
/// методе App.ConfigureServices — анализатор CA1506 отмечал чрезмерную связанность класса App.
/// </summary>
public static class ServiceRegistration
{
    /// <summary>Версия сервера MySQL, под которую Pomelo строит SQL.</summary>
    private static readonly MySqlServerVersion ServerVersion = new(new Version(8, 0, 36));

    /// <summary>Слой доступа к данным: контекст EF Core и репозитории.</summary>
    public static IServiceCollection AddDataAccess(this IServiceCollection services, string connectionString)
    {
        services.AddSingleton(new DbSettings(connectionString));
        services.AddDbContextFactory<RealtyDbContext>(options =>
        {
            options.UseMySql(connectionString, ServerVersion)
                   .UseSnakeCaseNamingConvention();
#if DEBUG
            // SQL-запросы EF Core видны в окне Output при отладке
            options.LogTo(message => Debug.WriteLine(message), LogLevel.Information)
                   .EnableSensitiveDataLogging();
#endif
        });

        services.AddTransient<IReferenceRepository, ReferenceRepository>();
        services.AddTransient<IRealtorRepository, RealtorRepository>();
        services.AddTransient<IClientRepository, ClientRepository>();
        services.AddTransient<IPropertyRepository, PropertyRepository>();
        services.AddTransient<IViewingRepository, ViewingRepository>();
        services.AddTransient<IDealRepository, DealRepository>();
        services.AddTransient<IReportRepository, ReportRepository>();
        return services;
    }

    /// <summary>Слой бизнес-логики: сервисы.</summary>
    public static IServiceCollection AddBusinessLogic(this IServiceCollection services)
    {
        services.AddSingleton<IReferenceService, ReferenceService>();   // кэш справочников
        services.AddTransient<IRealtorService, RealtorService>();
        services.AddTransient<IClientService, ClientService>();
        services.AddTransient<IPropertyService, PropertyService>();
        services.AddTransient<IViewingService, ViewingService>();
        services.AddTransient<IDealService, DealService>();
        services.AddTransient<IReportService, ReportService>();
        return services;
    }

    /// <summary>Слой представления: диалоги и модели представления.</summary>
    public static IServiceCollection AddPresentation(this IServiceCollection services)
    {
        services.AddSingleton<IDialogService, DialogService>();
        services.AddTransient<EditorFactory>();
        services.AddSingleton<MainViewModel>();
        services.AddTransient<DashboardViewModel>();
        services.AddTransient<PropertiesViewModel>();
        services.AddTransient<ClientsViewModel>();
        services.AddTransient<RealtorsViewModel>();
        services.AddTransient<ViewingsViewModel>();
        services.AddTransient<DealsViewModel>();
        services.AddTransient<ReportsViewModel>();
        return services;
    }
}
