# Простое приложение на Tkinter для работы с отдельной базой realty_tk (MySQL).
# База и таблица создаются автоматически при первом запуске.
# Библиотека pymysql лежит в папке рядом с программой — устанавливать ничего не нужно.
import tkinter as tk
from tkinter import ttk, messagebox

import pymysql

# Настройки подключения к MySQL
DB_NAME = "realty_tk"
DB = dict(host="localhost", port=3306, user="root", password="", charset="utf8mb4")


def connect():
    return pymysql.connect(database=DB_NAME, **DB)


def create_database():
    """Создаёт базу realty_tk и таблицу clients, если их ещё нет."""
    with pymysql.connect(**DB) as con, con.cursor() as cur:
        cur.execute(f"CREATE DATABASE IF NOT EXISTS {DB_NAME} CHARACTER SET utf8mb4")
        cur.execute(f"USE {DB_NAME}")
        cur.execute("""CREATE TABLE IF NOT EXISTS clients (
                           id INT AUTO_INCREMENT PRIMARY KEY,
                           full_name VARCHAR(150) NOT NULL,
                           phone VARCHAR(20) NOT NULL,
                           email VARCHAR(100) NULL)""")
        con.commit()


def load_clients():
    """Читает всех клиентов из БД и показывает их в таблице."""
    table.delete(*table.get_children())
    try:
        with connect() as con, con.cursor() as cur:
            cur.execute("SELECT id, full_name, phone, email FROM clients ORDER BY full_name")
            for client_id, name, phone, email in cur.fetchall():
                # iid = id клиента, чтобы потом знать, какую запись выбрали
                table.insert("", "end", iid=str(client_id), values=(client_id, name, phone, email or ""))
    except pymysql.MySQLError as e:
        messagebox.showerror("Ошибка", f"Не удалось подключиться к БД:\n{e}")


def add_client():
    name, phone, email = name_var.get().strip(), phone_var.get().strip(), email_var.get().strip()
    if not name or not phone:
        messagebox.showwarning("Внимание", "Заполните ФИО и телефон")
        return
    try:
        with connect() as con, con.cursor() as cur:
            # Значения передаются параметрами %s — защита от SQL-инъекций
            cur.execute("INSERT INTO clients (full_name, phone, email) VALUES (%s, %s, %s)",
                        (name, phone, email or None))
            con.commit()
        clear_fields()
        load_clients()
    except pymysql.MySQLError as e:
        messagebox.showerror("Ошибка", f"Не удалось добавить клиента:\n{e}")


def update_client():
    selected = table.selection()
    if not selected:
        messagebox.showwarning("Внимание", "Выберите клиента в таблице")
        return
    client_id = int(selected[0])
    try:
        with connect() as con, con.cursor() as cur:
            cur.execute("UPDATE clients SET full_name = %s, phone = %s, email = %s WHERE id = %s",
                        (name_var.get().strip(), phone_var.get().strip(), email_var.get().strip() or None, client_id))
            con.commit()
        load_clients()
    except pymysql.MySQLError as e:
        messagebox.showerror("Ошибка", f"Не удалось изменить клиента:\n{e}")


def delete_client():
    selected = table.selection()
    if not selected:
        messagebox.showwarning("Внимание", "Выберите клиента в таблице")
        return
    client_id = int(selected[0])
    if not messagebox.askyesno("Удаление", "Удалить выбранного клиента?"):
        return
    try:
        with connect() as con, con.cursor() as cur:
            cur.execute("DELETE FROM clients WHERE id = %s", (client_id,))
            con.commit()
        clear_fields()
        load_clients()
    except pymysql.MySQLError as e:
        messagebox.showerror("Ошибка", f"Не удалось удалить клиента:\n{e}")


def on_select(event):
    """При выборе строки — переносим данные клиента в поля ввода."""
    selected = table.selection()
    if selected:
        _, name, phone, email = (table.set(selected[0], col) for col in ("id", "name", "phone", "email"))
        name_var.set(name)
        phone_var.set(phone)
        email_var.set(email)


def clear_fields():
    name_var.set("")
    phone_var.set("")
    email_var.set("")


# ---------- Окно ----------
root = tk.Tk()
root.title("Риэлторское агентство — клиенты")
root.geometry("760x460")

form = ttk.Frame(root, padding=10)
form.pack(fill="x")
name_var, phone_var, email_var = tk.StringVar(), tk.StringVar(), tk.StringVar()
for i, (text, var) in enumerate((("ФИО:", name_var), ("Телефон:", phone_var), ("E-mail:", email_var))):
    ttk.Label(form, text=text).grid(row=i, column=0, sticky="w", pady=2)
    ttk.Entry(form, textvariable=var, width=45).grid(row=i, column=1, sticky="w", pady=2)

buttons = ttk.Frame(root, padding=(10, 0))
buttons.pack(fill="x")
ttk.Button(buttons, text="Добавить", command=add_client).pack(side="left", padx=2)
ttk.Button(buttons, text="Изменить", command=update_client).pack(side="left", padx=2)
ttk.Button(buttons, text="Удалить", command=delete_client).pack(side="left", padx=2)
ttk.Button(buttons, text="Обновить", command=load_clients).pack(side="left", padx=2)
ttk.Button(buttons, text="Очистить поля", command=clear_fields).pack(side="left", padx=2)

table = ttk.Treeview(root, columns=("id", "name", "phone", "email"), show="headings")
for col, title, width in (("id", "ID", 50), ("name", "ФИО", 270), ("phone", "Телефон", 160), ("email", "E-mail", 220)):
    table.heading(col, text=title)
    table.column(col, width=width)
table.pack(fill="both", expand=True, padx=10, pady=10)
table.bind("<<TreeviewSelect>>", on_select)

try:
    create_database()
except pymysql.MySQLError as e:
    messagebox.showerror("Ошибка", f"Не удалось подключиться к MySQL (проверьте пароль в DB):\n{e}")
load_clients()
root.mainloop()
