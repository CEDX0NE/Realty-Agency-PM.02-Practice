-- =====================================================================
--  Аудит изменений объектов и сделок. Запускать после 01_schema.sql
-- =====================================================================
USE realty_agency;

DROP TRIGGER IF EXISTS trg_properties_audit_insert;
DROP TRIGGER IF EXISTS trg_properties_audit_update;
DROP TRIGGER IF EXISTS trg_properties_audit_delete;
DROP TRIGGER IF EXISTS trg_deals_audit_insert;
DROP TRIGGER IF EXISTS trg_deals_audit_update;

DELIMITER $$

CREATE TRIGGER trg_properties_audit_insert
AFTER INSERT ON properties FOR EACH ROW
BEGIN
    INSERT INTO audit_log(who, what_action, table_name, record_id, details)
    VALUES (USER(), 'INSERT', 'properties', NEW.id,
            CONCAT('address=', NEW.address, ', price=', NEW.price));
END$$

CREATE TRIGGER trg_properties_audit_update
AFTER UPDATE ON properties FOR EACH ROW
BEGIN
    INSERT INTO audit_log(who, what_action, table_name, record_id, details)
    VALUES (USER(), 'UPDATE', 'properties', NEW.id,
            CONCAT('price: ', OLD.price, ' -> ', NEW.price,
                   '; status: ', OLD.status, ' -> ', NEW.status));
END$$

CREATE TRIGGER trg_properties_audit_delete
AFTER DELETE ON properties FOR EACH ROW
BEGIN
    INSERT INTO audit_log(who, what_action, table_name, record_id, details)
    VALUES (USER(), 'DELETE', 'properties', OLD.id, CONCAT('address=', OLD.address));
END$$

CREATE TRIGGER trg_deals_audit_insert
AFTER INSERT ON deals FOR EACH ROW
BEGIN
    INSERT INTO audit_log(who, what_action, table_name, record_id, details)
    VALUES (USER(), 'INSERT', 'deals', NEW.id,
            CONCAT('property=', NEW.property_id, ', amount=', NEW.amount, ', status=', NEW.status));
END$$

CREATE TRIGGER trg_deals_audit_update
AFTER UPDATE ON deals FOR EACH ROW
BEGIN
    INSERT INTO audit_log(who, what_action, table_name, record_id, details)
    VALUES (USER(), 'UPDATE', 'deals', NEW.id,
            CONCAT('status: ', OLD.status, ' -> ', NEW.status));
END$$

DELIMITER ;
