using System.Data;
using RealtyAgency.BusinessLogic.Services;
using RealtyAgency.DataAccess;
using RealtyAgency.DataAccess.Repositories;

namespace RealtyAgency.Tests.Integration;

/// <summary>Отчёты (ADO.NET, параметризованные запросы).</summary>
public class ReportIntegrationTests : IntegrationTestBase
{
    public ReportIntegrationTests(MySqlDatabase db)
        : base(db)
    {
    }

    private ReportService Service() => new(new ReportRepository(new DbSettings(Db.ConnectionString)));

    private static decimal Sum(DataTable table, string column) =>
        table.Rows.Cast<DataRow>().Sum(r => Convert.ToDecimal(r[column]));

    [Fact]
    [Trait("TC", "ТК-18")]
    public async Task DealsByPeriod_IncludesWholeLastDay()
    {
        var day = await Db.ScalarAsync<DateTime>("SELECT deal_date FROM deals WHERE id = 1");

        var table = await Service().DealsByPeriodAsync(day.Date, day.Date);

        Assert.Equal(1, table.Rows.Count);
        Assert.Equal(12_300_000m, Convert.ToDecimal(table.Rows[0]["Сумма ₽"]));
    }

    [Fact]
    [Trait("TC", "ТК-18")]
    public async Task RealtorPerformance_TotalsMatchCompletedDeals()
    {
        var table = await Service().RealtorPerformanceAsync(DateTime.Today.AddDays(-60), DateTime.Today);

        Assert.Equal(370_125m, Sum(table, "Комиссия ₽"));
        Assert.Equal(2, (int)Sum(table, "Сделок закрыто"));
    }

    [Fact]
    [Trait("TC", "ТК-18")]
    [Trait("Defect", "DEF-03")]
    public async Task RealtorPerformance_DismissedRealtorDealsStillCounted()
    {
        // Риэлтор Орлова закрыла сделку и уволилась — комиссия агентства за период не должна «пропасть»
        await Db.ExecuteAsync("UPDATE realtors SET is_active = 0 WHERE id = 1");

        var table = await Service().RealtorPerformanceAsync(DateTime.Today.AddDays(-60), DateTime.Today);

        Assert.Equal(370_125m, Sum(table, "Комиссия ₽"));
    }

    [Fact]
    public async Task MarketByDistrict_CountsOnlyAvailableProperties()
    {
        var table = await Service().MarketByDistrictAsync();

        Assert.Equal(11, (int)Sum(table, "Объектов"));
    }

    [Fact]
    [Trait("TC", "ТК-24")]
    public async Task Dashboard_ReturnsCurrentCounts()
    {
        var stats = await Service().GetDashboardAsync();

        Assert.Equal(10, stats.ActiveProperties);
        Assert.Equal(1, stats.OpenDeals);
        Assert.Equal(12, stats.ClientsCount);
        Assert.Equal(4, stats.UpcomingViewings);
    }
}
