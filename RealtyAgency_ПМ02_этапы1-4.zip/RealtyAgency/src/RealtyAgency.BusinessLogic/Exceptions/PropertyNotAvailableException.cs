namespace RealtyAgency.BusinessLogic.Exceptions;

/// <summary>Объект недоступен для показа/сделки (уже продан, снят, зарезервирован).</summary>
public class PropertyNotAvailableException : RealtyException
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="PropertyNotAvailableException"/>.</summary>
    /// <param name="propertyId">Код объекта.</param>
    /// <param name="message">Текст для пользователя.</param>
    public PropertyNotAvailableException(int propertyId, string message)
        : base(message)
    {
        PropertyId = propertyId;
    }

    /// <summary>Получает код объекта, по которому операция невозможна.</summary>
    public int PropertyId { get; }
}
