namespace RealtyAgency.DataAccess.Entities;

/// <summary>Район города (справочник, таблица districts).</summary>
public class District
{
    /// <summary>Получает или задает код района.</summary>
    public int Id { get; set; }

    /// <summary>Получает или задает название района (уникальное).</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>Получает или задает объекты в этом районе.</summary>
    public ICollection<Property> Properties { get; set; } = new List<Property>();

    /// <inheritdoc/>
    public override string ToString() => Name;
}
