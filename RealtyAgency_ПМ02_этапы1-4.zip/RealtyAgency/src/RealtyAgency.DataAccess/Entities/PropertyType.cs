namespace RealtyAgency.DataAccess.Entities;

/// <summary>Тип недвижимости: квартира, дом, коммерческое помещение… (справочник, таблица property_types).</summary>
public class PropertyType
{
    /// <summary>Получает или задает код типа.</summary>
    public int Id { get; set; }

    /// <summary>Получает или задает название типа (уникальное).</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>Получает или задает объекты этого типа.</summary>
    public ICollection<Property> Properties { get; set; } = new List<Property>();

    /// <inheritdoc/>
    public override string ToString() => Name;
}
