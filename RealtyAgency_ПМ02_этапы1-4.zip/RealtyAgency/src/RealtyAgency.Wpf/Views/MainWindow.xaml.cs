using System.Windows;
using RealtyAgency.Wpf.ViewModels;

namespace RealtyAgency.Wpf.Views;

public partial class MainWindow : Window
{
    public MainWindow() => InitializeComponent();

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
        // Открываем «Главную» после показа окна
        if (DataContext is MainViewModel vm && vm.SelectedNav is null)
        {
            vm.SelectedNav = vm.NavItems[0];
        }
    }
}
