using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Markup;
using System.Windows.Threading;
using Microsoft.Extensions.Configuration;
using RealtyAgency.BusinessLogic.Logging;

namespace RealtyAgency.Wpf.Infrastructure;

/// <summary>Настройка окружения при запуске: культура, журнал, перехват ошибок, конфигурация.</summary>
public static class AppEnvironment
{
    /// <summary>Русская культура: формат чисел «12 500 000», дат «07.10.2026».</summary>
    public static void UseRussianCulture()
    {
        var ru = CultureInfo.GetCultureInfo("ru-RU");
        CultureInfo.DefaultThreadCurrentCulture = ru;
        CultureInfo.DefaultThreadCurrentUICulture = ru;
        Thread.CurrentThread.CurrentCulture = ru;
        Thread.CurrentThread.CurrentUICulture = ru;
        FrameworkElement.LanguageProperty.OverrideMetadata(
            typeof(FrameworkElement),
            new FrameworkPropertyMetadata(XmlLanguage.GetLanguage(ru.IetfLanguageTag)));
    }

    /// <summary>Журнал Trace → logs/realty_ГГГГ-ММ-ДД.log рядом с .exe.</summary>
    public static void StartLog() => AppLog.Init(Path.Combine(AppContext.BaseDirectory, "logs"));

    /// <summary>Глобальная обработка непредвиденных ошибок — приложение не «вылетает».</summary>
    /// <param name="app">Приложение WPF.</param>
    public static void CatchUnhandledErrors(Application app)
    {
        app.DispatcherUnhandledException += OnDispatcherUnhandledException;
        AppDomain.CurrentDomain.UnhandledException += OnDomainUnhandledException;
        TaskScheduler.UnobservedTaskException += OnUnobservedTaskException;
    }

    /// <summary>Строка подключения «RealtyAgency» из appsettings.json.</summary>
    /// <returns>Строка подключения к MySQL.</returns>
    public static string ReadConnectionString()
    {
        var config = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: false)
            .Build();
        return config.GetConnectionString("RealtyAgency")
            ?? throw new InvalidOperationException("В appsettings.json нет строки подключения «RealtyAgency»");
    }

    private static void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        AppLog.Error("APP", "Необработанное исключение в UI-потоке", e.Exception);
        Trace.WriteLine(e.Exception.ToString());
        MessageBox.Show(
            "Произошла непредвиденная ошибка. Подробности записаны в журнал:\n" +
            $"{AppLog.LogFilePath}\n\n{e.Exception.Message}",
            "Непредвиденная ошибка",
            MessageBoxButton.OK,
            MessageBoxImage.Error);
        e.Handled = true;
    }

    private static void OnDomainUnhandledException(object sender, UnhandledExceptionEventArgs e)
    {
        if (e.ExceptionObject is Exception ex)
        {
            AppLog.Error("APP", "Критическая ошибка", ex);
            Trace.WriteLine(ex.ToString());
        }
    }

    private static void OnUnobservedTaskException(object? sender, UnobservedTaskExceptionEventArgs e)
    {
        AppLog.Error("APP", "Ошибка в фоновой задаче", e.Exception);
        e.SetObserved();
    }
}
