using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.DataAccess;

/// <summary>Параметры поиска объектов недвижимости; незаполненный параметр не ограничивает поиск.</summary>
public sealed class PropertyFilter
{
    /// <summary>Получает или задает часть адреса или описания.</summary>
    public string? Search { get; set; }

    /// <summary>Получает или задает код района.</summary>
    public int? DistrictId { get; set; }

    /// <summary>Получает или задает код типа недвижимости.</summary>
    public int? PropertyTypeId { get; set; }

    /// <summary>Получает или задает вид предложения.</summary>
    public OfferType? OfferType { get; set; }

    /// <summary>Получает или задает статус объекта.</summary>
    public PropertyStatus? Status { get; set; }

    /// <summary>Получает или задает минимальную цену (включительно).</summary>
    public decimal? MinPrice { get; set; }

    /// <summary>Получает или задает максимальную цену (включительно).</summary>
    public decimal? MaxPrice { get; set; }

    /// <summary>Получает или задает минимальное число комнат.</summary>
    public int? MinRooms { get; set; }
}
