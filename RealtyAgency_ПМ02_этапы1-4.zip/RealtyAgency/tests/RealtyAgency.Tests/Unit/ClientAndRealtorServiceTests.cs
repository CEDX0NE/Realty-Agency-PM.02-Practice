using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Services;
using RealtyAgency.DataAccess;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.Tests.Fakes;

namespace RealtyAgency.Tests.Unit;

/// <summary>Клиенты и риэлторы: проверки полей и уникальность телефона (US-01 – US-03).</summary>
[Trait("Category", "Unit")]
public class ClientAndRealtorServiceTests
{
    private readonly TestWorld _w = new();
    private readonly ClientService _clients;
    private readonly RealtorService _realtors;

    public ClientAndRealtorServiceTests()
    {
        _clients = new ClientService(_w.Clients);
        _realtors = new RealtorService(_w.Realtors);
    }

    [Fact]
    [Trait("TC", "ТК-01")]
    public async Task SaveAsync_ValidClient_TrimsAndAdds()
    {
        var c = new Client { FullName = "  Сидорова Ольга Ивановна ", Phone = " +7 (916) 300-00-01 ", Email = "  " };

        await _clients.SaveAsync(c);

        Assert.Equal(3, _w.Clients.Items.Count);
        Assert.Equal("Сидорова Ольга Ивановна", c.FullName);
        Assert.Null(c.Email);
    }

    [Theory]
    [Trait("TC", "ТК-02")]
    [InlineData("Ив", "+7 (916) 300-00-01", null)]
    [InlineData("Сидорова Ольга", "123", null)]
    [InlineData("Сидорова Ольга", "+7 (916) 300-00-01", "olga@")]
    public async Task SaveAsync_InvalidField_ThrowsValidation(string name, string phone, string? email)
    {
        var c = new Client { FullName = name, Phone = phone, Email = email };

        await Assert.ThrowsAsync<ValidationException>(() => _clients.SaveAsync(c));
        Assert.Equal(2, _w.Clients.Items.Count);
    }

    [Fact]
    [Trait("TC", "ТК-03")]
    public async Task SaveAsync_SamePhone_ThrowsValidation()
    {
        var c = new Client { FullName = "Двойник Иван Иванович", Phone = "+7 (916) 200-00-01" };

        var ex = await Assert.ThrowsAsync<ValidationException>(() => _clients.SaveAsync(c));

        Assert.Contains(ex.Errors, e => e.Contains("телефоном уже есть"));
    }

    [Theory]
    [Trait("TC", "ТК-03")]
    [Trait("Defect", "DEF-01")]
    [InlineData("+79162000001")]
    [InlineData("8 (916) 200-00-01")]
    [InlineData("8-916-200-00-01")]
    public async Task SaveAsync_SamePhoneInOtherFormat_ThrowsValidation(string phone)
    {
        var c = new Client { FullName = "Двойник Иван Иванович", Phone = phone };

        await Assert.ThrowsAsync<ValidationException>(() => _clients.SaveAsync(c));
        Assert.Equal(2, _w.Clients.Items.Count);
    }

    [Fact]
    [Trait("Defect", "DEF-01")]
    public async Task SaveAsync_PhoneWithoutCountryCode_StoredInSingleFormat()
    {
        var c = new Client { FullName = "Сидорова Ольга Ивановна", Phone = "89163000001" };

        await _clients.SaveAsync(c);

        Assert.Equal("+7 (916) 300-00-01", c.Phone);
    }

    [Fact]
    [Trait("TC", "ТК-04")]
    public async Task DeleteAsync_ClientInUse_ThrowsDeleteRestricted()
    {
        _w.Clients.FailWith = new DataAccessException("FK", DbErrorKind.ForeignKey);

        await Assert.ThrowsAsync<DeleteRestrictedException>(() => _clients.DeleteAsync(1));
    }

    [Fact]
    public async Task GetAllAsync_RecordDeleted_ThrowsEntityNotFound()
    {
        _w.Clients.FailWith = new DataAccessException("нет", DbErrorKind.NotFound);

        await Assert.ThrowsAsync<EntityNotFoundException>(() => _clients.GetAllAsync());
    }

    [Theory]
    [InlineData(-0.01)]
    [InlineData(50.01)]
    [Trait("TC", "ТК-22")]
    public async Task RealtorSave_CommissionOutOfRange_ThrowsValidation(decimal percent)
    {
        var r = new Realtor { FullName = "Новиков Пётр Ильич", Phone = "+7 (901) 111-22-09", CommissionPercent = percent };

        await Assert.ThrowsAsync<ValidationException>(() => _realtors.SaveAsync(r));
    }

    [Theory]
    [InlineData(0)]
    [InlineData(50)]
    [Trait("TC", "ТК-22")]
    public async Task RealtorSave_CommissionOnBoundary_Saves(decimal percent)
    {
        var r = new Realtor { FullName = "Новиков Пётр Ильич", Phone = "+7 (901) 111-22-09", CommissionPercent = percent };

        await _realtors.SaveAsync(r);

        Assert.Equal(3, _w.Realtors.Items.Count);
    }

    [Fact]
    public async Task RealtorSave_HireDateInFuture_ThrowsValidation()
    {
        var r = new Realtor { FullName = "Новиков Пётр Ильич", Phone = "+7 (901) 111-22-09", HireDate = DateTime.Today.AddDays(1) };

        await Assert.ThrowsAsync<ValidationException>(() => _realtors.SaveAsync(r));
    }

    [Fact]
    public async Task RealtorDelete_RealtorHasDeals_ThrowsDeleteRestricted()
    {
        _w.Realtors.FailWith = new DataAccessException("FK", DbErrorKind.ForeignKey);

        await Assert.ThrowsAsync<DeleteRestrictedException>(() => _realtors.DeleteAsync(1));
    }
}
