using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Services;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Repositories;

namespace RealtyAgency.Tests.Integration;

/// <summary>Взаимодействие модулей BLL ↔ DAL ↔ MySQL через интерфейсы этапа 2.</summary>
public class ServiceIntegrationTests : IntegrationTestBase
{
    public ServiceIntegrationTests(MySqlDatabase db)
        : base(db)
    {
    }

    private DealService Deals()
    {
        var factory = Db.ContextFactory();
        return new DealService(new DealRepository(factory), new PropertyRepository(factory), new RealtorRepository(factory));
    }

    [Fact]
    [Trait("TC", "ТК-10")]
    public async Task DealLifecycle_CreateThenComplete()
    {
        var service = Deals();
        var deal = new Deal { PropertyId = 2, ClientId = 2, RealtorId = 3, Amount = 18_900_000m, DealDate = DateTime.Now };

        await service.CreateAsync(deal);
        Assert.Equal(661_500m, deal.Commission);
        Assert.Equal("reserved", await Db.ScalarAsync<string>("SELECT status FROM properties WHERE id = 2"));

        await service.CompleteAsync(deal.Id);
        Assert.Equal("completed", await Db.ScalarAsync<string>($"SELECT status FROM deals WHERE id = {deal.Id}"));
        Assert.Equal("closed", await Db.ScalarAsync<string>("SELECT status FROM properties WHERE id = 2"));
    }

    [Fact]
    [Trait("TC", "ТК-15")]
    public async Task CancelOpenDeal_ReturnsPropertyToSale()
    {
        await Deals().CancelAsync(3);

        Assert.Equal("cancelled", await Db.ScalarAsync<string>("SELECT status FROM deals WHERE id = 3"));
        Assert.Equal("active", await Db.ScalarAsync<string>("SELECT status FROM properties WHERE id = 5"));
    }

    [Fact]
    [Trait("TC", "ТК-11")]
    public async Task SecondDealOnReservedProperty_Rejected()
    {
        var deal = new Deal { PropertyId = 5, ClientId = 9, RealtorId = 1, Amount = 23_500_000m, DealDate = DateTime.Now };

        await Assert.ThrowsAsync<PropertyNotAvailableException>(() => Deals().CreateAsync(deal));
        Assert.Equal(3, await Db.ScalarAsync<int>("SELECT COUNT(*) FROM deals"));
    }

    [Fact]
    [Trait("Defect", "DEF-04")]
    public async Task HugeDealAmount_ReportedAsValidationNotDatabaseError()
    {
        var deal = new Deal { PropertyId = 2, ClientId = 2, RealtorId = 3, Amount = 1_000_000_000_000m, DealDate = DateTime.Now };

        await Assert.ThrowsAsync<ValidationException>(() => Deals().CreateAsync(deal));
    }

    [Fact]
    [Trait("TC", "ТК-04")]
    public async Task DeleteOwnerClient_Restricted()
    {
        var service = new ClientService(new ClientRepository(Db.ContextFactory()));

        await Assert.ThrowsAsync<DeleteRestrictedException>(() => service.DeleteAsync(3));
    }

    [Fact]
    public async Task DeletePropertyWithDeals_Restricted()
    {
        var service = new PropertyService(new PropertyRepository(Db.ContextFactory()));

        await Assert.ThrowsAsync<DeleteRestrictedException>(() => service.DeleteAsync(1));
    }

    [Fact]
    [Trait("TC", "ТК-03")]
    [Trait("Defect", "DEF-01")]
    public async Task ClientWithSamePhoneInOtherFormat_Rejected()
    {
        var service = new ClientService(new ClientRepository(Db.ContextFactory()));

        await Assert.ThrowsAsync<ValidationException>(() =>
            service.SaveAsync(new Client { FullName = "Двойник Сергей Петрович", Phone = "89162000001" }));
        Assert.Equal(12, await Db.ScalarAsync<int>("SELECT COUNT(*) FROM clients"));
    }

    [Fact]
    [Trait("TC", "ТК-17")]
    [Trait("Defect", "DEF-02")]
    public async Task ViewingFiftyNineMinutesAfterAnother_Rejected()
    {
        var factory = Db.ContextFactory();
        var service = new ViewingService(new ViewingRepository(factory), new PropertyRepository(factory), new RealtorRepository(factory));
        var planned = await Db.ScalarAsync<DateTime>("SELECT scheduled_at FROM viewings WHERE id = 6");

        var v = new Viewing { PropertyId = 11, ClientId = 2, RealtorId = 3, ScheduledAt = planned.AddMinutes(59) };

        await Assert.ThrowsAsync<RealtorBusyException>(() => service.SaveAsync(v));
    }

    [Fact]
    [Trait("TC", "ТК-17")]
    public async Task ViewingOneHourAfterAnother_Allowed()
    {
        var factory = Db.ContextFactory();
        var service = new ViewingService(new ViewingRepository(factory), new PropertyRepository(factory), new RealtorRepository(factory));
        var planned = await Db.ScalarAsync<DateTime>("SELECT scheduled_at FROM viewings WHERE id = 6");

        await service.SaveAsync(new Viewing { PropertyId = 11, ClientId = 2, RealtorId = 3, ScheduledAt = planned.AddHours(1) });

        Assert.Equal(11, await Db.ScalarAsync<int>("SELECT COUNT(*) FROM viewings"));
    }
}
