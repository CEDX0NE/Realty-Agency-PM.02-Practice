using System.Diagnostics;

namespace RealtyAgency.BusinessLogic.Logging;

/// <summary>
/// Журнал приложения на базе System.Diagnostics.Trace (Шаг 6 этапа 2).
/// Все Trace.WriteLine / Debug.WriteLine из любых слоёв попадают:
///   • в окно Output Visual Studio (стандартный DefaultTraceListener);
///   • в файл logs/realty_ГГГГ-ММ-ДД.log рядом с .exe (наш listener).
/// </summary>
public static class AppLog
{
    /// <summary>Получает путь к файлу журнала текущего дня (после <see cref="Init"/>).</summary>
    public static string? LogFilePath { get; private set; }

    /// <summary>Подключает файловый журнал logs/realty_ГГГГ-ММ-ДД.log.</summary>
    /// <param name="folder">Папка для журналов.</param>
    public static void Init(string folder)
    {
        Directory.CreateDirectory(folder);
        LogFilePath = Path.Combine(folder, $"realty_{DateTime.Now:yyyy-MM-dd}.log");

        Trace.Listeners.Add(new TimestampFileListener(LogFilePath));
        Trace.AutoFlush = true;

        Trace.WriteLine(new string('=', 70));
        Info("APP", $"Запуск приложения. Журнал: {LogFilePath}");
    }

    /// <summary>Информационная запись.</summary>
    /// <param name="layer">Слой: UI, BLL, DAL, APP.</param>
    /// <param name="message">Текст.</param>
    public static void Info(string layer, string message) =>
        Trace.WriteLine($"[{layer}] {message}");

    /// <summary>Предупреждение (бизнес-ошибка, показанная пользователю).</summary>
    /// <param name="layer">Слой: UI, BLL, DAL, APP.</param>
    /// <param name="message">Текст.</param>
    public static void Warn(string layer, string message) =>
        Trace.WriteLine($"[{layer}][WARN] {message}");

    /// <summary>Ошибка.</summary>
    /// <param name="layer">Слой: UI, BLL, DAL, APP.</param>
    /// <param name="message">Текст.</param>
    /// <param name="ex">Исключение (необязательно).</param>
    public static void Error(string layer, string message, Exception? ex = null) =>
        Trace.WriteLine($"[{layer}][ERROR] {message}" +
                        (ex is null ? string.Empty : $" | {ex.GetType().Name}: {ex.Message}"));

    /// <summary>Файловый listener, добавляющий время к каждой строке.</summary>
    private sealed class TimestampFileListener : TextWriterTraceListener
    {
        public TimestampFileListener(string path)
            : base(path)
        {
        }

        public override void WriteLine(string? message) =>
            base.WriteLine($"{DateTime.Now:HH:mm:ss.fff}  {message}");
    }
}
