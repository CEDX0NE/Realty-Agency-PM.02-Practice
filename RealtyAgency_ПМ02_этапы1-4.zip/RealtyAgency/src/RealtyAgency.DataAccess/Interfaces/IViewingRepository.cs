using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.DataAccess.Interfaces;

/// <summary>Показы.</summary>
public interface IViewingRepository
{
    /// <summary>Возвращает показы, новые — первыми.</summary>
    /// <param name="status">Статус для отбора или <see langword="null"/> — все.</param>
    /// <returns>Список показов.</returns>
    Task<List<Viewing>> GetAllAsync(ViewingStatus? status);

    /// <summary>Находит показ по коду.</summary>
    /// <param name="id">Код показа.</param>
    /// <returns>Показ или <see langword="null"/>.</returns>
    Task<Viewing?> GetByIdAsync(int id);

    /// <summary>Есть ли у риэлтора запланированный показ строго внутри окна «время ± window».</summary>
    /// <param name="realtorId">Код риэлтора.</param>
    /// <param name="time">Время нового показа.</param>
    /// <param name="window">Половина ширины окна.</param>
    /// <param name="excludeId">Код показа, который не учитывать (при редактировании).</param>
    /// <returns><see langword="true"/>, если риэлтор занят.</returns>
    Task<bool> HasRealtorConflictAsync(int realtorId, DateTime time, TimeSpan window, int excludeId);

    /// <summary>Добавляет показ.</summary>
    /// <param name="viewing">Показ.</param>
    /// <returns>Задача.</returns>
    Task AddAsync(Viewing viewing);

    /// <summary>Сохраняет изменения показа.</summary>
    /// <param name="viewing">Показ.</param>
    /// <returns>Задача.</returns>
    Task UpdateAsync(Viewing viewing);

    /// <summary>Удаляет показ.</summary>
    /// <param name="id">Код показа.</param>
    /// <returns>Задача.</returns>
    Task DeleteAsync(int id);
}
