using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Interfaces;

namespace RealtyAgency.BusinessLogic.Services;

/// <summary>Справочники. Кэшируются в памяти — они почти не меняются.</summary>
public class ReferenceService : ServiceBase, IReferenceService
{
    private readonly IReferenceRepository _repo;
    private List<District>? _districts;
    private List<PropertyType>? _types;

    /// <summary>Инициализирует новый экземпляр класса <see cref="ReferenceService"/>.</summary>
    /// <param name="repo">Репозиторий справочников.</param>
    public ReferenceService(IReferenceRepository repo) => _repo = repo;

    /// <inheritdoc/>
    public Task<List<District>> GetDistrictsAsync() =>
        GuardAsync("Загрузка районов", async () => _districts ??= await _repo.GetDistrictsAsync());

    /// <inheritdoc/>
    public Task<List<PropertyType>> GetPropertyTypesAsync() =>
        GuardAsync("Загрузка типов", async () => _types ??= await _repo.GetPropertyTypesAsync());
}
