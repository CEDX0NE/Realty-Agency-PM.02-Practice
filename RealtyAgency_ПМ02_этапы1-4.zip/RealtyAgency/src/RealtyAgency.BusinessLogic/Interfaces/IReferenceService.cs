using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.BusinessLogic.Interfaces;

/// <summary>Справочники: районы и типы недвижимости (кэшируются).</summary>
public interface IReferenceService
{
    /// <summary>Возвращает районы, отсортированные по названию.</summary>
    /// <returns>Список районов.</returns>
    Task<List<District>> GetDistrictsAsync();

    /// <summary>Возвращает типы недвижимости.</summary>
    /// <returns>Список типов.</returns>
    Task<List<PropertyType>> GetPropertyTypesAsync();
}
