namespace RealtyAgency.BusinessLogic.Exceptions;

/// <summary>Запись нельзя удалить: на неё ссылаются другие данные.</summary>
public class DeleteRestrictedException : RealtyException
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="DeleteRestrictedException"/>.</summary>
    /// <param name="message">Текст для пользователя.</param>
    /// <param name="inner">Исходное исключение.</param>
    public DeleteRestrictedException(string message, Exception? inner = null)
        : base(message, inner)
    {
    }
}
