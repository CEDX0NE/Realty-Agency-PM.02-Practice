using System.Globalization;

namespace RealtyAgency.Wpf.Infrastructure;

/// <summary>
/// Разбор чисел, введённых пользователем: «12 500 000», «12 500 000,50», «64.5».
/// Один метод для форм редактирования и фильтров (раньше логика дублировалась).
/// </summary>
public static class NumberText
{
    /// <summary>Убирает пробелы (в том числе неразрывные), запятую заменяет точкой.</summary>
    /// <param name="text">Введённый текст.</param>
    /// <returns>Строка для разбора в инвариантной культуре.</returns>
    public static string Normalize(string? text) =>
        (text ?? string.Empty).Replace(" ", string.Empty).Replace(" ", string.Empty).Replace(",", ".").Trim();

    /// <summary>Пытается разобрать десятичное число.</summary>
    /// <param name="text">Введённый текст.</param>
    /// <param name="value">Результат.</param>
    /// <returns><see langword="true"/>, если разбор удался.</returns>
    public static bool TryParseDecimal(string? text, out decimal value) =>
        decimal.TryParse(Normalize(text), NumberStyles.Number, CultureInfo.InvariantCulture, out value);

    /// <summary>Пытается разобрать целое число.</summary>
    /// <param name="text">Введённый текст.</param>
    /// <param name="value">Результат.</param>
    /// <returns><see langword="true"/>, если разбор удался.</returns>
    public static bool TryParseInt(string? text, out int value) =>
        int.TryParse(Normalize(text), NumberStyles.Integer, CultureInfo.InvariantCulture, out value);
}
