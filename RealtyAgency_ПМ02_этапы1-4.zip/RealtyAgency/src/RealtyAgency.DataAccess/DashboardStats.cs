namespace RealtyAgency.DataAccess;

/// <summary>Сводные показатели для главной страницы.</summary>
/// <param name="ActiveProperties">Объектов в продаже и аренде.</param>
/// <param name="OpenDeals">Открытых сделок.</param>
/// <param name="DealsThisMonth">Сделок, завершённых в текущем месяце.</param>
/// <param name="CommissionThisMonth">Комиссия агентства за текущий месяц, ₽.</param>
/// <param name="UpcomingViewings">Предстоящих показов.</param>
/// <param name="ClientsCount">Клиентов в базе.</param>
public sealed record DashboardStats(
    int ActiveProperties,
    int OpenDeals,
    int DealsThisMonth,
    decimal CommissionThisMonth,
    int UpcomingViewings,
    int ClientsCount);
