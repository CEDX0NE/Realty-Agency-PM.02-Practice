namespace RealtyAgency.BusinessLogic.Exceptions;

/// <summary>Базовое исключение приложения «Риэлторское агентство».</summary>
public class RealtyException : Exception
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="RealtyException"/>.</summary>
    /// <param name="message">Текст для пользователя.</param>
    /// <param name="inner">Исходное исключение.</param>
    public RealtyException(string message, Exception? inner = null)
        : base(message, inner)
    {
    }
}
