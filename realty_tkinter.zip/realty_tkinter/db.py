"""Работа с базой данных realty_agency (MySQL) — все запросы приложения в одном месте.

Значения от пользователя передаются только параметрами (%s), поэтому SQL-инъекция невозможна.
"""
import configparser
import os
import re
from decimal import Decimal

import pymysql

# Коды ошибок MySQL, которые переводятся в понятные сообщения
ERR_ACCESS_DENIED = 1045
ERR_UNKNOWN_DB = 1049
ERR_CANT_CONNECT = 2003
ERR_DUPLICATE = 1062
ERR_ROW_REFERENCED = 1451
ERR_SIGNAL = 1644          # SIGNAL SQLSTATE '45000' из триггеров

MAX_MONEY = Decimal("999999999999.99")   # DECIMAL(14,2)

STATUS_RU = {"active": "Активен", "reserved": "Зарезервирован", "closed": "Закрыт", "archived": "Снят",
             "open": "Открыта", "completed": "Завершена", "cancelled": "Отменена",
             "sale": "Продажа", "rent": "Аренда"}


class DbError(Exception):
    """Ошибка, текст которой можно показать пользователю."""


def explain(error):
    """Переводит исключение PyMySQL в понятный текст."""
    code = error.args[0] if error.args else 0
    if code in (ERR_ACCESS_DENIED, ERR_UNKNOWN_DB, ERR_CANT_CONNECT):
        return "Не удалось подключиться к MySQL. Проверьте, что сервер запущен и настройки в config.ini верны."
    if code == ERR_DUPLICATE:
        return "Такая запись уже есть (например, этот телефон уже занят)."
    if code == ERR_ROW_REFERENCED:
        return "Запись используется в других таблицах, удалить её нельзя."
    if code == ERR_SIGNAL:
        return str(error.args[1])
    return f"Ошибка MySQL ({code}): {error.args[1] if len(error.args) > 1 else error}"


class Database:
    """Открывает новое подключение на каждую операцию — данные всегда свежие."""

    def __init__(self, ini_path="config.ini"):
        config = configparser.ConfigParser()
        if not config.read(os.path.join(os.path.dirname(os.path.abspath(__file__)), ini_path), encoding="utf-8"):
            raise DbError("Не найден файл config.ini")
        s = config["mysql"]
        self.params = dict(host=s.get("host"), port=s.getint("port"), user=s.get("user"),
                           password=s.get("password"), database=s.get("database"), charset="utf8mb4",
                           cursorclass=pymysql.cursors.DictCursor, autocommit=False)

    def _connect(self):
        try:
            return pymysql.connect(**self.params)
        except pymysql.MySQLError as e:
            raise DbError(explain(e)) from e

    def query(self, sql, args=()):
        con = self._connect()
        try:
            with con.cursor() as cur:
                cur.execute(sql, args)
                return cur.fetchall()
        except pymysql.MySQLError as e:
            raise DbError(explain(e)) from e
        finally:
            con.close()

    def execute(self, statements):
        """Выполняет одну или несколько команд в одной транзакции; возвращает id последней вставки."""
        con = self._connect()
        try:
            last_id = None
            with con.cursor() as cur:
                for sql, args in statements:
                    cur.execute(sql, args)
                    if cur.lastrowid:          # id запоминаем после INSERT, UPDATE его не возвращает
                        last_id = cur.lastrowid
            con.commit()
            return last_id
        except pymysql.MySQLError as e:
            con.rollback()
            raise DbError(explain(e)) from e
        finally:
            con.close()

    # ---------------- справочники ----------------
    def districts(self):
        return self.query("SELECT id, name FROM districts ORDER BY name")

    def property_types(self):
        return self.query("SELECT id, name FROM property_types ORDER BY name")

    def realtors(self, only_active=True):
        sql = "SELECT id, full_name, commission_percent FROM realtors"
        if only_active:
            sql += " WHERE is_active = 1"
        return self.query(sql + " ORDER BY full_name")

    # ---------------- клиенты ----------------
    def clients(self, search=""):
        sql = "SELECT id, full_name, phone, email, notes FROM clients"
        args = ()
        if search.strip():
            sql += " WHERE full_name LIKE %s OR phone LIKE %s OR email LIKE %s"
            like = f"%{search.strip()}%"
            args = (like, like, like)
        return self.query(sql + " ORDER BY full_name", args)

    def save_client(self, client_id, full_name, phone, email, notes):
        full_name = full_name.strip()
        phone = normalize_phone(phone)
        email = email.strip() or None
        notes = notes.strip() or None
        errors = []
        if len(full_name) < 5:
            errors.append("ФИО — не короче 5 символов")
        if sum(ch.isdigit() for ch in phone) < 10:
            errors.append("Телефон — минимум 10 цифр")
        if email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            errors.append("E-mail указан неверно")
        if notes and len(notes) > 500:
            errors.append("Заметка — не длиннее 500 символов")
        if self.query("SELECT 1 FROM clients WHERE phone = %s AND id <> %s", (phone, client_id or 0)):
            errors.append("Клиент с таким телефоном уже есть")
        if errors:
            raise DbError("Проверьте данные:\n• " + "\n• ".join(errors))
        if client_id:
            self.execute([("UPDATE clients SET full_name=%s, phone=%s, email=%s, notes=%s WHERE id=%s",
                           (full_name, phone, email, notes, client_id))])
        else:
            self.execute([("INSERT INTO clients(full_name, phone, email, notes) VALUES (%s, %s, %s, %s)",
                           (full_name, phone, email, notes))])

    def delete_client(self, client_id):
        self.execute([("DELETE FROM clients WHERE id = %s", (client_id,))])

    # ---------------- объекты ----------------
    def properties(self, search="", district_id=None, offer=None, status=None, min_price=None, max_price=None):
        sql = ("SELECT p.id, p.address, d.name AS district, t.name AS type, p.offer_type, p.price, p.area, p.rooms, "
               "p.status, c.full_name AS owner, r.full_name AS realtor "
               "FROM properties p JOIN districts d ON d.id = p.district_id "
               "JOIN property_types t ON t.id = p.property_type_id "
               "JOIN clients c ON c.id = p.owner_id JOIN realtors r ON r.id = p.realtor_id WHERE 1 = 1")
        args = []
        if search.strip():
            sql += " AND p.address LIKE %s"
            args.append(f"%{search.strip()}%")
        if district_id:
            sql += " AND p.district_id = %s"
            args.append(district_id)
        if offer:
            sql += " AND p.offer_type = %s"
            args.append(offer)
        if status:
            sql += " AND p.status = %s"
            args.append(status)
        if min_price is not None:
            sql += " AND p.price >= %s"
            args.append(min_price)
        if max_price is not None:
            sql += " AND p.price <= %s"
            args.append(max_price)
        return self.query(sql + " ORDER BY p.created_at DESC", tuple(args))

    def property_by_id(self, property_id):
        rows = self.query("SELECT * FROM properties WHERE id = %s", (property_id,))
        return rows[0] if rows else None

    def save_property(self, property_id, data):
        errors = []
        if len(data["address"].strip()) < 5:
            errors.append("Адрес — не короче 5 символов")
        for key, title in (("district_id", "район"), ("property_type_id", "тип"), ("owner_id", "собственника"),
                           ("realtor_id", "риэлтора")):
            if not data[key]:
                errors.append(f"Выберите {title}")
        if not (0 < data["price"] <= MAX_MONEY):
            errors.append("Цена — больше нуля и не больше 999 999 999 999,99")
        if not (0 < data["area"] < 100000):
            errors.append("Площадь — больше нуля")
        if not (0 <= data["rooms"] <= 50):
            errors.append("Комнат — от 0 до 50")
        if errors:
            raise DbError("Проверьте данные:\n• " + "\n• ".join(errors))
        cols = ("address", "district_id", "property_type_id", "owner_id", "realtor_id", "offer_type", "price", "area",
                "rooms", "description")
        values = tuple(data[c] for c in cols)
        if property_id:
            sets = ", ".join(f"{c} = %s" for c in cols)
            self.execute([(f"UPDATE properties SET {sets} WHERE id = %s", values + (property_id,))])
        else:
            self.execute([(f"INSERT INTO properties({', '.join(cols)}) VALUES ({', '.join(['%s'] * len(cols))})",
                           values)])

    def toggle_archive(self, property_id):
        p = self.property_by_id(property_id)
        if p["status"] not in ("active", "archived"):
            raise DbError("Объект зарезервирован или закрыт — его статус меняется только через сделки.")
        new_status = "archived" if p["status"] == "active" else "active"
        self.execute([("UPDATE properties SET status = %s WHERE id = %s", (new_status, property_id))])

    def delete_property(self, property_id):
        self.execute([("DELETE FROM properties WHERE id = %s", (property_id,))])

    # ---------------- сделки ----------------
    def deals(self, status=None):
        sql = ("SELECT dl.id, dl.deal_date, p.address, cl.full_name AS client, r.full_name AS realtor, dl.amount, "
               "dl.commission, dl.status FROM deals dl JOIN properties p ON p.id = dl.property_id "
               "JOIN clients cl ON cl.id = dl.client_id JOIN realtors r ON r.id = dl.realtor_id")
        args = ()
        if status:
            sql += " WHERE dl.status = %s"
            args = (status,)
        return self.query(sql + " ORDER BY dl.deal_date DESC", args)

    def create_deal(self, property_id, client_id, realtor_id, amount):
        """Сделка и смена статуса объекта — в одной транзакции. Возвращает (id сделки, комиссия)."""
        p = self.property_by_id(property_id)
        if p is None or p["status"] != "active":
            raise DbError("Сделку можно оформить только по активному объекту.")
        if p["owner_id"] == client_id:
            raise DbError("Покупатель/арендатор не может быть собственником объекта.")
        if not (0 < amount <= MAX_MONEY):
            raise DbError("Сумма сделки — больше нуля и не больше 999 999 999 999,99")
        realtor = self.query("SELECT commission_percent FROM realtors WHERE id = %s AND is_active = 1", (realtor_id,))
        if not realtor:
            raise DbError("Выберите работающего риэлтора.")
        commission = (amount * realtor[0]["commission_percent"] / 100).quantize(Decimal("0.01"))
        deal_id = self.execute([
            ("INSERT INTO deals(property_id, client_id, realtor_id, amount, commission, status) "
             "VALUES (%s, %s, %s, %s, %s, 'open')", (property_id, client_id, realtor_id, amount, commission)),
            ("UPDATE properties SET status = 'reserved' WHERE id = %s", (property_id,)),
        ])
        return deal_id, commission

    def change_deal(self, deal_id, new_status):
        """Завершить (completed → объект closed) или отменить (cancelled → объект active)."""
        rows = self.query("SELECT property_id, status FROM deals WHERE id = %s", (deal_id,))
        if not rows or rows[0]["status"] != "open":
            raise DbError("Изменить можно только открытую сделку.")
        property_status = "closed" if new_status == "completed" else "active"
        self.execute([("UPDATE deals SET status = %s WHERE id = %s", (new_status, deal_id)),
                      ("UPDATE properties SET status = %s WHERE id = %s", (property_status, rows[0]["property_id"]))])

    # ---------------- отчёт ----------------
    def deals_report(self, date_from, date_to):
        if date_from > date_to:
            raise DbError("Дата «с» позже даты «по».")
        return self.query(
            "SELECT DATE_FORMAT(dl.deal_date, '%%d.%%m.%%Y') AS day, p.address, p.offer_type, cl.full_name AS client, "
            "r.full_name AS realtor, dl.amount, dl.commission, dl.status FROM deals dl "
            "JOIN properties p ON p.id = dl.property_id JOIN clients cl ON cl.id = dl.client_id "
            "JOIN realtors r ON r.id = dl.realtor_id "
            "WHERE dl.deal_date >= %s AND dl.deal_date < %s + INTERVAL 1 DAY ORDER BY dl.deal_date",
            (date_from, date_to))


def normalize_phone(phone):
    """«89161112233», «+7 916 111-22-33» → «+7 (916) 111-22-33» (как в приложении на C#)."""
    digits = "".join(ch for ch in phone if ch.isdigit())
    if len(digits) == 11 and digits[0] in "78":
        digits = digits[1:]
    if len(digits) != 10:
        return phone.strip()
    return f"+7 ({digits[:3]}) {digits[3:6]}-{digits[6:8]}-{digits[8:]}"


def parse_money(text, field):
    """«12 500 000,50» → Decimal; пустая строка → None."""
    s = text.replace(" ", "").replace(" ", "").replace(",", ".").strip()
    if not s:
        return None
    try:
        return Decimal(s)
    except ArithmeticError as e:
        raise DbError(f"Поле «{field}»: введите число") from e
