using RealtyAgency.BusinessLogic.Services;
using RealtyAgency.Tests.Fakes;

namespace RealtyAgency.Tests.Unit;

/// <summary>Справочники кэшируются: повторный запрос не обращается к БД.</summary>
[Trait("Category", "Unit")]
public class ReferenceServiceTests
{
    [Fact]
    public async Task GetDistrictsAndTypes_SecondCall_ReturnsCachedList()
    {
        var repo = new FakeReferenceRepository();
        var service = new ReferenceService(repo);

        var first = await service.GetDistrictsAsync();
        var second = await service.GetDistrictsAsync();
        await service.GetPropertyTypesAsync();
        await service.GetPropertyTypesAsync();

        Assert.Same(first, second);
        Assert.Equal(2, repo.Calls);
    }
}
