namespace RealtyAgency.DataAccess.Entities;

/// <summary>Клиент агентства: собственник, покупатель или арендатор (таблица clients).</summary>
public class Client
{
    /// <summary>Получает или задает код клиента.</summary>
    public int Id { get; set; }

    /// <summary>Получает или задает фамилию, имя и отчество.</summary>
    public string FullName { get; set; } = string.Empty;

    /// <summary>Получает или задает телефон в формате +7 (XXX) XXX-XX-XX (уникальный).</summary>
    public string Phone { get; set; } = string.Empty;

    /// <summary>Получает или задает e-mail (необязательно).</summary>
    public string? Email { get; set; }

    /// <summary>Получает или задает заметку агента о клиенте (до 500 символов).</summary>
    public string? Notes { get; set; }

    /// <summary>Получает или задает дату регистрации клиента.</summary>
    public DateTime RegisteredAt { get; set; } = DateTime.Now;

    /// <summary>Получает или задает объекты, которыми владеет клиент.</summary>
    public ICollection<Property> OwnedProperties { get; set; } = new List<Property>();

    /// <summary>Получает или задает показы, на которые приходил клиент.</summary>
    public ICollection<Viewing> Viewings { get; set; } = new List<Viewing>();

    /// <summary>Получает или задает сделки, где клиент — покупатель или арендатор.</summary>
    public ICollection<Deal> Deals { get; set; } = new List<Deal>();

    /// <inheritdoc/>
    public override string ToString() => FullName;
}
