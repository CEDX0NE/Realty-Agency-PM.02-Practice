-- =====================================================================
--  Роли и пользователи MySQL (принцип минимальных привилегий)
--  Запускать от root после 01_schema.sql
-- =====================================================================
USE realty_agency;

CREATE ROLE IF NOT EXISTS 'ra_admin', 'ra_app', 'ra_report';

-- Администратор БД: всё
GRANT ALL PRIVILEGES ON realty_agency.* TO 'ra_admin';

-- Приложение: только чтение/изменение данных, без DDL
GRANT SELECT, INSERT, UPDATE, DELETE ON realty_agency.districts      TO 'ra_app';
GRANT SELECT, INSERT, UPDATE, DELETE ON realty_agency.property_types TO 'ra_app';
GRANT SELECT, INSERT, UPDATE, DELETE ON realty_agency.realtors       TO 'ra_app';
GRANT SELECT, INSERT, UPDATE, DELETE ON realty_agency.clients        TO 'ra_app';
GRANT SELECT, INSERT, UPDATE, DELETE ON realty_agency.properties     TO 'ra_app';
GRANT SELECT, INSERT, UPDATE, DELETE ON realty_agency.viewings       TO 'ra_app';
GRANT SELECT, INSERT, UPDATE, DELETE ON realty_agency.deals          TO 'ra_app';
GRANT SELECT ON realty_agency.v_properties_full     TO 'ra_app';
GRANT SELECT ON realty_agency.v_deals_report        TO 'ra_app';
GRANT SELECT ON realty_agency.v_realtor_performance TO 'ra_app';

-- Отчёты: только чтение представлений
GRANT SELECT ON realty_agency.v_properties_full     TO 'ra_report';
GRANT SELECT ON realty_agency.v_deals_report        TO 'ra_report';
GRANT SELECT ON realty_agency.v_realtor_performance TO 'ra_report';

-- Пользователи (пароли поменяйте на свои и не забудьте про appsettings.json)
CREATE USER IF NOT EXISTS 'realty_admin'@'localhost'  IDENTIFIED BY 'Kluch_Admin_2026!';
CREATE USER IF NOT EXISTS 'realty_app'@'localhost'    IDENTIFIED BY 'Kluch_App_2026!';
CREATE USER IF NOT EXISTS 'realty_report'@'localhost' IDENTIFIED BY 'Kluch_Report_2026!';

GRANT 'ra_admin'  TO 'realty_admin'@'localhost';
GRANT 'ra_app'    TO 'realty_app'@'localhost';
GRANT 'ra_report' TO 'realty_report'@'localhost';

SET DEFAULT ROLE ALL TO
    'realty_admin'@'localhost',
    'realty_app'@'localhost',
    'realty_report'@'localhost';

FLUSH PRIVILEGES;
