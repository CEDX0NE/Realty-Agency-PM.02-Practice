using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.BusinessLogic.Logging;
using RealtyAgency.DataAccess;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Interfaces;

namespace RealtyAgency.BusinessLogic.Services;

/// <summary>Объекты недвижимости: проверки и правила смены статуса.</summary>
public class PropertyService : ServiceBase, IPropertyService
{
    private readonly IPropertyRepository _repo;

    /// <summary>Инициализирует новый экземпляр класса <see cref="PropertyService"/>.</summary>
    /// <param name="repo">Репозиторий объектов.</param>
    public PropertyService(IPropertyRepository repo) => _repo = repo;

    /// <inheritdoc/>
    public Task<List<Property>> SearchAsync(PropertyFilter filter) =>
        GuardAsync("Поиск объектов", () =>
        {
            if (filter.MinPrice is decimal min && filter.MaxPrice is decimal max && min > max)
            {
                throw new ValidationException("Цена «от» больше цены «до»");
            }

            return _repo.SearchAsync(filter);
        });

    /// <inheritdoc/>
    public Task<List<Property>> GetAvailableAsync() =>
        GuardAsync("Доступные объекты", () => _repo.GetAvailableAsync());

    /// <inheritdoc/>
    public Task SaveAsync(Property property) =>
        GuardAsync($"Сохранение объекта «{property.Address}»", async () =>
        {
            Validate(property);

            if (property.Id == 0)
            {
                property.Status = PropertyStatus.Active;
                property.CreatedAt = DateTime.Now;
                await _repo.AddAsync(property);
                AppLog.Info("BLL", $"Добавлен объект ID={property.Id}: {property.Address}, {property.Price:N0} ₽");
                return;
            }

            // Статус и дату создания форма не меняет — берём их из БД
            var existing = await _repo.GetByIdAsync(property.Id)
                           ?? throw new EntityNotFoundException($"Объект ID={property.Id} не найден");
            property.Status = existing.Status;
            property.CreatedAt = existing.CreatedAt;
            await _repo.UpdateAsync(property);
            AppLog.Info("BLL", $"Изменён объект ID={property.Id}");
        });

    /// <inheritdoc/>
    public Task DeleteAsync(int id) =>
        GuardAsync($"Удаление объекта ID={id}", () => DeleteOrExplainAsync(
            () => _repo.DeleteAsync(id),
            "По объекту есть сделки — удалить его нельзя. Используйте «Снять с продажи»."));

    /// <inheritdoc/>
    public Task ToggleArchiveAsync(int id) =>
        GuardAsync($"Снять/вернуть объект ID={id}", async () =>
        {
            var property = await _repo.GetByIdAsync(id)
                           ?? throw new EntityNotFoundException($"Объект ID={id} не найден");

            property.Status = property.Status switch
            {
                PropertyStatus.Active => PropertyStatus.Archived,
                PropertyStatus.Archived => PropertyStatus.Active,
                PropertyStatus.Reserved => throw new PropertyNotAvailableException(
                    id,
                    "По объекту идёт сделка. Сначала завершите или отмените её."),
                _ => throw new PropertyNotAvailableException(
                    id,
                    "Объект уже продан/сдан — его статус меняется только через сделки."),
            };

            // Навигационные свойства не нужны для обновления
            property.District = null;
            property.PropertyType = null;
            property.Owner = null;
            property.Realtor = null;
            await _repo.UpdateAsync(property);
            AppLog.Info("BLL", $"Объект ID={id}: статус -> {property.Status}");
        });

    private static void Validate(Property property)
    {
        property.Address = property.Address.Trim();
        property.Description = Validator.Clean(property.Description);

        new Validator()
            .Require(property.Address.Length >= Limits.MinAddressLength, $"Адрес — не короче {Limits.MinAddressLength} символов")
            .Require(property.DistrictId > 0, "Выберите район")
            .Require(property.PropertyTypeId > 0, "Выберите тип недвижимости")
            .Require(property.OwnerId > 0, "Выберите собственника")
            .Require(property.RealtorId > 0, "Выберите ответственного риэлтора")
            .Require(property.Price > 0, "Цена должна быть больше нуля")
            .Require(property.Price <= Limits.MaxMoney, "Цена — не больше 999 999 999 999,99 ₽")
            .Require(property.Area > 0 && property.Area < Limits.MaxArea, "Площадь должна быть больше нуля")
            .Require(property.Rooms >= 0 && property.Rooms <= Limits.MaxRooms, $"Комнат — от 0 до {Limits.MaxRooms}")
            .Require(
                property.TotalFloors is null || (property.TotalFloors >= 1 && property.TotalFloors <= Limits.MaxFloors),
                $"Этажность — от 1 до {Limits.MaxFloors}")
            .Require(
                property.Floor is null || property.TotalFloors is null || property.Floor <= property.TotalFloors,
                "Этаж не может быть больше этажности дома")
            .Require(
                (property.Description?.Length ?? 0) <= Limits.MaxDescriptionLength,
                $"Описание — не длиннее {Limits.MaxDescriptionLength} символов")
            .ThrowIfInvalid();
    }
}
