namespace RealtyAgency.BusinessLogic.Services;

/// <summary>
/// Ограничения бизнес-правил агентства. Собраны в одном месте вместо «магических чисел»
/// в коде сервисов; значения согласованы со схемой БД (sql/01_schema.sql).
/// </summary>
public static class Limits
{
    /// <summary>Минимальная длина ФИО клиента или риэлтора.</summary>
    public const int MinNameLength = 5;

    /// <summary>Минимальная длина адреса объекта.</summary>
    public const int MinAddressLength = 5;

    /// <summary>Максимальная площадь объекта, м² (столбец area — DECIMAL(8,2)).</summary>
    public const decimal MaxArea = 100_000m;

    /// <summary>Максимальное число комнат.</summary>
    public const int MaxRooms = 50;

    /// <summary>Максимальная этажность дома.</summary>
    public const int MaxFloors = 200;

    /// <summary>Максимальная длина описания объекта.</summary>
    public const int MaxDescriptionLength = 2000;

    /// <summary>Максимальная длина заметки о клиенте и отзыва о показе (VARCHAR(500)).</summary>
    public const int MaxNoteLength = 500;

    /// <summary>Максимальный процент комиссии риэлтора (CHECK в таблице realtors).</summary>
    public const decimal MaxCommissionPercent = 50m;

    /// <summary>Максимальная сумма в рублях: столбцы price и amount — DECIMAL(14,2).</summary>
    public const decimal MaxMoney = 999_999_999_999.99m;

    /// <summary>Доля отклонения суммы сделки от цены объекта, после которой в журнал пишется предупреждение.</summary>
    public const decimal PriceDeviationWarning = 0.3m;
}
