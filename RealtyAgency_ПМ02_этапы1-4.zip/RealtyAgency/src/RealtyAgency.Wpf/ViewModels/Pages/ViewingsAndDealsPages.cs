using System.Collections.ObjectModel;
using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.Wpf.Infrastructure;

namespace RealtyAgency.Wpf.ViewModels.Pages;

/// <summary>Расписание показов.</summary>
public sealed class ViewingsViewModel : PageViewModel
{
    private readonly IViewingService _service;
    private readonly EditorFactory _editors;

    public ViewingsViewModel(IDialogService dialogs, IViewingService service, EditorFactory editors)
        : base(dialogs)
    {
        _service = service;
        _editors = editors;
        _status = StatusChoices[1]; // по умолчанию — запланированные

        AddCommand = new AsyncRelayCommand(AddAsync);
        EditCommand = new AsyncRelayCommand(EditAsync, () => Selected is not null);
        DeleteCommand = new AsyncRelayCommand(DeleteAsync, () => Selected is not null);
        DoneCommand = new AsyncRelayCommand(
            () => SetStatusAsync(ViewingStatus.Done),
            () => Selected?.Status == ViewingStatus.Planned);
        CancelCommand = new AsyncRelayCommand(
            () => SetStatusAsync(ViewingStatus.Cancelled),
            () => Selected?.Status == ViewingStatus.Planned);
    }

    public override string Title => "Показы";

    public override string Subtitle => "Расписание просмотров объектов с клиентами";

    public ObservableCollection<Viewing> Items { get; } = new();

    private Viewing? _selected;

    public Viewing? Selected { get => _selected; set => Set(ref _selected, value); }

    public List<Choice<ViewingStatus>> StatusChoices { get; } = new()
    {
        new("Все показы", null),
        new("Запланированные", ViewingStatus.Planned),
        new("Проведённые", ViewingStatus.Done),
        new("Отменённые", ViewingStatus.Cancelled),
    };

    private Choice<ViewingStatus> _status;

    public Choice<ViewingStatus> Status
    {
        get => _status;
        set
        {
            if (Set(ref _status, value))
            {
                _ = LoadAsync();
            }
        }
    }

    public AsyncRelayCommand AddCommand { get; }

    public AsyncRelayCommand EditCommand { get; }

    public AsyncRelayCommand DeleteCommand { get; }

    public AsyncRelayCommand DoneCommand { get; }

    public AsyncRelayCommand CancelCommand { get; }

    public override Task LoadAsync() => RunAsync(async () =>
    {
        var list = await _service.GetAllAsync(Status.Value);
        Items.Clear();
        foreach (var v in list)
        {
            Items.Add(v);
        }

        Footer = $"Показов: {Items.Count}";
    });

    private async Task AddAsync()
    {
        if (await Dialogs.ShowEditorAsync(_editors.ViewingEditor(null)))
        {
            await LoadAsync();
        }
    }

    private async Task EditAsync()
    {
        if (Selected is null)
        {
            return;
        }

        if (await Dialogs.ShowEditorAsync(_editors.ViewingEditor(Selected)))
        {
            await LoadAsync();
        }
    }

    private async Task DeleteAsync()
    {
        if (Selected is not { } v)
        {
            return;
        }

        if (!Dialogs.Confirm("Удалить показ?"))
        {
            return;
        }

        if (await RunAsync(() => _service.DeleteAsync(v.Id)))
        {
            await LoadAsync();
        }
    }

    private async Task SetStatusAsync(ViewingStatus status)
    {
        if (Selected is not { } v)
        {
            return;
        }

        if (await RunAsync(() => _service.SetStatusAsync(v.Id, status, null)))
        {
            await LoadAsync();
        }
    }
}

/// <summary>Сделки.</summary>
public sealed class DealsViewModel : PageViewModel
{
    private readonly IDealService _service;
    private readonly EditorFactory _editors;

    public DealsViewModel(IDialogService dialogs, IDealService service, EditorFactory editors)
        : base(dialogs)
    {
        _service = service;
        _editors = editors;
        _status = StatusChoices[0];

        AddCommand = new AsyncRelayCommand(AddAsync);
        CompleteCommand = new AsyncRelayCommand(CompleteAsync, () => Selected?.Status == DealStatus.Open);
        CancelCommand = new AsyncRelayCommand(CancelAsync, () => Selected?.Status == DealStatus.Open);
    }

    public override string Title => "Сделки";

    public override string Subtitle => "Продажа и аренда: от задатка до закрытия";

    public ObservableCollection<Deal> Items { get; } = new();

    private Deal? _selected;

    public Deal? Selected { get => _selected; set => Set(ref _selected, value); }

    public List<Choice<DealStatus>> StatusChoices { get; } = new()
    {
        new("Все сделки", null),
        new("Открытые", DealStatus.Open),
        new("Завершённые", DealStatus.Completed),
        new("Отменённые", DealStatus.Cancelled),
    };

    private Choice<DealStatus> _status;

    public Choice<DealStatus> Status
    {
        get => _status;
        set
        {
            if (Set(ref _status, value))
            {
                _ = LoadAsync();
            }
        }
    }

    private string _totals = string.Empty;

    public string Totals { get => _totals; private set => Set(ref _totals, value); }

    public AsyncRelayCommand AddCommand { get; }

    public AsyncRelayCommand CompleteCommand { get; }

    public AsyncRelayCommand CancelCommand { get; }

    public override Task LoadAsync() => RunAsync(async () =>
    {
        var list = await _service.GetAllAsync(Status.Value);
        Items.Clear();
        foreach (var d in list)
        {
            Items.Add(d);
        }

        var completed = list.Where(d => d.Status == DealStatus.Completed).ToList();
        Footer = $"Сделок: {Items.Count}";
        Totals = $"Комиссия по завершённым: {completed.Sum(d => d.Commission):N0} ₽";
    });

    private async Task AddAsync()
    {
        if (await Dialogs.ShowEditorAsync(_editors.DealEditor()))
        {
            await LoadAsync();
        }
    }

    private async Task CompleteAsync()
    {
        if (Selected is not { } d)
        {
            return;
        }

        if (!Dialogs.Confirm($"Завершить сделку по «{d.Property?.Address}»?\nОбъект получит статус «Закрыт»."))
        {
            return;
        }

        if (await RunAsync(() => _service.CompleteAsync(d.Id)))
        {
            await LoadAsync();
        }
    }

    private async Task CancelAsync()
    {
        if (Selected is not { } d)
        {
            return;
        }

        if (!Dialogs.Confirm($"Отменить сделку по «{d.Property?.Address}»?\nОбъект вернётся в продажу."))
        {
            return;
        }

        if (await RunAsync(() => _service.CancelAsync(d.Id)))
        {
            await LoadAsync();
        }
    }
}
