using System.Text;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using MySqlConnector;
using RealtyAgency.DataAccess;

namespace RealtyAgency.Tests.Integration;

/// <summary>
/// Тестовая база MySQL. Создаётся из тех же скриптов sql/01_schema.sql,
/// 02_seed.sql и 05_audit.sql, что и рабочая, но под именем realty_agency_test —
/// рабочая база realty_agency не затрагивается.
/// Строка подключения — testsettings.json или переменная окружения REALTY_TEST_MYSQL.
/// </summary>
public sealed class MySqlDatabase
{
    private static readonly string[] Scripts = { "01_schema.sql", "02_seed.sql", "05_audit.sql" };

    public MySqlDatabase()
    {
        var json = JsonDocument.Parse(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "testsettings.json"))).RootElement;
        RootConnection = Environment.GetEnvironmentVariable("REALTY_TEST_MYSQL") ?? json.GetProperty("MySqlRoot").GetString()!;
        Name = json.GetProperty("TestDatabase").GetString()!;
        ConnectionString = new MySqlConnectionStringBuilder(RootConnection) { Database = Name }.ConnectionString;
    }

    public string RootConnection { get; }

    public string Name { get; }

    public string ConnectionString { get; }

    /// <summary>Пересоздать базу и заполнить тестовыми данными.</summary>
    public async Task ResetAsync()
    {
        await using var connection = new MySqlConnection(RootConnection);
        await connection.OpenAsync();
        await ExecuteAsync(connection, $"DROP DATABASE IF EXISTS `{Name}`");
        foreach (var script in Scripts)
        {
            var text = await File.ReadAllTextAsync(Path.Combine(AppContext.BaseDirectory, "sql", script), Encoding.UTF8);
            foreach (var statement in SplitScript(text.Replace("realty_agency", Name)))
                await ExecuteAsync(connection, statement);
        }
    }

    public IDbContextFactory<RealtyDbContext> ContextFactory() => new Factory(ConnectionString);

    public async Task<T> ScalarAsync<T>(string sql)
    {
        await using var connection = new MySqlConnection(ConnectionString);
        await connection.OpenAsync();
        await using var command = new MySqlCommand(sql, connection);
        return (T)Convert.ChangeType((await command.ExecuteScalarAsync())!, typeof(T));
    }

    public async Task ExecuteAsync(string sql)
    {
        await using var connection = new MySqlConnection(ConnectionString);
        await connection.OpenAsync();
        await ExecuteAsync(connection, sql);
    }

    private static async Task ExecuteAsync(MySqlConnection connection, string sql)
    {
        await using var command = new MySqlCommand(sql, connection);
        await command.ExecuteNonQueryAsync();
    }

    /// <summary>Разбивает скрипт на команды с учётом DELIMITER (как консоль mysql).</summary>
    private static IEnumerable<string> SplitScript(string script)
    {
        var delimiter = ";";
        var current = new StringBuilder();
        foreach (var rawLine in script.Replace("\r", string.Empty).Split('\n'))
        {
            var line = rawLine.TrimEnd();
            if (line.TrimStart().StartsWith("DELIMITER ", StringComparison.OrdinalIgnoreCase))
            {
                delimiter = line.Trim()["DELIMITER ".Length..].Trim();
                continue;
            }

            if (current.Length == 0 && (line.TrimStart().StartsWith("--") || line.Trim().Length == 0))
                continue;

            current.AppendLine(line);
            if (line.EndsWith(delimiter, StringComparison.Ordinal))
            {
                var statement = current.ToString().TrimEnd();
                yield return statement[..^delimiter.Length];
                current.Clear();
            }
        }

        if (current.ToString().Trim().Length > 0)
            yield return current.ToString();
    }

    private sealed class Factory : IDbContextFactory<RealtyDbContext>
    {
        private readonly DbContextOptions<RealtyDbContext> _options;

        public Factory(string connectionString)
        {
            _options = new DbContextOptionsBuilder<RealtyDbContext>()
                .UseMySql(connectionString, new MySqlServerVersion(new Version(8, 0, 36)))
                .UseSnakeCaseNamingConvention()
                .Options;
        }

        public RealtyDbContext CreateDbContext() => new(_options);
    }
}

/// <summary>Интеграционные тесты выполняются последовательно — у них одна общая база.</summary>
[CollectionDefinition("MySQL", DisableParallelization = true)]
public sealed class MySqlCollection : ICollectionFixture<MySqlDatabase>
{
}

/// <summary>Базовый класс: перед каждым тестом база пересоздаётся из скриптов.</summary>
[Collection("MySQL")]
[Trait("Category", "Integration")]
public abstract class IntegrationTestBase : IAsyncLifetime
{
    protected IntegrationTestBase(MySqlDatabase db) => Db = db;

    protected MySqlDatabase Db { get; }

    public Task InitializeAsync() => Db.ResetAsync();

    public Task DisposeAsync() => Task.CompletedTask;
}
