"""«Ключ» на Tkinter — графическое приложение для работы с базой риэлторского агентства.

Запуск:  python app.py   (перед этим: pip install -r requirements.txt и настройка config.ini)
Вкладки: Объекты, Клиенты, Сделки, Отчёт. Все обращения к БД — в модуле db.py.
"""
import csv
import datetime
import tkinter as tk
from decimal import Decimal
from tkinter import filedialog, messagebox, ttk

from db import STATUS_RU, Database, DbError, parse_money

APP_TITLE = "Ключ — риэлторское агентство (Tkinter)"


def money(value):
    """12300000 → «12 300 000»."""
    return f"{value:,.0f}".replace(",", " ")


def run(action):
    """Выполняет действие и показывает понятное сообщение, если что-то пошло не так."""
    try:
        return action()
    except DbError as e:
        messagebox.showwarning(APP_TITLE, str(e))
    return None


class Table(ttk.Frame):
    """Treeview с прокруткой: columns = [(ключ, заголовок, ширина)]."""

    def __init__(self, master, columns):
        super().__init__(master)
        self.keys = [c[0] for c in columns]
        self.tree = ttk.Treeview(self, columns=self.keys, show="headings", selectmode="browse")
        for key, title, width in columns:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, anchor="w")
        scroll = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    def fill(self, rows, convert):
        self.tree.delete(*self.tree.get_children())
        for row in rows:
            self.tree.insert("", "end", iid=str(row["id"]), values=convert(row))

    def selected_id(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo(APP_TITLE, "Выберите строку в таблице.")
            return None
        return int(sel[0])


class Form(tk.Toplevel):
    """Модальное окно-форма: поля добавляются методами entry/combo/text, результат — в self.result."""

    def __init__(self, master, title):
        super().__init__(master)
        self.title(title)
        self.resizable(False, False)
        self.transient(master)
        self.body = ttk.Frame(self, padding=12)
        self.body.pack(fill="both", expand=True)
        self.row = 0
        self.result = None

    def _label(self, text):
        ttk.Label(self.body, text=text).grid(row=self.row, column=0, sticky="w", pady=3, padx=(0, 8))

    def entry(self, text, value=""):
        self._label(text)
        var = tk.StringVar(value=value)
        ttk.Entry(self.body, textvariable=var, width=40).grid(row=self.row, column=1, sticky="we")
        self.row += 1
        return var

    def combo(self, text, items, selected_id=None):
        """items — список (id, подпись). Возвращает функцию, которая вернёт выбранный id."""
        self._label(text)
        box = ttk.Combobox(self.body, values=[t for _, t in items], state="readonly", width=38)
        box.grid(row=self.row, column=1, sticky="we")
        ids = [i for i, _ in items]
        if selected_id in ids:
            box.current(ids.index(selected_id))
        self.row += 1
        return lambda: ids[box.current()] if box.current() >= 0 else None

    def buttons(self, on_save, save_text="Сохранить"):
        frame = ttk.Frame(self.body)
        frame.grid(row=self.row, column=0, columnspan=2, sticky="e", pady=(10, 0))
        ttk.Button(frame, text=save_text, command=on_save).pack(side="left", padx=4)
        ttk.Button(frame, text="Отмена", command=self.destroy).pack(side="left")
        self.grab_set()
        self.wait_window()


class PropertiesTab(ttk.Frame):
    def __init__(self, master, db):
        super().__init__(master, padding=8)
        self.db = db
        filters = ttk.Frame(self)
        filters.pack(fill="x", pady=(0, 6))
        self.search = tk.StringVar()
        self.min_price = tk.StringVar()
        self.max_price = tk.StringVar()
        ttk.Label(filters, text="Адрес:").pack(side="left")
        ttk.Entry(filters, textvariable=self.search, width=18).pack(side="left", padx=(2, 8))
        self.districts = [(None, "Все районы")] + [(d["id"], d["name"]) for d in run(db.districts) or []]
        self.district = ttk.Combobox(filters, values=[t for _, t in self.districts], state="readonly", width=14)
        self.district.current(0)
        self.district.pack(side="left", padx=(0, 8))
        self.offers = [(None, "Любой вид"), ("sale", "Продажа"), ("rent", "Аренда")]
        self.offer = ttk.Combobox(filters, values=[t for _, t in self.offers], state="readonly", width=11)
        self.offer.current(0)
        self.offer.pack(side="left", padx=(0, 8))
        self.statuses = [(None, "Любой статус"), ("active", "Активен"), ("reserved", "Зарезервирован"),
                         ("closed", "Закрыт"), ("archived", "Снят")]
        self.status = ttk.Combobox(filters, values=[t for _, t in self.statuses], state="readonly", width=15)
        self.status.current(0)
        self.status.pack(side="left", padx=(0, 8))
        ttk.Label(filters, text="Цена от").pack(side="left")
        ttk.Entry(filters, textvariable=self.min_price, width=11).pack(side="left", padx=2)
        ttk.Label(filters, text="до").pack(side="left")
        ttk.Entry(filters, textvariable=self.max_price, width=11).pack(side="left", padx=(2, 8))
        ttk.Button(filters, text="Найти", command=self.load).pack(side="left")

        actions = ttk.Frame(self)
        actions.pack(fill="x", pady=(0, 6))
        for text, cmd in (("Добавить", self.add), ("Изменить", self.edit), ("Снять / вернуть", self.archive),
                          ("Удалить", self.delete)):
            ttk.Button(actions, text=text, command=cmd).pack(side="left", padx=(0, 4))

        self.table = Table(self, [("address", "Адрес", 230), ("district", "Район", 100), ("type", "Тип", 110),
                                  ("offer", "Вид", 70), ("price", "Цена, ₽", 100), ("area", "Площадь", 70),
                                  ("rooms", "Комн.", 50), ("status", "Статус", 105), ("owner", "Собственник", 180)])
        self.table.pack(fill="both", expand=True)
        self.load()

    def load(self):
        def action():
            rows = self.db.properties(
                search=self.search.get(), district_id=self.districts[self.district.current()][0],
                offer=self.offers[self.offer.current()][0], status=self.statuses[self.status.current()][0],
                min_price=parse_money(self.min_price.get(), "Цена от"), max_price=parse_money(self.max_price.get(), "Цена до"))
            self.table.fill(rows, lambda r: (r["address"], r["district"], r["type"], STATUS_RU[r["offer_type"]],
                                             money(r["price"]), f"{float(r['area']):g}", r["rooms"], STATUS_RU[r["status"]],
                                             r["owner"]))
        run(action)

    def _form(self, existing):
        types = [(t["id"], t["name"]) for t in self.db.property_types()]
        clients = [(c["id"], c["full_name"]) for c in self.db.clients()]
        realtors = [(r["id"], r["full_name"]) for r in self.db.realtors()]
        e = existing or {}
        form = Form(self, "Объект" if existing else "Новый объект")
        address = form.entry("Адрес *", e.get("address", ""))
        district = form.combo("Район *", self.districts[1:], e.get("district_id"))
        ptype = form.combo("Тип *", types, e.get("property_type_id"))
        offer = form.combo("Вид *", self.offers[1:], e.get("offer_type", "sale"))
        price = form.entry("Цена, ₽ *", money(e["price"]) if e else "")
        area = form.entry("Площадь, м² *", f"{float(e['area']):g}" if e else "")
        rooms = form.entry("Комнат *", str(e.get("rooms", 1)))
        owner = form.combo("Собственник *", clients, e.get("owner_id"))
        realtor = form.combo("Риэлтор *", realtors, e.get("realtor_id"))
        description = form.entry("Описание", e.get("description") or "")

        def save():
            def action():
                rooms_text = rooms.get().strip()
                if not rooms_text.isdigit():
                    raise DbError("Поле «Комнат»: введите целое число")
                self.db.save_property(existing["id"] if existing else None, {
                    "address": address.get().strip(), "district_id": district(), "property_type_id": ptype(),
                    "owner_id": owner(), "realtor_id": realtor(), "offer_type": offer() or "sale",
                    "price": parse_money(price.get(), "Цена") or Decimal(0),
                    "area": parse_money(area.get(), "Площадь") or Decimal(0), "rooms": int(rooms_text),
                    "description": description.get().strip() or None})
                return True
            if run(action):
                form.destroy()
                self.load()
        form.buttons(save)

    def add(self):
        run(lambda: self._form(None))

    def edit(self):
        pid = self.table.selected_id()
        if pid:
            run(lambda: self._form(self.db.property_by_id(pid)))

    def archive(self):
        pid = self.table.selected_id()
        if pid and run(lambda: self.db.toggle_archive(pid) or True):
            self.load()

    def delete(self):
        pid = self.table.selected_id()
        if pid and messagebox.askyesno(APP_TITLE, "Удалить объект вместе с его показами?"):
            if run(lambda: self.db.delete_property(pid) or True):
                self.load()


class ClientsTab(ttk.Frame):
    def __init__(self, master, db):
        super().__init__(master, padding=8)
        self.db = db
        top = ttk.Frame(self)
        top.pack(fill="x", pady=(0, 6))
        self.search = tk.StringVar()
        ttk.Label(top, text="Поиск (ФИО, телефон, e-mail):").pack(side="left")
        entry = ttk.Entry(top, textvariable=self.search, width=30)
        entry.pack(side="left", padx=4)
        entry.bind("<Return>", lambda _: self.load())
        for text, cmd in (("Найти", self.load), ("Добавить", self.add), ("Изменить", self.edit), ("Удалить", self.delete)):
            ttk.Button(top, text=text, command=cmd).pack(side="left", padx=(0, 4))
        self.table = Table(self, [("name", "ФИО", 250), ("phone", "Телефон", 150), ("email", "E-mail", 180),
                                  ("notes", "Заметка", 300)])
        self.table.pack(fill="both", expand=True)
        self.load()

    def load(self):
        run(lambda: self.table.fill(self.db.clients(self.search.get()),
                                    lambda r: (r["full_name"], r["phone"], r["email"] or "", r["notes"] or "")))

    def _form(self, existing):
        e = existing or {}
        form = Form(self, "Клиент" if existing else "Новый клиент")
        name = form.entry("ФИО *", e.get("full_name", ""))
        phone = form.entry("Телефон *", e.get("phone", ""))
        email = form.entry("E-mail", e.get("email") or "")
        notes = form.entry("Заметка", e.get("notes") or "")

        def save():
            if run(lambda: self.db.save_client(e.get("id"), name.get(), phone.get(), email.get(), notes.get()) or True):
                form.destroy()
                self.load()
        form.buttons(save)

    def add(self):
        self._form(None)

    def edit(self):
        cid = self.table.selected_id()
        if cid:
            rows = [c for c in run(self.db.clients) or [] if c["id"] == cid]
            if rows:
                self._form(rows[0])

    def delete(self):
        cid = self.table.selected_id()
        if cid and messagebox.askyesno(APP_TITLE, "Удалить клиента?"):
            if run(lambda: self.db.delete_client(cid) or True):
                self.load()


class DealsTab(ttk.Frame):
    def __init__(self, master, db, on_change):
        super().__init__(master, padding=8)
        self.db = db
        self.on_change = on_change
        top = ttk.Frame(self)
        top.pack(fill="x", pady=(0, 6))
        self.statuses = [(None, "Все сделки"), ("open", "Открытые"), ("completed", "Завершённые"), ("cancelled", "Отменённые")]
        self.status = ttk.Combobox(top, values=[t for _, t in self.statuses], state="readonly", width=14)
        self.status.current(0)
        self.status.bind("<<ComboboxSelected>>", lambda _: self.load())
        self.status.pack(side="left", padx=(0, 8))
        for text, cmd in (("Оформить сделку", self.create), ("Завершить", lambda: self.change("completed")),
                          ("Отменить", lambda: self.change("cancelled"))):
            ttk.Button(top, text=text, command=cmd).pack(side="left", padx=(0, 4))
        self.table = Table(self, [("date", "Дата", 90), ("address", "Объект", 230), ("client", "Клиент", 190),
                                  ("realtor", "Риэлтор", 180), ("amount", "Сумма, ₽", 110),
                                  ("commission", "Комиссия, ₽", 100), ("status", "Статус", 90)])
        self.table.pack(fill="both", expand=True)
        self.load()

    def load(self):
        run(lambda: self.table.fill(self.db.deals(self.statuses[self.status.current()][0]), lambda r: (
            r["deal_date"].strftime("%d.%m.%Y"), r["address"], r["client"], r["realtor"], money(r["amount"]),
            money(r["commission"]), STATUS_RU[r["status"]])))

    def create(self):
        def open_form():
            props = [(p["id"], f"{p['address']} — {money(p['price'])} ₽") for p in self.db.properties(status="active")]
            clients = [(c["id"], c["full_name"]) for c in self.db.clients()]
            realtors = [(r["id"], f"{r['full_name']} ({r['commission_percent']:g} %)") for r in self.db.realtors()]
            form = Form(self, "Оформление сделки")
            prop = form.combo("Объект (активный) *", props)
            client = form.combo("Покупатель / арендатор *", clients)
            realtor = form.combo("Риэлтор *", realtors)
            amount = form.entry("Сумма сделки, ₽ *")

            def save():
                def action():
                    if not (prop() and client() and realtor()):
                        raise DbError("Выберите объект, клиента и риэлтора.")
                    return self.db.create_deal(prop(), client(), realtor(),
                                               parse_money(amount.get(), "Сумма") or Decimal(0))
                result = run(action)
                if result:
                    messagebox.showinfo(APP_TITLE, f"Сделка № {result[0]} оформлена. Комиссия: {money(result[1])} ₽.")
                    form.destroy()
                    self.load()
                    self.on_change()
            form.buttons(save, "Оформить")
        run(open_form)

    def change(self, status):
        did = self.table.selected_id()
        if did and run(lambda: self.db.change_deal(did, status) or True):
            self.load()
            self.on_change()


class ReportTab(ttk.Frame):
    def __init__(self, master, db):
        super().__init__(master, padding=8)
        self.db = db
        self.rows = []
        top = ttk.Frame(self)
        top.pack(fill="x", pady=(0, 6))
        today = datetime.date.today()
        self.date_from = tk.StringVar(value=today.replace(day=1).strftime("%d.%m.%Y"))
        self.date_to = tk.StringVar(value=today.strftime("%d.%m.%Y"))
        ttk.Label(top, text="Сделки с").pack(side="left")
        ttk.Entry(top, textvariable=self.date_from, width=11).pack(side="left", padx=4)
        ttk.Label(top, text="по").pack(side="left")
        ttk.Entry(top, textvariable=self.date_to, width=11).pack(side="left", padx=4)
        ttk.Button(top, text="Сформировать", command=self.build).pack(side="left", padx=4)
        ttk.Button(top, text="Экспорт в CSV", command=self.export).pack(side="left")
        self.total = ttk.Label(self, text="", font=("Segoe UI", 10, "bold"))
        self.total.pack(anchor="w", pady=(0, 6))
        self.table = Table(self, [("day", "Дата", 90), ("address", "Объект", 230), ("offer", "Вид", 70),
                                  ("client", "Клиент", 180), ("realtor", "Риэлтор", 170), ("amount", "Сумма, ₽", 110),
                                  ("commission", "Комиссия, ₽", 100), ("status", "Статус", 90)])
        self.table.pack(fill="both", expand=True)

    def _date(self, text, field):
        try:
            return datetime.datetime.strptime(text.strip(), "%d.%m.%Y").date()
        except ValueError as e:
            raise DbError(f"Поле «{field}»: дата в формате ДД.ММ.ГГГГ") from e

    def build(self):
        def action():
            self.rows = self.db.deals_report(self._date(self.date_from.get(), "с"), self._date(self.date_to.get(), "по"))
            for i, r in enumerate(self.rows, 1):
                r["id"] = i
            self.table.fill(self.rows, lambda r: (r["day"], r["address"], STATUS_RU[r["offer_type"]], r["client"],
                                                  r["realtor"], money(r["amount"]), money(r["commission"]),
                                                  STATUS_RU[r["status"]]))
            done = [r for r in self.rows if r["status"] == "completed"]
            self.total.config(text=f"Сделок: {len(self.rows)}, завершено: {len(done)}, комиссия по завершённым: "
                                   f"{money(sum(r['commission'] for r in done))} ₽")
        run(action)

    def export(self):
        if not self.rows:
            messagebox.showinfo(APP_TITLE, "Сначала сформируйте отчёт.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV (Excel)", "*.csv")],
                                            initialfile=f"Сделки {datetime.date.today():%Y-%m-%d}.csv")
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:   # BOM — чтобы Excel понял кириллицу
            writer = csv.writer(f, delimiter=";")
            writer.writerow(["Дата", "Объект", "Вид", "Клиент", "Риэлтор", "Сумма", "Комиссия", "Статус"])
            for r in self.rows:
                writer.writerow([r["day"], r["address"], STATUS_RU[r["offer_type"]], r["client"], r["realtor"],
                                 str(r["amount"]).replace(".", ","), str(r["commission"]).replace(".", ","),
                                 STATUS_RU[r["status"]]])
        messagebox.showinfo(APP_TITLE, f"Отчёт сохранён:\n{path}")


def main():
    root = tk.Tk()
    root.title(APP_TITLE)
    root.geometry("1180x620")
    ttk.Style().theme_use("clam")
    try:
        db = Database()
        db.query("SELECT 1")
    except DbError as e:
        messagebox.showerror(APP_TITLE, str(e))
        root.destroy()
        return
    tabs = ttk.Notebook(root)
    tabs.pack(fill="both", expand=True)
    properties = PropertiesTab(tabs, db)
    tabs.add(properties, text="Объекты")
    tabs.add(ClientsTab(tabs, db), text="Клиенты")
    tabs.add(DealsTab(tabs, db, on_change=properties.load), text="Сделки")
    tabs.add(ReportTab(tabs, db), text="Отчёт")
    root.mainloop()


if __name__ == "__main__":
    main()
