using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.BusinessLogic.Logging;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Interfaces;

namespace RealtyAgency.BusinessLogic.Services;

/// <summary>Показы: проверка доступности объекта и занятости риэлтора.</summary>
public class ViewingService : ServiceBase, IViewingService
{
    /// <summary>
    /// Минимальный интервал между показами одного риэлтора — ровно час.
    /// Репозиторий ищет показы строго внутри окна (время ± MinGap),
    /// поэтому показ через 60 минут разрешён, а через 59 — нет.
    /// </summary>
    public static readonly TimeSpan MinGap = TimeSpan.FromHours(1);

    private readonly IViewingRepository _viewings;
    private readonly IPropertyRepository _properties;
    private readonly IRealtorRepository _realtors;

    /// <summary>Инициализирует новый экземпляр класса <see cref="ViewingService"/>.</summary>
    /// <param name="viewings">Репозиторий показов.</param>
    /// <param name="properties">Репозиторий объектов.</param>
    /// <param name="realtors">Репозиторий риэлторов.</param>
    public ViewingService(IViewingRepository viewings, IPropertyRepository properties, IRealtorRepository realtors)
    {
        _viewings = viewings;
        _properties = properties;
        _realtors = realtors;
    }

    /// <inheritdoc/>
    public Task<List<Viewing>> GetAllAsync(ViewingStatus? status = null) =>
        GuardAsync("Список показов", () => _viewings.GetAllAsync(status));

    /// <inheritdoc/>
    public Task SaveAsync(Viewing viewing) =>
        GuardAsync("Сохранение показа", async () =>
        {
            Validate(viewing);
            await EnsurePropertyCanBeShownAsync(viewing);
            await EnsureRealtorIsFreeAsync(viewing);

            if (viewing.Id == 0)
            {
                await _viewings.AddAsync(viewing);
            }
            else
            {
                await _viewings.UpdateAsync(viewing);
            }

            AppLog.Info("BLL", $"Показ сохранён: ID={viewing.Id}, объект {viewing.PropertyId}, {viewing.ScheduledAt:dd.MM HH:mm}");
        });

    /// <inheritdoc/>
    public Task SetStatusAsync(int id, ViewingStatus status, string? feedback) =>
        GuardAsync($"Показ ID={id} -> {status}", async () =>
        {
            var viewing = await _viewings.GetByIdAsync(id)
                          ?? throw new EntityNotFoundException($"Показ ID={id} не найден");

            if (status == ViewingStatus.Done && viewing.ScheduledAt > DateTime.Now)
            {
                throw new BusinessRuleException("Нельзя отметить проведённым показ, который ещё не наступил.");
            }

            viewing.Status = status;
            if (!string.IsNullOrWhiteSpace(feedback))
            {
                viewing.Feedback = feedback.Trim();
            }

            await _viewings.UpdateAsync(viewing);
        });

    /// <inheritdoc/>
    public Task DeleteAsync(int id) =>
        GuardAsync($"Удаление показа ID={id}", () => _viewings.DeleteAsync(id));

    private static void Validate(Viewing viewing)
    {
        viewing.Feedback = Validator.Clean(viewing.Feedback);

        new Validator()
            .Require(viewing.PropertyId > 0, "Выберите объект")
            .Require(viewing.ClientId > 0, "Выберите клиента")
            .Require(viewing.RealtorId > 0, "Выберите риэлтора")
            .Require(viewing.Id != 0 || viewing.ScheduledAt > DateTime.Now, "Новый показ нельзя назначить на прошедшее время")
            .Require((viewing.Feedback?.Length ?? 0) <= Limits.MaxNoteLength, $"Отзыв — не длиннее {Limits.MaxNoteLength} символов")
            .ThrowIfInvalid();
    }

    private async Task EnsurePropertyCanBeShownAsync(Viewing viewing)
    {
        var property = await _properties.GetByIdAsync(viewing.PropertyId)
                       ?? throw new EntityNotFoundException("Выбранный объект не найден");

        if (property.Status is PropertyStatus.Closed or PropertyStatus.Archived)
        {
            throw new PropertyNotAvailableException(
                property.Id,
                $"Объект «{property.Address}» уже закрыт или снят — показ невозможен.");
        }

        if (property.OwnerId == viewing.ClientId)
        {
            throw new ValidationException("Клиент — собственник этого объекта, показ ему не нужен");
        }
    }

    private async Task EnsureRealtorIsFreeAsync(Viewing viewing)
    {
        if (viewing.Status != ViewingStatus.Planned
            || !await _viewings.HasRealtorConflictAsync(viewing.RealtorId, viewing.ScheduledAt, MinGap, viewing.Id))
        {
            return;
        }

        var realtor = await _realtors.GetByIdAsync(viewing.RealtorId);
        throw new RealtorBusyException(realtor?.FullName ?? $"ID={viewing.RealtorId}", viewing.ScheduledAt);
    }
}
