Простое приложение Tkinter + MySQL (база realty_tk, таблица clients)

1. Распакуйте архив: clients_app.py и папка pymysql должны лежать рядом.
2. Откройте clients_app.py и в строке DB = dict(...) впишите свой пароль root (password="...").
3. Запуск:  python clients_app.py
   База realty_tk и таблица clients создадутся сами при первом запуске.

Ничего устанавливать не нужно: tkinter входит в Python, pymysql лежит в папке рядом.
Если Python пишет "No module named tkinter" — переустановите Python с python.org
и в установщике оставьте галочку "tcl/tk and IDLE".
