namespace RealtyAgency.DataAccess;

/// <summary>Настройки подключения (читаются из appsettings.json в App.xaml.cs).</summary>
/// <param name="ConnectionString">Строка подключения к MySQL.</param>
public sealed record DbSettings(string ConnectionString);
