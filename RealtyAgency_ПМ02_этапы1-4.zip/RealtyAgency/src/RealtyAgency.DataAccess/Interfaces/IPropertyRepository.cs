using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.DataAccess.Interfaces;

/// <summary>Объекты недвижимости.</summary>
public interface IPropertyRepository
{
    /// <summary>Ищет объекты по фильтру (вместе с районом, типом, собственником и риэлтором).</summary>
    /// <param name="filter">Параметры поиска.</param>
    /// <returns>Объекты, новые — первыми.</returns>
    Task<List<Property>> SearchAsync(PropertyFilter filter);

    /// <summary>Возвращает активные и зарезервированные объекты по адресу.</summary>
    /// <returns>Список объектов.</returns>
    Task<List<Property>> GetAvailableAsync();

    /// <summary>Находит объект по коду.</summary>
    /// <param name="id">Код объекта.</param>
    /// <returns>Объект или <see langword="null"/>.</returns>
    Task<Property?> GetByIdAsync(int id);

    /// <summary>Добавляет объект; после вызова заполнен <see cref="Property.Id"/>.</summary>
    /// <param name="property">Объект.</param>
    /// <returns>Задача.</returns>
    Task AddAsync(Property property);

    /// <summary>Сохраняет изменения объекта.</summary>
    /// <param name="property">Объект.</param>
    /// <returns>Задача.</returns>
    Task UpdateAsync(Property property);

    /// <summary>Удаляет объект (показы удаляются каскадно).</summary>
    /// <param name="id">Код объекта.</param>
    /// <returns>Задача.</returns>
    Task DeleteAsync(int id);
}
