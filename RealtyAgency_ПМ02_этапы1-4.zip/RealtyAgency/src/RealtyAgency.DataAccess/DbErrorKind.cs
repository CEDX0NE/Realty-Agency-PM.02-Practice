namespace RealtyAgency.DataAccess;

/// <summary>Вид ошибки при работе с БД.</summary>
public enum DbErrorKind
{
    /// <summary>Прочие ошибки.</summary>
    General,

    /// <summary>Сервер недоступен, неверный логин или нет базы.</summary>
    Connection,

    /// <summary>Запись не найдена.</summary>
    NotFound,

    /// <summary>Запись используется в других таблицах или ссылается на несуществующую.</summary>
    ForeignKey,

    /// <summary>Нарушена уникальность (телефон и т.п.).</summary>
    Duplicate,

    /// <summary>Сработал триггер-предохранитель (SIGNAL SQLSTATE '45000').</summary>
    Rule,
}
