using RealtyAgency.DataAccess;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Repositories;

namespace RealtyAgency.Tests.Integration;

/// <summary>Слой доступа к данным на настоящей БД MySQL: EF Core, триггеры, ограничения.</summary>
public class RepositoryTests : IntegrationTestBase
{
    public RepositoryTests(MySqlDatabase db)
        : base(db)
    {
    }

    [Fact]
    public async Task Search_NoFilter_ReturnsAllWithReferences()
    {
        var repo = new PropertyRepository(Db.ContextFactory());

        var all = await repo.SearchAsync(new PropertyFilter());

        Assert.Equal(14, all.Count);
        Assert.All(all, p => Assert.NotNull(p.District));
        Assert.Contains(all, p => p.Status == PropertyStatus.Reserved);
    }

    [Fact]
    [Trait("TC", "ТК-08")]
    public async Task Search_PriceRangeBoundaries_AreInclusive()
    {
        var repo = new PropertyRepository(Db.ContextFactory());

        var found = await repo.SearchAsync(new PropertyFilter { MinPrice = 9_900_000m, MaxPrice = 12_500_000m });

        // 9 900 000 (ул. Речная), 11 200 000 (ул. Школьная), 12 500 000 (ул. Ленина)
        Assert.Equal(new[] { 9_900_000m, 11_200_000m, 12_500_000m }, found.Select(p => p.Price).OrderBy(x => x));
    }

    [Fact]
    [Trait("TC", "ТК-08")]
    public async Task Search_CombinedFilters()
    {
        var repo = new PropertyRepository(Db.ContextFactory());

        var found = await repo.SearchAsync(new PropertyFilter
        {
            OfferType = OfferType.Rent, Status = PropertyStatus.Active, MinRooms = 1, Search = "ул.",
        });

        Assert.Equal(2, found.Count);
        Assert.All(found, p => Assert.Equal(OfferType.Rent, p.OfferType));
    }

    [Fact]
    public async Task GetAvailable_ReturnsActiveAndReservedOnly()
    {
        var repo = new PropertyRepository(Db.ContextFactory());

        var found = await repo.GetAvailableAsync();

        Assert.Equal(11, found.Count);
        Assert.DoesNotContain(found, p => p.Status is PropertyStatus.Closed or PropertyStatus.Archived);
    }

    [Fact]
    [Trait("TC", "ТК-21")]
    public async Task ClientSearch_ByPartOfPhone()
    {
        var repo = new ClientRepository(Db.ContextFactory());

        var found = await repo.GetAllAsync("200-00-05");

        Assert.Equal("Морозов Павел Николаевич", Assert.Single(found).FullName);
    }

    [Fact]
    public async Task AddClient_DuplicatePhone_TranslatedToDuplicate()
    {
        var repo = new ClientRepository(Db.ContextFactory());

        var ex = await Assert.ThrowsAsync<DataAccessException>(() =>
            repo.AddAsync(new Client { FullName = "Копия Клиента", Phone = "+7 (916) 200-00-01" }));

        Assert.Equal(DbErrorKind.Duplicate, ex.Kind);
    }

    [Fact]
    public async Task DeleteClientWithProperties_TranslatedToForeignKey()
    {
        var repo = new ClientRepository(Db.ContextFactory());

        var ex = await Assert.ThrowsAsync<DataAccessException>(() => repo.DeleteAsync(1));

        Assert.Equal(DbErrorKind.ForeignKey, ex.Kind);
    }

    [Fact]
    public async Task UpdateMissingRecord_TranslatedToNotFound()
    {
        var repo = new ClientRepository(Db.ContextFactory());

        var ex = await Assert.ThrowsAsync<DataAccessException>(() =>
            repo.UpdateAsync(new Client { Id = 999, FullName = "Нет Такого", Phone = "+7 (916) 999-99-99" }));

        Assert.Equal(DbErrorKind.NotFound, ex.Kind);
    }

    [Fact]
    public async Task CreateDeal_OnArchivedProperty_StoppedByTrigger()
    {
        var repo = new DealRepository(Db.ContextFactory());
        var deal = new Deal { PropertyId = 12, ClientId = 2, RealtorId = 1, Amount = 6_000_000m, Commission = 1m };

        var ex = await Assert.ThrowsAsync<DataAccessException>(() => repo.CreateAsync(deal, PropertyStatus.Reserved));

        Assert.Equal(DbErrorKind.Rule, ex.Kind);
        Assert.Equal(3, await Db.ScalarAsync<int>("SELECT COUNT(*) FROM deals"));
    }

    [Fact]
    public async Task CreateDeal_WritesDealAndPropertyStatusInOneTransaction()
    {
        var repo = new DealRepository(Db.ContextFactory());
        var deal = new Deal { PropertyId = 2, ClientId = 2, RealtorId = 3, Amount = 18_500_000m, Commission = 647_500m };

        await repo.CreateAsync(deal, PropertyStatus.Reserved);

        Assert.True(deal.Id > 0);
        Assert.Equal("reserved", await Db.ScalarAsync<string>("SELECT status FROM properties WHERE id = 2"));
        Assert.Equal(1, await Db.ScalarAsync<int>($"SELECT COUNT(*) FROM audit_log WHERE table_name = 'deals' AND record_id = {deal.Id}"));
    }

    [Fact]
    public async Task ViewingConflict_ThirtyMinutesApart_Detected()
    {
        var repo = new ViewingRepository(Db.ContextFactory());
        var planned = await Db.ScalarAsync<DateTime>("SELECT scheduled_at FROM viewings WHERE id = 6");

        var conflict = await repo.HasRealtorConflictAsync(3, planned.AddMinutes(30), TimeSpan.FromMinutes(59), 0);

        Assert.True(conflict);
    }
}
