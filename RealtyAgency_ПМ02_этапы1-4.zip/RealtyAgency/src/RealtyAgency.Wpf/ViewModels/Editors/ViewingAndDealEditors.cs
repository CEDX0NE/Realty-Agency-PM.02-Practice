using System.Globalization;
using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.Wpf.ViewModels.Editors;

/// <summary>Форма показа объекта.</summary>
public sealed class ViewingEditorViewModel : EditorViewModelBase
{
    private static readonly string[] TimeFormats = { @"h\:mm", @"hh\:mm" };

    private readonly IViewingService _service;
    private readonly IPropertyService _properties;
    private readonly IClientService _clients;
    private readonly IRealtorService _realtors;
    private readonly Viewing? _existing;

    public ViewingEditorViewModel(
        IViewingService service,
        IPropertyService properties,
        IClientService clients,
        IRealtorService realtors,
        Viewing? existing,
        int? presetPropertyId)
    {
        _service = service;
        _properties = properties;
        _clients = clients;
        _realtors = realtors;
        _existing = existing;

        if (existing is not null)
        {
            _propertyId = existing.PropertyId;
            _clientId = existing.ClientId;
            _realtorId = existing.RealtorId;
            _date = existing.ScheduledAt.Date;
            _time = existing.ScheduledAt.ToString("HH:mm", CultureInfo.InvariantCulture);
            _feedback = existing.Feedback ?? string.Empty;
        }
        else
        {
            _propertyId = presetPropertyId;
            _date = DateTime.Today.AddDays(1);
            _time = "12:00";
        }
    }

    public override string Title => _existing is null ? "Новый показ" : "Редактирование показа";

    public List<Property> Properties { get; private set; } = new();

    public List<Client> Clients { get; private set; } = new();

    public List<Realtor> Realtors { get; private set; } = new();

    public override async Task LoadAsync()
    {
        Properties = await _properties.GetAvailableAsync();
        Clients = await _clients.GetAllAsync();
        Realtors = (await _realtors.GetAllAsync())
            .Where(r => r.IsActive || r.Id == _existing?.RealtorId)
            .ToList();

        OnPropertyChanged(nameof(Properties));
        OnPropertyChanged(nameof(Clients));
        OnPropertyChanged(nameof(Realtors));

        // Если объект выбран заранее — подставим его риэлтора
        if (_existing is null && PropertyId is int id)
        {
            ApplyPropertyRealtor(id);
        }
    }

    private int? _propertyId;

    public int? PropertyId
    {
        get => _propertyId;
        set
        {
            if (Set(ref _propertyId, value) && value is int id && _existing is null)
            {
                ApplyPropertyRealtor(id);
            }
        }
    }

    private void ApplyPropertyRealtor(int propertyId)
    {
        var p = Properties.FirstOrDefault(x => x.Id == propertyId);
        if (p is not null && Realtors.Any(r => r.Id == p.RealtorId))
        {
            RealtorId = p.RealtorId;
        }
    }

    private int? _clientId;

    public int? ClientId { get => _clientId; set => Set(ref _clientId, value); }

    private int? _realtorId;

    public int? RealtorId { get => _realtorId; set => Set(ref _realtorId, value); }

    private DateTime? _date;

    public DateTime? Date { get => _date; set => Set(ref _date, value); }

    private string _time = string.Empty;

    public string Time { get => _time; set => Set(ref _time, value); }

    private string _feedback = string.Empty;

    public string Feedback { get => _feedback; set => Set(ref _feedback, value); }

    protected override async Task SaveCoreAsync(List<string> parseErrors)
    {
        var scheduledAt = ParseScheduledAt(parseErrors);
        if (scheduledAt is null)
        {
            return;
        }

        await _service.SaveAsync(new Viewing
        {
            Id = _existing?.Id ?? 0,
            PropertyId = PropertyId ?? 0,
            ClientId = ClientId ?? 0,
            RealtorId = RealtorId ?? 0,
            ScheduledAt = scheduledAt.Value,
            Status = _existing?.Status ?? ViewingStatus.Planned,
            Feedback = Feedback,
        });
    }

    /// <summary>Дата из календаря + время «ЧЧ:ММ»; ошибки разбора — в <paramref name="parseErrors"/>.</summary>
    private DateTime? ParseScheduledAt(List<string> parseErrors)
    {
        if (Date is null)
        {
            parseErrors.Add("Укажите дату показа");
        }

        if (!TimeSpan.TryParseExact(Time.Trim(), TimeFormats, CultureInfo.InvariantCulture, out var time)
            || time >= TimeSpan.FromDays(1))
        {
            parseErrors.Add("Время укажите в формате ЧЧ:ММ, например 14:30");
        }

        return parseErrors.Count > 0 ? null : Date!.Value.Date + time;
    }
}

/// <summary>Форма оформления сделки.</summary>
public sealed class DealEditorViewModel : EditorViewModelBase
{
    private readonly IDealService _service;
    private readonly IPropertyService _properties;
    private readonly IClientService _clients;
    private readonly IRealtorService _realtors;

    public DealEditorViewModel(
        IDealService service,
        IPropertyService properties,
        IClientService clients,
        IRealtorService realtors,
        int? presetPropertyId)
    {
        _service = service;
        _properties = properties;
        _clients = clients;
        _realtors = realtors;
        _propertyId = presetPropertyId;
    }

    public override string Title => "Оформление сделки";

    public override string SaveText => "Оформить сделку";

    public List<Property> Properties { get; private set; } = new();

    public List<Client> Clients { get; private set; } = new();

    public List<Realtor> Realtors { get; private set; } = new();

    public override async Task LoadAsync()
    {
        // Сделку можно открыть только по активному объекту
        Properties = (await _properties.GetAvailableAsync())
            .Where(p => p.Status == PropertyStatus.Active)
            .ToList();
        Clients = await _clients.GetAllAsync();
        Realtors = await _realtors.GetAllAsync(onlyActive: true);

        OnPropertyChanged(nameof(Properties));
        OnPropertyChanged(nameof(Clients));
        OnPropertyChanged(nameof(Realtors));

        if (PropertyId is int id)
        {
            ApplyProperty(id);
        }
    }

    private int? _propertyId;

    public int? PropertyId
    {
        get => _propertyId;
        set
        {
            if (Set(ref _propertyId, value) && value is int id)
            {
                ApplyProperty(id);
            }
        }
    }

    /// <summary>При выборе объекта подставляем его цену и риэлтора.</summary>
    private void ApplyProperty(int propertyId)
    {
        var p = Properties.FirstOrDefault(x => x.Id == propertyId);
        if (p is null)
        {
            return;
        }

        Amount = Format(p.Price);
        if (Realtors.Any(r => r.Id == p.RealtorId))
        {
            RealtorId = p.RealtorId;
        }

        OfferHint = p.OfferType == OfferType.Rent
            ? "Аренда: укажите сумму ежемесячного платежа"
            : "Продажа: укажите итоговую цену по договору";
    }

    private string _offerHint = string.Empty;

    public string OfferHint { get => _offerHint; private set => Set(ref _offerHint, value); }

    private int? _clientId;

    public int? ClientId { get => _clientId; set => Set(ref _clientId, value); }

    private int? _realtorId;

    public int? RealtorId
    {
        get => _realtorId;
        set
        {
            if (Set(ref _realtorId, value))
            {
                OnPropertyChanged(nameof(CommissionPreview));
            }
        }
    }

    private string _amount = string.Empty;

    public string Amount
    {
        get => _amount;
        set
        {
            if (Set(ref _amount, value))
            {
                OnPropertyChanged(nameof(CommissionPreview));
            }
        }
    }

    private DateTime? _dealDate = DateTime.Today;

    public DateTime? DealDate { get => _dealDate; set => Set(ref _dealDate, value); }

    private bool _completeNow;

    /// <summary>Получает или задает значение, показывающее, что договор уже подписан и сделка сразу «Завершена».</summary>
    public bool CompleteNow { get => _completeNow; set => Set(ref _completeNow, value); }

    /// <summary>Получает подсказку «Комиссия риэлтора: 369 000 ₽ (3 %)».</summary>
    public string CommissionPreview
    {
        get
        {
            var realtor = Realtors.FirstOrDefault(r => r.Id == RealtorId);
            var amount = ParseDecimal(Amount, string.Empty, new List<string>());
            if (realtor is null || amount is null || amount <= 0)
            {
                return string.Empty;
            }

            var commission = _service.CalculateCommission(amount.Value, realtor.CommissionPercent);
            return $"Комиссия риэлтора: {commission:N0} ₽ ({realtor.CommissionPercent:0.##} %)";
        }
    }

    protected override async Task SaveCoreAsync(List<string> parseErrors)
    {
        var amount = ParseDecimal(Amount, "Сумма", parseErrors);
        if (DealDate is null)
        {
            parseErrors.Add("Укажите дату сделки");
        }

        if (parseErrors.Count > 0)
        {
            return;
        }

        // Время берём текущее, чтобы сделки за один день шли по порядку
        var date = DealDate!.Value.Date == DateTime.Today ? DateTime.Now : DealDate.Value.Date.AddHours(12);

        await _service.CreateAsync(new Deal
        {
            PropertyId = PropertyId ?? 0,
            ClientId = ClientId ?? 0,
            RealtorId = RealtorId ?? 0,
            Amount = amount!.Value,
            DealDate = date,
            Status = CompleteNow ? DealStatus.Completed : DealStatus.Open,
        });
    }
}
