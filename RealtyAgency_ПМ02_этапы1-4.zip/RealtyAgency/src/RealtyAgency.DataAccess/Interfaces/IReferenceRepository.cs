using RealtyAgency.DataAccess.Entities;

namespace RealtyAgency.DataAccess.Interfaces;

/// <summary>Справочники: районы и типы недвижимости.</summary>
public interface IReferenceRepository
{
    /// <summary>Возвращает районы по алфавиту.</summary>
    /// <returns>Список районов.</returns>
    Task<List<District>> GetDistrictsAsync();

    /// <summary>Возвращает типы недвижимости по алфавиту.</summary>
    /// <returns>Список типов.</returns>
    Task<List<PropertyType>> GetPropertyTypesAsync();
}
