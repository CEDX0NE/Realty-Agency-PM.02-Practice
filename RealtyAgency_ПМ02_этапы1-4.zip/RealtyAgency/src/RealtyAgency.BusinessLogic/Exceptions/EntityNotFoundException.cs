namespace RealtyAgency.BusinessLogic.Exceptions;

/// <summary>Запись не найдена (например, удалена в другом окне).</summary>
public class EntityNotFoundException : RealtyException
{
    /// <summary>Инициализирует новый экземпляр класса <see cref="EntityNotFoundException"/>.</summary>
    /// <param name="message">Текст для пользователя.</param>
    /// <param name="inner">Исходное исключение.</param>
    public EntityNotFoundException(string message, Exception? inner = null)
        : base(message, inner)
    {
    }
}
