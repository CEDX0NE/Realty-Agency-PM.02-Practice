using System.Diagnostics;
using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Logging;
using RealtyAgency.DataAccess;

namespace RealtyAgency.BusinessLogic.Services;

/// <summary>
/// Общая часть сервисов: перевод ошибок слоя данных (DataAccessException)
/// в исключения бизнес-логики + запись в журнал.
/// </summary>
public abstract class ServiceBase
{
    /// <summary>Выполняет операцию сервиса с переводом ошибок БД в исключения бизнес-логики.</summary>
    /// <typeparam name="T">Тип результата.</typeparam>
    /// <param name="operation">Название операции для журнала.</param>
    /// <param name="action">Операция.</param>
    /// <returns>Результат операции.</returns>
    protected static async Task<T> GuardAsync<T>(string operation, Func<Task<T>> action)
    {
        Debug.WriteLine($"[BLL] -> {operation}");
        try
        {
            return await action();
        }
        catch (DataAccessException ex)
        {
            AppLog.Error("BLL", operation, ex);
            throw ex.Kind switch
            {
                DbErrorKind.NotFound => new EntityNotFoundException(ex.Message, ex),
                DbErrorKind.ForeignKey => new DeleteRestrictedException(ex.Message, ex),
                DbErrorKind.Rule => new BusinessRuleException(ex.Message),
                DbErrorKind.Duplicate => new BusinessRuleException(ex.Message),
                _ => new DatabaseException(ex.Message, ex),
            };
        }
        catch (RealtyException ex)
        {
            // Бизнес-ошибку тоже пишем в журнал — это пригодится в протоколе отладки
            AppLog.Warn("BLL", $"{operation}: {ex.GetType().Name} — {ex.Message.Replace('\n', ' ')}");
            throw;
        }
    }

    /// <summary>Выполняет операцию сервиса без результата.</summary>
    /// <param name="operation">Название операции для журнала.</param>
    /// <param name="action">Операция.</param>
    /// <returns>Задача.</returns>
    protected static Task GuardAsync(string operation, Func<Task> action) =>
        GuardAsync<bool>(operation, async () =>
        {
            await action();
            return true;
        });

    /// <summary>
    /// Удаление записи, на которую могут ссылаться другие таблицы: ошибка внешнего ключа
    /// (или триггера-предохранителя) превращается в понятное сообщение.
    /// </summary>
    /// <param name="delete">Операция удаления в репозитории.</param>
    /// <param name="restrictedMessage">Сообщение, если удалить нельзя.</param>
    /// <returns>Задача.</returns>
    protected static async Task DeleteOrExplainAsync(Func<Task> delete, string restrictedMessage)
    {
        try
        {
            await delete();
        }
        catch (DataAccessException ex) when (ex.Kind is DbErrorKind.ForeignKey or DbErrorKind.Rule)
        {
            throw new DeleteRestrictedException(restrictedMessage, ex);
        }
    }
}
