using System.Diagnostics;
using RealtyAgency.BusinessLogic.Exceptions;
using RealtyAgency.BusinessLogic.Interfaces;
using RealtyAgency.DataAccess.Entities;
using RealtyAgency.DataAccess.Interfaces;

namespace RealtyAgency.BusinessLogic.Services;

/// <summary>Клиенты.</summary>
public class ClientService : ServiceBase, IClientService
{
    private readonly IClientRepository _repo;

    /// <summary>Инициализирует новый экземпляр класса <see cref="ClientService"/>.</summary>
    /// <param name="repo">Репозиторий клиентов.</param>
    public ClientService(IClientRepository repo) => _repo = repo;

    /// <inheritdoc/>
    public Task<List<Client>> GetAllAsync(string? search = null) =>
        GuardAsync("Список клиентов", () => _repo.GetAllAsync(search));

    /// <inheritdoc/>
    public Task SaveAsync(Client client) =>
        GuardAsync($"Сохранение клиента «{client.FullName}»", async () =>
        {
            client.FullName = client.FullName.Trim();
            client.Phone = Validator.NormalizePhone(client.Phone);
            client.Email = Validator.Clean(client.Email);
            client.Notes = Validator.Clean(client.Notes);

            new Validator()
                .Require(client.FullName.Length >= Limits.MinNameLength, $"ФИО клиента — не короче {Limits.MinNameLength} символов")
                .Require(Validator.IsPhone(client.Phone), "Телефон — минимум 10 цифр, например +7 (900) 123-45-67")
                .Require(Validator.IsEmailOrEmpty(client.Email), "E-mail указан неверно")
                .Require((client.Notes?.Length ?? 0) <= Limits.MaxNoteLength, $"Заметка — не длиннее {Limits.MaxNoteLength} символов")
                .ThrowIfInvalid();

            if (await _repo.PhoneExistsAsync(client.Phone, client.Id))
            {
                throw new ValidationException("Клиент с таким телефоном уже есть");
            }

            if (client.Id == 0)
            {
                await _repo.AddAsync(client);
            }
            else
            {
                await _repo.UpdateAsync(client);
            }

            Debug.WriteLine($"[BLL] Клиент сохранён, ID={client.Id}");
        });

    /// <inheritdoc/>
    public Task DeleteAsync(int id) =>
        GuardAsync($"Удаление клиента ID={id}", () => DeleteOrExplainAsync(
            () => _repo.DeleteAsync(id),
            "Клиент участвует в объектах, показах или сделках — удалить его нельзя."));
}
